//
//  JZModuleView.m
//  RF
//
//  Created by Jim on 2017/5/10.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZModuleView.h"
#import "CustomSize.h"
#import "NSLabel.h"

@interface JZModuleView () <NSCollectionViewDelegate>
{
    NSRect _labelFrame;
    
    NSRect _collectionScrollViewFrame;
    
    NSRect _insertViewFrame;
}

@property (nonatomic) NSLabel *label;

@property (nonatomic) JZCollectionScrollView *collectionScrollView;

@property (nonatomic) JZInsertView *insertView;

@end

@implementation JZModuleView

- (NSLabel *)label
{
    if (!_label) {
        
        _label = [[NSLabel alloc] initWithFrame:_labelFrame];
        
        _label.text = @"Insert Item Here";
        
        _label.alignment = NSTextAlignmentCenter;
        
        _label.font = [NSFont systemFontOfSize:15];
    }
    
    return _label;
}

- (JZCollectionScrollView *)collectionScrollView
{
    if (!_collectionScrollView) {
        
        _collectionScrollView = [[JZCollectionScrollView alloc] initWithFrame:_collectionScrollViewFrame];
    }
    
    return _collectionScrollView;
}

- (JZInsertView *)insertView
{
    if (!_insertView) {
        
        _insertView = [[JZInsertView alloc] initWithFrame:_insertViewFrame];
    }
    
    return _insertView;
}

- (void)setFrame:(NSRect)frame
{
    [super setFrame:frame];
    
    self.label.frame = NSMakeRect(0, self.bounds.size.height - 30, self.bounds.size.width, 30);
    
    self.collectionScrollView.frame = NSMakeRect(0,
                                                 insertviewheight + interval * 2,
                                                 self.bounds.size.width,
                                                 self.bounds.size.height - insertviewheight - interval * 2 - 30);
    
    self.insertView.frame = _insertViewFrame;

}

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _labelFrame = NSMakeRect(0, self.bounds.size.height - 30, self.bounds.size.width, 30);
        
        _collectionScrollViewFrame = NSMakeRect(0,
                                                insertviewheight + interval * 2,
                                                self.bounds.size.width,
                                                self.bounds.size.height - insertviewheight - interval * 2 - 30);
        
        _insertViewFrame = NSMakeRect(0, interval, insertviewheight, insertviewheight);
        
        [self addSubview:self.label];
        
        [self addSubview:self.collectionScrollView];
        
        [self addSubview:self.insertView];
    }
    return self;
}

- (void)updateItemName:(NSString *)itemName
{
    _itemName = [itemName copy];
    
    [self.insertView updateItemName:itemName];
    
    [self.collectionScrollView updateItemName:itemName];
}

@end
