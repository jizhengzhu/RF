//
//  JZLogScrollView.h
//  RF
//
//  Created by Jim on 2017/4/26.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface JZLogScrollView : NSScrollView

@property IBOutlet NSTextView *textView;

@end
