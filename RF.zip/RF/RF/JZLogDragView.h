//
//  JZLogDragView.h
//  RF
//
//  Created by Jim on 2017/5/8.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class JZLogDragView;

@protocol JZLogDragViewDelegate <NSObject>

@optional
- (void)logDragView:(JZLogDragView *)logDragView mouseDrag:(NSEvent *)event;

@end

@interface JZLogDragView : NSView

@property (weak) id <JZLogDragViewDelegate> delegate;

@end
