//
//  JZOutlineView.h
//  RF
//
//  Created by Jim on 2017/5/8.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface JZOutlineView : NSOutlineView

@end
