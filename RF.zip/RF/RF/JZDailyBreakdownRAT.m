//
//  JZDailyBreakdownRAT.m
//  RF
//
//  Created by Jim on 2017/5/5.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZDailyBreakdownRAT.h"
#import "JZFileDragView.h"
#import "JZLimitView.h"
#import "JZDailyBreakdownRATFrame.h"
#import "JZModuleView.h"
#import "CustomSize.h"
#import "JZShellTool.h"
#import "JZLocalNotificationTool.h"
#import "JZAlertTool.h"
#import "JZApplicationManager.h"

@interface JZDailyBreakdownRAT () <JZFileDragViewDelegate, NSAlertDelegate, NSUserNotificationCenterDelegate>
{
    NSString *_summaryFilePath;
    
    NSString *_frequencyFilePath;
    
    NSString *_notificationTitle;
    
    NSString *_notificationSubtitle;
    
    NSString *_notificationInformativeText;
    
    NSUserNotification *_removedNotification;
}

@end

@implementation JZDailyBreakdownRAT

- (JZDailyBreakdownRATFrame *)myFrame
{
    if (!_myFrame) {
        
        _myFrame = [[JZDailyBreakdownRATFrame alloc] initWithRect:self.bounds];
    }
    return _myFrame;
}

- (JZFileDragView *)summaryDragView
{
    if (!_summaryDragView) {
        
        _summaryDragView = [JZFileDragView fileDragViewFrame:self.myFrame.summaryDragViewFrame fileTypes:@[@"xlsx"] imageNames:@[@"xlsx"]];
        
        _summaryDragView.title.text = @"Summary File Here";
        
        _summaryDragView.delegate = self;
        
        _summaryDragView.viewName = @"Summary";
        
        [[[JZApplicationManager manager] fileDragViewPool] addFileDragView:_summaryDragView];
    }
    
    return _summaryDragView;
}

- (JZFileDragView *)frequencyDragView
{
    if (!_frequencyDragView) {
        
        _frequencyDragView = [JZFileDragView fileDragViewFrame:self.myFrame.frequencyDragViewFrame fileTypes:@[@"xlsx"] imageNames:@[@"xlsx"]];
        
        _frequencyDragView.title.text = @"Frequency File Here";
        
        _frequencyDragView.delegate = self;

        _frequencyDragView.viewName = @"Frequency";

        [[[JZApplicationManager manager] fileDragViewPool] addFileDragView:_frequencyDragView];

    }
    
    return _frequencyDragView;
}

- (JZLimitView *)limitView
{
    if (!_limitView) {
        
        _limitView = [[JZLimitView alloc] initWithFrame:self.myFrame.limitViewFrame];
        
        NSString *path = [[NSBundle mainBundle] pathForResource:@"RATLimitList" ofType:@"plist"];
        
        NSArray *array = [NSArray arrayWithContentsOfFile:path];
        
        _limitView.dataArray = array;
        
    }
    
    return _limitView;
}

- (NSButton *)optionBtn
{
    if (!_optionBtn) {
        
        _optionBtn = [[NSButton alloc] initWithFrame:self.myFrame.optionBtnFrame];
        
        [_optionBtn setButtonType:NSButtonTypeSwitch];
        
        [_optionBtn setTitle:@"PathLoss Summary"];
    }
    
    return _optionBtn;
}

- (JZModuleView *)moduleView
{
    if (!_moduleView) {
        
        _moduleView = [[JZModuleView alloc] initWithFrame:self.myFrame.moduleViewFrame];
    }
    
    return _moduleView;
}

- (void)setFrame:(NSRect)frame
{
    [super setFrame:frame];
    
    _myFrame = [[JZDailyBreakdownRATFrame alloc] initWithRect:self.bounds];
    
    self.summaryDragView.frame = _myFrame.summaryDragViewFrame;
    
    self.frequencyDragView.frame = _myFrame.frequencyDragViewFrame;
    
    self.limitView.frame = _myFrame.limitViewFrame;
    
    self.optionBtn.frame = _myFrame.optionBtnFrame;
    
    self.moduleView.frame = _myFrame.moduleViewFrame;
}

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
                
        [self addSubview:self.summaryDragView];
        
        [self addSubview:self.frequencyDragView];
        
        [self addSubview:self.limitView];
        
        [self addSubview:self.optionBtn];
        
        [self addSubview:self.moduleView];
        
        [[NSUserNotificationCenter defaultUserNotificationCenter] setDelegate:self];
    }
    return self;
}

- (void)updateItemName:(NSString *)itemName
{
    self.itemName = [itemName copy];
    
    NSString *key = [NSString stringWithFormat:@"%@%@", itemName, ModuleArrayKey];
    
    NSMutableArray *mArray = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    
    if (mArray == nil) {
        
        NSString *path = [[NSBundle mainBundle] pathForResource:@"RATModule" ofType:@"plist"];
        
        NSArray *array = [NSArray arrayWithContentsOfFile:path];
        
        NSMutableArray *moduleArray = [NSMutableArray arrayWithArray:array];
        
        [[NSUserDefaults standardUserDefaults] setObject:moduleArray forKey:key];
        
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    
    [self.moduleView updateItemName:itemName];
    
    NSString *notificationName = [NSString stringWithFormat:@"%@%@", self.itemName, UserUnixTaskNotification];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(runPythonCompletion:) name:notificationName object:nil];
    
    NSString *summaryFilePathKey = [NSString stringWithFormat:@"%@%@%@", self.itemName, self.summaryDragView.viewName, FilePathKey];
    
    _summaryFilePath = [[NSUserDefaults standardUserDefaults] objectForKey:summaryFilePathKey];
    
    
    if (_summaryFilePath.length > 0) {
        
        self.summaryDragView.filePath = _summaryFilePath;
        
    }
    
    NSString *frequencyFilePathKey = [NSString stringWithFormat:@"%@%@%@", self.itemName, self.frequencyDragView.viewName, FilePathKey];
    
    _frequencyFilePath = [[NSUserDefaults standardUserDefaults] objectForKey:frequencyFilePathKey];
    
    
    if (_frequencyFilePath.length > 0) {
        
        self.frequencyDragView.filePath = _frequencyFilePath;
        
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateSummaryFilePath:) name:JZDailyBreakdownInsertConfigCreateSucceededNotification object:nil];
}

/**
 *  父类方法
 */
- (void)runPythonFile
{
    NSLog(@"%s", __FUNCTION__);
    
    [self runPythonFileWithBlock:^{
        
        NSString *path = [[NSBundle mainBundle] pathForResource:@"test0" ofType:@"py"];
        
        NSString *shellcode = [NSString stringWithFormat:@"python %@", path];
        
        [JZShellTool shellToolExec:shellcode itemName:self.itemName];
        
    }];
}

- (void)runPythonFileWithBlock:(void(^)())block
{
    NSString *messageText;
    
    NSString *informativeText = @"you can drag excel file to the dashed area or click the dashed area to select file";
    
    if (_summaryFilePath.length > 0 && _frequencyFilePath.length > 0) {
        
        block();
        
        return;
        
    } else if (_summaryFilePath.length == 0  && _frequencyFilePath.length > 0) {
        
        messageText = @"Please Check for Missing Summary File";
        
    } else if (_summaryFilePath.length > 0 && _frequencyFilePath.length == 0) {
        
        messageText = @"Please Check for Missing Frequency File";
        
    } else if (_summaryFilePath.length == 0 && _frequencyFilePath.length == 0) {
        
        messageText = @"Please Check for Missing Summary File and Frequency File";
        
    }
    
    [JZAlertTool showAlertWithMessageText:messageText informativeText:informativeText window:self.window];
    
}

#pragma mark - NSUserNotificationCenter
- (void)runPythonCompletion:(NSNotification *)note
{
    [super runPythonCompletion:note];
    
    NSString *errorString = [note userInfo][@"errorString"];
    
    if (errorString.length == 0) {
        
        _notificationTitle = @"Create Succeeded";
        
        _notificationInformativeText = @"new excel file here.";
        
    } else {
        
        _notificationTitle = @"Create Failed";
        
        _notificationInformativeText = @"See the log below for more information.";
    }
    
    _notificationSubtitle = @"Daily & Breakdown RAT";
    
    _removedNotification = [JZLocalNotificationTool postNotificationWithTitle:_notificationTitle
                                                                     subtitle:_notificationSubtitle
                                                              informativeText:_notificationInformativeText
                                                                     itemName:self.itemName
                                                          removedNotification:_removedNotification];
}

- (void)updateSummaryFilePath:(NSNotification *)notify
{
    NSString *filePath = [notify userInfo][@"filePath"];
        
    self.summaryDragView.filePath = filePath;
        
    _summaryFilePath = filePath;
}

#pragma mark - NSUserNotificationCenterDelegate
- (void)userNotificationCenter:(NSUserNotificationCenter *)center didDeliverNotification:(NSUserNotification *)notification
{
    NSLog(@"通知已经递交！");
    
    if (notification.presented == NO) {
        
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            
            _removedNotification = [JZLocalNotificationTool postNotificationWithTitle:_notificationTitle
                                                                             subtitle:_notificationSubtitle
                                                                      informativeText:_notificationInformativeText
                                                                             itemName:self.itemName
                                                                  removedNotification:_removedNotification];
        });
        
    }
}

- (void)userNotificationCenter:(NSUserNotificationCenter *)center didActivateNotification:(NSUserNotification *)notification
{
    if (notification.activationType == NSUserNotificationActivationTypeAdditionalActionClicked) {
        
        NSLog(@"NSUserNotificationActivationTypeAdditionalActionClicked");
    }
    NSLog(@"用户点击了通知！");
    
    NSURL *url = [NSURL URLWithString:@"file:///Users/jim/Desktop/xiaolong/xiaolong.xlsx"];
    [[NSWorkspace sharedWorkspace] activateFileViewerSelectingURLs:@[url]];
}

- (BOOL)userNotificationCenter:(NSUserNotificationCenter *)center shouldPresentNotification:(NSUserNotification *)notification
{
    //用户中心决定不显示该条通知(如果显示条数超过限制或重复通知等)，returen YES;强制显示
    return YES;
}

#pragma mark - JZFileDragViewDelegate
- (void)fileDragView:(JZFileDragView *)fileDragView throwFilePath:(NSString *)filePath
{
    NSLog(@"filePath = %@", filePath);
    
    if ([fileDragView.viewName isEqualToString:@"Summary"]) {
        
        _summaryFilePath = filePath;
    
    } else if ([fileDragView.viewName isEqualToString:@"Frequency"]) {
        
        _frequencyFilePath = filePath;
        
    }
        
    NSString *key = [NSString stringWithFormat:@"%@%@%@", self.itemName, fileDragView.viewName, FilePathKey];
    
    [[NSUserDefaults standardUserDefaults] setObject:filePath forKey:key];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)dealloc
{
    NSString *notificationName = [NSString stringWithFormat:@"%@%@", self.itemName, UserUnixTaskNotification];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationName object:nil];
    
}

@end
