//
//  JZDailyBreakdownWiFi.h
//  RF
//
//  Created by Jim on 2017/5/5.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZMainView.h"

@class JZFileDragView, JZModuleView, JZLimitView, JZDailyBreakdownWiFiFrame, NSLabel;

@interface JZDailyBreakdownWiFi : JZMainView

@property (nonatomic) JZFileDragView *summaryDragView;

@property (nonatomic) JZModuleView *moduleView;

@property (nonatomic) JZLimitView *limitView;

@property (nonatomic) JZDailyBreakdownWiFiFrame *myFrame;

@property (nonatomic) NSButton *optionBtn;

@end
