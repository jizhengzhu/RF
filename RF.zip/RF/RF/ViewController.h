//
//  ViewController.h
//  RF
//
//  Created by Jim on 2017/4/25.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class JZFilterView, JZOutlineViewDelegate, JZMainSuperView, JZLogToolView, JZLogScrollView, JZOutlineView, JZLogDragView;
@interface ViewController : NSViewController

@property (weak) IBOutlet JZOutlineView *outlineView;

@property (weak) IBOutlet JZLogToolView *logToolView;

@property (weak) IBOutlet JZFilterView *filterView;

@property (weak) IBOutlet JZMainSuperView *mainView;

@property (strong) IBOutlet JZOutlineViewDelegate *outlineViewDelegate;

@property (weak) IBOutlet JZLogDragView *logDragView;

@property (weak) IBOutlet NSButton *showAndHiddenLogButton;

@property (weak) IBOutlet NSButton *cleanButton;

@property (weak) IBOutlet JZLogScrollView *logScrollView;

- (IBAction)cleanLog:(NSButton *)sender;

- (IBAction)showAndHiddenLog:(id)sender;

@end

