//
//  JZDailyBreakdownInsertConfigrect.m
//  RF
//
//  Created by Jim on 2017/5/6.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZDailyBreakdownInsertConfigFrame.h"
#import "CustomSize.h"

@implementation JZDailyBreakdownInsertConfigFrame
{
    CGFloat margin;
    
    CGFloat y;
}

- (instancetype)initWithRect:(NSRect)rect
{
    
    self = [super init];
    if (self) {
        margin = (rect.size.width - (dragviewlength + interval * 2 + 80) * 2) / 3;
        
        y = rect.size.height * goldenRatio;
        
        CGFloat antennaInformationViewX = margin;
        
        CGFloat antennaInformationViewY = y;
        
        CGFloat antennaInformationViewW = dragviewlength + interval * 2 + 80;
        
        CGFloat antennaInformationViewH = dragviewlength * (1.f + goldenRatio) + dragviewtitleheight;
        
        _antennaInformationViewFrame = NSMakeRect(antennaInformationViewX, antennaInformationViewY, antennaInformationViewW, antennaInformationViewH);
        
        CGFloat rawDataViewX = antennaInformationViewX + antennaInformationViewW + margin;
        
        CGFloat rawDataViewY = y;
        
        CGFloat rawDataViewW = antennaInformationViewW;
        
        CGFloat rawDataViewH = antennaInformationViewH;
        
        _rawDataViewFrame = NSMakeRect(rawDataViewX, rawDataViewY, rawDataViewW, rawDataViewH);
    
        CGFloat moduleViewX = 50;

        CGFloat moduleViewY = 0;

        CGFloat moduleViewW = rect.size.width - 100;

        CGFloat moduleViewH = antennaInformationViewY;
        
        _moduleViewFrame = NSMakeRect(moduleViewX, moduleViewY, moduleViewW, moduleViewH);
        
    }
    return self;
}

@end
