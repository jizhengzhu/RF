//
//  JZOutlineCellPool.m
//  RF
//
//  Created by Jim on 2017/5/9.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZOutlineCellPool.h"
#import "JZOutlineCell.h"
#import "JZOutlineView.h"
#import "JZWindow.h"
#import "CustomSize.h"

@implementation JZOutlineCellPool


- (NSMutableDictionary *)outlineCellPool
{
    if (!_outlineCellPool) {
        
        _outlineCellPool = [NSMutableDictionary dictionary];
    }
    return _outlineCellPool;
}

- (JZOutlineCell *)findOutlineCellByItemName:(NSString *)itemName
{
    return [self.outlineCellPool objectForKey:itemName];
}

- (void)addOutlineCell:(JZOutlineCell *)outlineCell
{
    [self.outlineCellPool setObject:outlineCell forKey:outlineCell.itemName];
}

- (void)refreshOutlineCellDisplayWithFirstResponder:(id)firstResponder
{
    NSLog(@"firstResponder class = %@", [firstResponder class]);
    
    if ([firstResponder isKindOfClass:[JZOutlineView class]] || [firstResponder isKindOfClass:[JZWindow class]]) {
        
        NSString *itemName = [[NSUserDefaults standardUserDefaults] objectForKey:keyItemName];
        
        JZOutlineCell *cell = [self findOutlineCellByItemName:itemName];
        
        firstResponder = cell;
    }
    
    NSString *labelItemName;
    
    BOOL isOutlineCell;
    
    if ([firstResponder isKindOfClass:[JZOutlineCell class]]) {
        
        labelItemName = [firstResponder itemName];
        
        isOutlineCell = YES;
        
    } else {
        
        isOutlineCell = NO;
    }
    
    if (_main == NO) {
        
        isOutlineCell = NO;
    }
    
    for (NSString *key in self.outlineCellPool) {
        
        JZOutlineCell *outlineCell = [self.outlineCellPool objectForKey:key];
        
        if (isOutlineCell) {
            
            if ([key isEqualToString:labelItemName]) {
                
                outlineCell.isSelected = YES;
                
                [outlineCell.label setTextColor:[NSColor whiteColor]];
                
                [outlineCell setBackgroundColor:[NSColor colorWithRed:0.11 green:0.38 blue:0.22 alpha:1.00]];
                
                if ([outlineCell.label.text isEqualToString:@"InsertConfig"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"confighighlight"];
                    
                } else if ([outlineCell.label.text isEqualToString:@"WiFi"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"WiFihighlight"];
                    
                } else if ([outlineCell.label.text isEqualToString:@"RAT"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"RAThighlight"];
                    
                } else if ([outlineCell.label.text isEqualToString:@"WF3"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"WF3highlight"];
                    
                } else if ([outlineCell.label.text isEqualToString:@"WF5"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"WF5highlight"];
                    
                }
                
            } else {
                
                outlineCell.isSelected = NO;
                
                [outlineCell.label setTextColor:[NSColor colorWithWhite:0.3 alpha:1]];
                
                [outlineCell setBackgroundColor:[NSColor clearColor]];
                
                if ([outlineCell.label.text isEqualToString:@"InsertConfig"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"confignormal"];
                    
                } else if ([outlineCell.label.text isEqualToString:@"WiFi"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"WiFinormal"];
                    
                } else if ([outlineCell.label.text isEqualToString:@"RAT"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"RATnormal"];
                    
                } else if ([outlineCell.label.text isEqualToString:@"WF3"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"WF3normal"];
                    
                } else if ([outlineCell.label.text isEqualToString:@"WF5"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"WF5normal"];
                    
                }
            }
            
            
        } else {
            
            if (outlineCell.isSelected == YES) {
                
                [outlineCell.label setTextColor:[NSColor blackColor]];
                
                [outlineCell setBackgroundColor:[NSColor colorWithRed:0.11 green:0.38 blue:0.22 alpha:0.5]];
                
                if ([outlineCell.label.text isEqualToString:@"InsertConfig"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"confignormal"];
                    
                } else if ([outlineCell.label.text isEqualToString:@"WiFi"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"WiFinormal"];
                    
                } else if ([outlineCell.label.text isEqualToString:@"RAT"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"RATnormal"];
                    
                } else if ([outlineCell.label.text isEqualToString:@"WF3"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"WF3normal"];
                    
                } else if ([outlineCell.label.text isEqualToString:@"WF5"]) {
                    
                    outlineCell.image = [NSImage imageNamed:@"WF5normal"];
                    
                }
                
            }
        }
        
        if (outlineCell.selectable == NO) {
            
            outlineCell.label.textColor = [NSColor blackColor];
        }
    }
    
}

@end
