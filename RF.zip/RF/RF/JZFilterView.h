//
//  JZFilterView.h
//  RF
//
//  Created by Jim on 2017/4/26.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface JZFilterView : NSView

@property (weak) IBOutlet NSTextField *textField;


- (void)adjustBorder;

@end
