//
//  JZDragView.h
//  RF
//
//  Created by Jim on 2017/5/5.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

static const CGFloat lineWidth = 2;

typedef NS_ENUM(NSInteger, JZDragStatus) {
    
    JZ_DragEnd = 0,
    
    JZ_DragExit = 1,
    
    JZ_DragEnter = 2,
};

typedef NS_ENUM(NSInteger, JZMouseLocationStatus) {
    
    JZ_MouseExit = 0,
    
    JZ_MouseEnter = 1,
};

typedef NS_ENUM(NSInteger, JZMousePressStatus) {
    
    JZ_MouseUp = 0,
    
    JZ_MouseDown = 1,
};

@class JZDragView;
@protocol JZDragViewDelegate <NSObject>

@optional
- (void)dragView:(JZDragView *)dragView throwFilePath:(NSString *)filePath;

- (void)mouseEnterDragView:(JZDragView *)dragView;

- (void)mouseDownDragView:(JZDragView *)dragView;

- (void)mouseUpDragView:(JZDragView *)dragView;

- (void)mouseExitDragView:(JZDragView *)dragView;

- (void)draggingEndDragView:(JZDragView *)dragView;

@end

@interface JZDragView : NSImageView
{
    JZDragStatus _dragStatus;
    
    JZMousePressStatus _mousePressStatus;
    
    CGFloat _radius;
    
    CGFloat _borderlengths;
    
    CGFloat _bordergaps;
    
    CGFloat _pluslengths;
    
    CGFloat _plusgaps;
}

@property BOOL fileExist;

@property JZMouseLocationStatus mouseLocationStatus;

@property (weak) id <JZDragViewDelegate> delegate;

@property (copy, readonly) NSString *imageName;

@property (nonatomic, readonly) NSArray *fileTypes;

@property (nonatomic) BOOL isSelected;

- (instancetype)initWithFrame:(NSRect)frameRect fileTypes:(NSArray *)fileTypes imageNames:(NSArray *)imageNames;

+ (instancetype)dragViewFrame:(NSRect)frame fileTypes:(NSArray *)fileTypes imageNames:(NSArray *)imageNames;

@end
