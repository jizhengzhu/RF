//
//  JZDragView+RightClick.h
//  RF
//
//  Created by Jim on 2017/5/15.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZDragView.h"

@interface JZDragView (RightClick)

@end
