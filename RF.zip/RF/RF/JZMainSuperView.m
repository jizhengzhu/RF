//
//  JZMainSuperView.m
//  RF
//
//  Created by Jim on 2017/5/8.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZMainSuperView.h"
#import "CustomSize.h"
#import "JZApplicationManager.h"
#import "JZMainView.h"
#import <objc/runtime.h>

@implementation JZMainSuperView

- (void)setItemName:(NSString *)itemName
{
    _itemName = [itemName copy];
    
    JZMainView *mainView = [[[JZApplicationManager manager] mainViewPool] findMainViewByItemName:itemName];
    
    if (!mainView) {
        
        Class class = objc_getClass([itemName UTF8String]);
        
        mainView = [[class alloc] initWithFrame:self.bounds];
        
        // 执行这个方法后，mainView的ItemName才有值，再initWithFrame方法里self的ItemName的值是空的
        [mainView updateItemName:itemName];
        
        [[[JZApplicationManager manager] mainViewPool] addMainView:mainView];
        
    }
    
    mainView.frame = self.bounds;
    
    [self removeAllSubViews];
    
    [self addSubview:mainView];
    
}

- (void)setFrame:(NSRect)frame
{
    [super setFrame:frame];
    
    NSLog(@"%@", NSStringFromRect(self.bounds));
    
    NSLog(@"SUBVIEWS = %@", [[self.subviews lastObject] class]);
    
    [[self.subviews lastObject] setFrame:self.bounds];
    
}

- (void)removeAllSubViews
{
    for (NSView *subView in self.subviews) {
        
        [subView removeFromSuperview];
    }
}

- (void)mouseMoved:(NSEvent *)event
{
    [super mouseMoved:event];
    
    [[NSCursor arrowCursor] set];
}

- (void)drawRect:(NSRect)dirtyRect {
    
    [super drawRect:dirtyRect];

}

@end
