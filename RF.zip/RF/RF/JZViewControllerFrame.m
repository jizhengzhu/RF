
//
//  JZViewControllerFrame.m
//  RF
//
//  Created by Jim on 2017/5/9.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZViewControllerFrame.h"
#import "CustomSize.h"

@implementation JZViewControllerFrame

- (instancetype)initWithRect:(NSRect)rect
{
    self = [super init];
    
    if (self) {
        
        _logViewHeight = 145;

        [self refreshFrameWithRect:rect];
    }
    return self;
}

- (void)refreshFrameWithRect:(NSRect)rect
{
    
    _mainViewFrame = NSMakeRect(tbwidth, toolheight, rect.size.width - tbwidth, rect.size.height - toolheight);
    
    _logDragViewFrame = NSMakeRect(tbwidth, _logViewHeight + toolheight, rect.size.width - tbwidth, logdragheight);
    
    _logScrollViewFrame = NSMakeRect(tbwidth, toolheight, rect.size.width - tbwidth, _logViewHeight);
    
}

@end
