//
//  JZCollectionScrollView.h
//  RF
//
//  Created by Jim on 2017/5/13.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JZCollectionView.h"

@interface JZCollectionScrollView : NSView

@property (readonly) NSString *itemName;

@property (nonatomic, readonly) JZCollectionView *collectionView;

- (void)addModuleWithModuleName:(NSString *)moduleName;

- (void)refreshCollectionView;

- (void)updateItemName:(NSString *)itemName;

@end
