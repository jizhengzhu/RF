//
//  JZApplicationManager.h
//  RF
//
//  Created by Jim on 2017/5/7.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JZOutlineCellPool.h"
#import "JZFileDragViewPool.h"
#import "JZMainViewPool.h"
#import "JZCollectionCellPool.h"
#import <Cocoa/Cocoa.h>

@interface JZApplicationManager : NSObject

+ (instancetype)manager;

@property (readonly) BOOL isFirstLaunch;

@property (nonatomic) id firstResponder;

@property (nonatomic) BOOL main;

@property (nonatomic, readonly) JZMainViewPool *mainViewPool;

@property (nonatomic, readonly) JZOutlineCellPool *outlineCellPool;

@property (nonatomic, readonly) JZFileDragViewPool *fileDragViewPool;

@property (nonatomic, readonly) JZCollectionCellPool *collectionCellPool;

@property (nonatomic, readonly) NSMutableArray *pageManagerArray;

@property NSInteger index;

- (void)increaseIndex;

- (void)decreaseIndex;

- (void)refreshOutlineCellDisplay;

- (void)refreshFileDragViewDisplay;

- (void)refreshCollectionViewDisplay;

@end
