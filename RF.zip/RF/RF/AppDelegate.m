//
//  AppDelegate.m
//  RF
//
//  Created by Jim on 2017/4/25.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()



@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    
    NSLog(@"%s", __FUNCTION__);

//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"JZDailyBreakdownInsertConfigModuleArrayKey"];
//    
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"JZDailyBreakdownWiFiModuleArrayKey"];
//    
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"JZDailyBreakdownRATModuleArrayKey"];
    
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"JZDailyBreakdownInsertConfigRawDataFilePathKey"];
//    
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"JZDailyBreakdownInsertConfigAntennaInformationFilePathKey"];
    
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
    NSLog(@"%s", __FUNCTION__);

}

@end
