//
//  JZDragView.m
//  RF
//
//  Created by Jim on 2017/5/5.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZDragView.h"
#import "JZDragView+drawRect.h"
#import "JZApplicationManager.h"
#import "JZDragView+selectFiles.h"
#import "JZFileDragView.h"

@interface JZDragView ()

@property NSArray *fileTypes;

@property (copy) NSArray *imageNames;

@end

@implementation JZDragView

- (instancetype)initWithFrame:(NSRect)frame fileTypes:(NSArray *)fileTypes imageNames:(NSArray *)imageNames
{
    self = [super initWithFrame:frame];
    if (self) {
        
        _radius = frame.size.width / 10.f;
        
        _borderlengths = frame.size.width / 10.f;
        
        _bordergaps = _borderlengths / 4.f;
        
        _pluslengths = frame.size.width * 3.f / 20.f;
        
        _plusgaps = _pluslengths / 6.f;
        
        _dragStatus = JZ_DragEnd;
        
        _mouseLocationStatus = JZ_MouseExit;
        
        _mousePressStatus = JZ_MouseUp;

        _fileExist = NO;
        
        _fileTypes = fileTypes;
        
        _imageNames = imageNames;
        
        [self registerForDraggedTypes:@[NSFilenamesPboardType]];

    }
    return self;
}

+ (instancetype)dragViewFrame:(NSRect)frame fileTypes:(NSArray *)fileTypes imageNames:(NSArray *)imageNames
{
    return [[self alloc] initWithFrame:frame fileTypes:fileTypes imageNames:imageNames];
}

- (void)setIsSelected:(BOOL)isSelected
{
    _isSelected = isSelected;
    
    if (isSelected == YES) {
        
        _mouseLocationStatus = JZ_MouseEnter;
        
        _mousePressStatus = JZ_MouseUp;
        
    } else {
        
        _mouseLocationStatus = JZ_MouseExit;
    }
    
    [self setNeedsDisplay:YES];
}

- (void)drawRect:(NSRect)dirtyRect {
    
    [super drawRect:dirtyRect];
    
    if (_dragStatus == JZ_DragEnter) {
        
        if (_fileExist == NO) {
            
            [self drawDashBorder:dirtyRect];
            
            [self drawPlusSign:dirtyRect];
            
        }
        
        [self drawTranslucentBackground:dirtyRect];
        
    } else if (_dragStatus == JZ_DragExit) {
        
        if (_fileExist == NO) {
            
            [self drawDashBorder:dirtyRect];
            
            [self drawPlusSign:dirtyRect];
            
        } else {
            
            self.layer.backgroundColor = [NSColor colorWithWhite:0 alpha:0.1].CGColor;
            
            self.layer.cornerRadius = _radius;
            
            self.shadow = nil;

        }
        
    } else if (_dragStatus == JZ_DragEnd) {
        
        if (_fileExist == NO) {
            
            [self drawDashBorder:dirtyRect];
            
            [self drawPlusSign:dirtyRect];
                        
        } else {
            
            self.layer.backgroundColor = [NSColor colorWithWhite:0 alpha:0.1].CGColor;
            
            self.layer.cornerRadius = _radius;
            
            self.shadow = nil;
        }
    }
    
    if (_mouseLocationStatus == JZ_MouseEnter) {
        
        if (_fileExist == NO) {
            
            if (_mousePressStatus == JZ_MouseDown) {
                
                [self drawMouseDownHighlightDashBorder:dirtyRect];
                
                [self drawMouseDownHighlightPlusSign:dirtyRect];
                
            } else {
                
                [self drawMouseEnterHighlightDashBorder:dirtyRect];
                
                [self drawMouseEnterHighlightPlusSign:dirtyRect];
            }

            
        } else {
            
            self.layer.backgroundColor = [NSColor whiteColor].CGColor;

            if (_mousePressStatus == JZ_MouseUp) {
                
                if ([[[JZApplicationManager manager] firstResponder] isEqual:self]) {
                    
                    [self drawBorderMouseEnter:dirtyRect];

                } else {
                    
                    [self drawShadow];

                }
            }
        }
        
    } else {
        
        if ([[[JZApplicationManager manager] firstResponder] isEqual:self]) {
            
            if ([[JZApplicationManager manager] main] == YES) {
                
                self.layer.backgroundColor = [NSColor whiteColor].CGColor;
                
                [self drawBorderMouseExit:dirtyRect];
                
            } else {
                
                self.layer.backgroundColor = [NSColor colorWithWhite:0 alpha:0.1].CGColor;
                
            }
            
        } else {
            
            if (_fileExist == YES) {
                
                self.layer.backgroundColor = [NSColor colorWithWhite:0 alpha:0.1].CGColor;

            }
        }
    }
    
    if ([[JZApplicationManager manager] main] == NO) {
        

    }
}

#pragma mark - Destination Operations
- (NSDragOperation)draggingEntered:(id<NSDraggingInfo>)sender
{
    NSLog(@"%s" ,__FUNCTION__);
    
    _dragStatus = JZ_DragEnter;
    
    [self setNeedsDisplay:YES];
    
    return NSDragOperationCopy;
    
}

- (void)draggingExited:(id<NSDraggingInfo>)sender
{
    _dragStatus = JZ_DragExit;
    
    [self setNeedsDisplay:YES];
    
    NSLog(@"%s" ,__FUNCTION__);
    
}

- (void)draggingEnded:(id<NSDraggingInfo>)sender
{
    NSLog(@"%s" ,__FUNCTION__);
    
    _dragStatus = JZ_DragEnd;
    
    [self setNeedsDisplay:YES];
    
    if ([self.delegate respondsToSelector:@selector(draggingEndDragView:)]) {
        
        [self.delegate draggingEndDragView:self];
    }
}


- (BOOL)prepareForDragOperation:(id<NSDraggingInfo>)sender
{
    if ([sender draggingSource] != self) {
        
        NSArray *filePaths = [[sender draggingPasteboard] propertyListForType:NSFilenamesPboardType];
        
        NSString *filePath = [filePaths firstObject];
        
        NSString *fileType = [[filePath componentsSeparatedByString:@"."] lastObject];
        
        BOOL isFileTypeRight = NO;
        
        for (NSString *standardFileType in self.fileTypes) {
            
            if ([fileType isEqualToString:standardFileType]) {
                
                isFileTypeRight = YES;
                
                break;
            }
        }
        if (isFileTypeRight == YES) {
            
            _fileExist = YES;
            
            [self setImage:[NSImage imageNamed:fileType]];
            
            [self setNeedsDisplay:YES];
            
            return YES;
        }
    }
    return NO;
}

- (BOOL)performDragOperation:(id<NSDraggingInfo>)sender
{
    if ([sender draggingSource] != self) {
        
        NSArray *filePaths = [[sender draggingPasteboard] propertyListForType:NSFilenamesPboardType];
        
        if ([self.delegate respondsToSelector:@selector(dragView:throwFilePath:)]) {
            
            [self.delegate dragView:self throwFilePath:[filePaths firstObject]];
        }
        
    }
    return YES;
}

//此方法需要在改变的时候手动调用一次(父类的方法)
- (void)updateTrackingAreas
{
    NSArray *trackings = [self trackingAreas];
    for (NSTrackingArea *tracking in trackings)
    {
        [self removeTrackingArea:tracking];
    }
    
    //添加NSTrackingActiveAlways掩码可以使视图未处于激活或第一响应者时也能响应相应的方法
    NSTrackingArea *trackingArea = [[NSTrackingArea alloc] initWithRect:[self bounds]
                                                                options:NSTrackingMouseEnteredAndExited|NSTrackingMouseMoved|NSTrackingActiveAlways
                                                                  owner:self
                                                               userInfo:nil];
    [self addTrackingArea:trackingArea];
}

//重写
- (void)mouseDown:(NSEvent *)event
{
    NSLog(@"%s" ,__FUNCTION__);

    _mousePressStatus = JZ_MouseDown;
    
    [self setNeedsDisplay:YES];
    
    if ([self.delegate respondsToSelector:@selector(mouseDownDragView:)]) {
        
        [self.delegate mouseDownDragView:self];
    }
}

- (void)mouseUp:(NSEvent *)event
{
    NSLog(@"%s" ,__FUNCTION__);

    _mousePressStatus = JZ_MouseUp;
    
    if (_mouseLocationStatus == JZ_MouseExit) {
        
        return;
    }
    
    if (_fileExist == YES) {
        
        _isSelected = YES;
        
        // 非常重要，这句话使当前视图成为第一响应者，否则无法响应键盘事件
        [[NSApplication sharedApplication].keyWindow makeFirstResponder:self];
        
        [[JZApplicationManager manager] setFirstResponder:self];
        
        [[JZApplicationManager manager] refreshOutlineCellDisplay];
        
        [[JZApplicationManager manager] refreshFileDragViewDisplay];
        
    } else {
        
        [self selectFiles:self.fileTypes completion:^(NSString *filePath) {
            
            if ([filePath length] == 0) {
                
                return;
            }
            
            _fileExist = YES;
            
            NSString *fileType = [[filePath componentsSeparatedByString:@"."] lastObject];
            
            [self setImage:[NSImage imageNamed:fileType]];
            
            [self setNeedsDisplay:YES];
            
            if ([self.delegate respondsToSelector:@selector(dragView:throwFilePath:)]) {
                
                [self.delegate dragView:self throwFilePath:filePath];
            }
            
        }];
    }
    
    [self setNeedsDisplay:YES];

    if ([self.delegate respondsToSelector:@selector(mouseUpDragView:)]) {
        
        [self.delegate mouseUpDragView:self];
    }
}

- (void)mouseEntered:(NSEvent *)event
{
    NSLog(@"%s", __FUNCTION__);
    
    _mouseLocationStatus = JZ_MouseEnter;
    
    [[NSCursor pointingHandCursor] set];
    
    [self setNeedsDisplay:YES];
    
    if ([self.delegate respondsToSelector:@selector(mouseEnterDragView:)]) {
        
        [self.delegate mouseEnterDragView:self];
    }

}

- (void)mouseMoved:(NSEvent *)event
{    
    [[NSCursor pointingHandCursor] set];
}

- (void)mouseExited:(NSEvent *)event
{
    NSLog(@"%s" ,__FUNCTION__);
    
    _mouseLocationStatus = JZ_MouseExit;
    
    [[NSCursor arrowCursor] set];

    [self setNeedsDisplay:YES];
    
    if ([self.delegate respondsToSelector:@selector(mouseExitDragView:)]) {
        
        [self.delegate mouseExitDragView:self];
    }
}


- (void)keyDown:(NSEvent *)event
{
    NSLog(@"%s" ,__FUNCTION__);

    NSString *chars = [event characters];
    
    unichar character = [chars characterAtIndex: 0];
    
    if (character == NSDeleteCharacter) {
        
        self.layer.backgroundColor = [NSColor clearColor].CGColor;
        
        self.image = nil;
        
        self.shadow = nil;
        
        _fileExist = NO;
        
        [[NSApplication sharedApplication].keyWindow makeFirstResponder:nil];
        
        
        if ([self.delegate respondsToSelector:@selector(dragView:throwFilePath:)]) {
            
            [self.delegate dragView:self throwFilePath:@""];
        }
        
    } else if (character == 27) {
        
        [[NSApplication sharedApplication].keyWindow makeFirstResponder:nil];

        JZFileDragView *fileDragView = (JZFileDragView *)self.superview;

        if (_mouseLocationStatus == JZ_MouseEnter) {
            
            fileDragView.label.textColor = [NSColor blackColor];
            
            [fileDragView.label drawShadow:[NSColor lightGrayColor]];
            
        } else {
            
            fileDragView.label.textColor = [NSColor darkGrayColor];
        }
    }

    
    [self setNeedsDisplay:YES];

}

/**
 * 网上说下面这个方法必须实现并返回YES，才可以响应鼠标键盘事件，但是我发现不实现也可以，不知道有没有其他影响
 */
//- (BOOL)acceptsFirstResponder
//{
//    return YES;
//}

@end

