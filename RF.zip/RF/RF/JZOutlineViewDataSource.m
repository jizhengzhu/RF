//
//  JZOutlineViewDataSource.m
//  RF
//
//  Created by Jim on 2017/4/27.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZOutlineViewDataSource.h"

@implementation JZOutlineViewDataSource

- (NSArray *)list
{
    if (!_list) {
        
        NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"menulist" ofType:@"plist"];
        
        _list = [[NSArray alloc] initWithContentsOfFile:plistPath];
    }
    
    return _list;
}


- (BOOL)outlineView:(NSOutlineView *)outlineView isItemExpandable:(id)item
{
//    NSLog(@"1____%@", item);
    
    if ([item isKindOfClass:[NSDictionary class]]) {
        return YES;
    }else {
        return NO;
    }
}

- (NSInteger)outlineView:(NSOutlineView *)outlineView numberOfChildrenOfItem:(id)item
{
//    NSLog(@"2____%@", item);
    
    if (item == nil) {
        //item is nil when the outline view wants to inquire for root level items
        return [self.list count];
    }
    
    if ([item isKindOfClass:[NSDictionary class]]) {
        return [item[@"children"] count];
    }
    
    return 0;
}

- (id)outlineView:(NSOutlineView *)outlineView child:(NSInteger)index ofItem:(id)item
{
    
//    NSLog(@"3____%@", item);
    if (item == nil) {
        //item is nil when the outline view wants to inquire for root level items
        return [self.list objectAtIndex:index];
    }
    
    if ([item isKindOfClass:[NSDictionary class]]) {
        
        return @[item[@"children"][index], item[@"parent"]];
    }
    
    return nil;
}

- (id)outlineView:(NSOutlineView *)outlineView objectValueForTableColumn:(NSTableColumn *)theColumn byItem:(id)item
{
//    NSLog(@"4____%@", item);
//    
//    if ([[theColumn itemName] isEqualToString:@"children"]) {
//        if ([item isKindOfClass:[NSDictionary class]]) {
//            return [item objectForKey:@"parent"];
//        }
//        return item;
//    }else{
//        if ([item isKindOfClass:[NSDictionary class]]) {
//            return [item objectForKey:@"parent"];
//        }
//    }
    
    return nil;
}

- (nullable id)outlineView:(NSOutlineView *)outlineView persistentObjectForItem:(nullable id)item
{
    NSLog(@"item = %@", item);
    
    return item;

}

- (nullable id)outlineView:(NSOutlineView *)outlineView itemForPersistentObject:(id)object
{
    NSLog(@"object = %@", object);
    
    return object;
}

@end
