//
//  JZFilterView.m
//  RF
//
//  Created by Jim on 2017/4/26.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZFilterView.h"
#import "CustomSize.h"

@implementation JZFilterView

- (void)adjustBorder
{
    [self setWantsLayer:YES]; // 有这句话才能使用layer
    
    CALayer *viewLayer = [CALayer layer];
    
    viewLayer.borderColor = [NSColor lightGrayColor].CGColor;
    
    viewLayer.borderWidth = 1;
    
    viewLayer.cornerRadius = 3;
    
    viewLayer.masksToBounds = YES;
    
    [self setLayer: viewLayer];
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
    
}

@end
