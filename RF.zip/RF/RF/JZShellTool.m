//
//  JZShellTool.m
//  RF
//
//  Created by Jim on 2017/5/12.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZShellTool.h"
#import "CustomSize.h"

@implementation JZShellTool

+ (void)shellToolExec:(NSString *)cmd itemName:(NSString *)itemName
{
    // 初始化并设置shell路径
    
    NSDictionary *environmentDict = [[NSProcessInfo processInfo] environment];
    
    NSString *launchPath = [environmentDict objectForKey:@"SHELL"];
    
    NSUserUnixTask *task = [[NSUserUnixTask alloc] initWithURL:[NSURL fileURLWithPath:launchPath] error:nil];

//     新建输出管道作为Task的输出
    NSPipe *outputPipe = [NSPipe pipe];
    
    NSPipe *errorPipe = [NSPipe pipe];
    
    [task setStandardOutput:[outputPipe fileHandleForWriting]];
    
    [task setStandardError:[errorPipe fileHandleForWriting]];

    // 开始task
    [task executeWithArguments:@[@"-c", cmd] completionHandler:^(NSError *error) {
        
        NSLog(@"error = %@", error);
        
        NSString *outputString = [[NSString alloc] initWithData: [[outputPipe fileHandleForReading] readDataToEndOfFile] encoding: NSUTF8StringEncoding];
        
        NSLog(@"outputString: %@", outputString);
        
        NSString *errorString = [[NSString alloc] initWithData: [[errorPipe fileHandleForReading] readDataToEndOfFile] encoding: NSUTF8StringEncoding];
        
        NSLog(@"errorString: %@", errorString);

        NSString *notificatnName = [NSString stringWithFormat:@"%@%@", itemName, UserUnixTaskNotification];
        
        NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
        
        [userInfo setObject:outputString forKey:@"outputString"];
        
        [userInfo setObject:errorString forKey:@"errorString"];
                
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificatnName object:nil userInfo:userInfo];

        });
        
    }];

}


@end
