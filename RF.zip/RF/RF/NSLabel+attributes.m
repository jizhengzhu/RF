//
//  NSLabel+attributes.m
//  RF
//
//  Created by Jim on 2017/5/7.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "NSLabel+attributes.h"

@implementation NSLabel (attributes)

- (NSDictionary *)customAttribute
{
    NSMutableParagraphStyle *paragraphStyle = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    
    if (self.autoResize) {
        
        paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
        
    } else {
        
        paragraphStyle.lineBreakMode = self.lineBreakMode;
    }
    
    paragraphStyle.alignment = self.alignment;
    
    NSDictionary *attribute = @{NSForegroundColorAttributeName:self.textColor,
                                NSFontAttributeName:self.font,
                                NSParagraphStyleAttributeName:paragraphStyle
                                };
    
    return attribute;
}

@end
