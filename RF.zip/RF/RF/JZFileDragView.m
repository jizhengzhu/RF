//
//  JZFileDragView.m
//  RF
//
//  Created by Jim on 2017/5/9.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZFileDragView.h"
#import "JZDragView.h"
#import "NSLabel.h"
#import "CustomSize.h"

@interface JZFileDragView () <JZDragViewDelegate>

@property NSArray *fileTypes;

@property (copy) NSArray *imageNames;

@end

@implementation JZFileDragView

- (instancetype)initWithFrame:(NSRect)frame fileTypes:(NSArray *)fileTypes imageNames:(NSArray *)imageNames
{
    self = [super initWithFrame:frame];
    
    if (self) {
        
        _fileTypes = fileTypes;

        _title = [[NSLabel alloc] initWithFrame:NSMakeRect(0, self.bounds.size.height - dragviewtitleheight, self.bounds.size.width, dragviewtitleheight)];
        
        _title.font = [NSFont systemFontOfSize:15];
        
        _title.alignment = NSTextAlignmentCenter;
        
        _dragView = [JZDragView dragViewFrame:NSMakeRect(50,
                                                         (frame.size.height - dragviewtitleheight) * (1.f - goldenRatio),
                                                         (frame.size.height - dragviewtitleheight) * goldenRatio,
                                                         (frame.size.height - dragviewtitleheight) * goldenRatio)
                                    fileTypes:fileTypes
                                    imageNames:imageNames];
        
        _dragView.delegate = self;
        
        _label = [[NSLabel alloc] initWithFrame:NSMakeRect(40, 0, self.bounds.size.width - 80, (self.bounds.size.height - dragviewtitleheight) * goldenRatio * goldenRatio)];
        
        [self resetLabelText];
        
        _label.alignment = NSTextAlignmentCenter;
        
        _label.textColor = [NSColor grayColor];
        
        [self addSubview:_title];
        
        [self addSubview:_dragView];
        
        [self addSubview:_label];
    }
    
    return self;
}

+ (instancetype)fileDragViewFrame:(NSRect)frame fileTypes:(NSArray *)fileTypes imageNames:(NSArray *)imageNames
{
    return [[self alloc] initWithFrame:frame fileTypes:fileTypes imageNames:imageNames];
}

- (void)updateItemName:(NSString *)itemName
{
    _itemName = [itemName copy];
}

- (void)setFilePath:(NSString *)filePath {
    
    _filePath = [filePath copy];
    
    self.dragView.fileExist = YES;
    
    NSString *fileType = [[filePath componentsSeparatedByString:@"."] lastObject];
    
    [self.dragView setImage:[NSImage imageNamed:fileType]];
    
    self.label.textColor = [NSColor darkGrayColor];
    
    NSString *fileName = [[filePath componentsSeparatedByString:@"/"] lastObject];
    
    self.label.text = fileName;
}
    
- (void)setIsSelected:(BOOL)isSelected
{
    _isSelected = isSelected;
    
    self.dragView.isSelected = isSelected;
    
    if (isSelected == YES) {
        
        [self mouseUpDragView:self.dragView];
        
    } else {
        
        [self mouseExitDragView:self.dragView];
        
    }
}

#pragma mark - JZDragViewDelegate 方法

- (void)dragView:(JZDragView *)dragView throwFilePath:(NSString *)filePath
{
    _filePath = filePath;
    
    NSArray *array = [filePath componentsSeparatedByString:@"/"];
    
    if ([[array lastObject] length]) {
        
        self.label.text = [array lastObject];
        
        self.label.textColor = [NSColor darkGrayColor];
        
    } else {
        
        [self resetLabelText];
        
        if (dragView.mouseLocationStatus == JZ_MouseEnter) {
            
            self.label.textColor = [NSColor colorWithRed:0.05 green:0.70 blue:0.96 alpha:1.00];
            
        } else {
            
            self.label.textColor = [NSColor grayColor];
            
        }
    }
    
    if ([self.delegate respondsToSelector:@selector(fileDragView:throwFilePath:)]) {
        
        [self.delegate fileDragView:self throwFilePath:filePath];
    }
}

- (void)resetLabelText
{
    NSMutableString *text = [NSMutableString string];
    
    for (NSString *fileType in self.fileTypes) {
        
        [text appendString:[NSString stringWithFormat:@"%@、", fileType]];
    }
    self.label.text = [NSString stringWithFormat:@"%@文件名", [text substringToIndex:text.length - 1]];
    
}

- (void)mouseEnterDragView:(JZDragView *)dragView
{
    if (dragView.fileExist == YES) {
        
        self.label.textColor = [NSColor blackColor];
        
        [self.label drawShadow:[NSColor lightGrayColor]];
        
    } else {
        
        self.label.textColor = [NSColor colorWithRed:0.05 green:0.70 blue:0.96 alpha:1.00];
        
    }
}

- (void)mouseDownDragView:(JZDragView *)dragView
{
    self.label.shadow = nil;
    
    if (dragView.fileExist == YES) {
        
        self.label.textColor = [NSColor darkGrayColor];

    } else {
        
        self.label.textColor = [NSColor colorWithRed:0.43 green:0.79 blue:0.95 alpha:1.00];
    }

}

- (void)mouseUpDragView:(JZDragView *)dragView
{
    if (dragView.mouseLocationStatus == JZ_MouseEnter) {
        
        if (dragView.fileExist == YES) {
                        
            [self.label drawShadow:[NSColor lightGrayColor]];
            
            if (self.dragView.mouseLocationStatus == JZ_MouseEnter) {
                
                self.label.textColor = [NSColor blackColor];
                
            } else {
                
                self.label.textColor = [NSColor darkGrayColor];
                
            }
            
        } else {
            
            [self.label drawShadow:[NSColor colorWithRed:0.43 green:0.79 blue:0.95 alpha:1.00]];
            
        }
    } else {
        
        self.label.shadow = nil;
    }
}

- (void)mouseExitDragView:(JZDragView *)dragView
{
    self.label.shadow = nil;
    
    if (self.dragView.fileExist == NO) {
        
        self.label.textColor = [NSColor grayColor];
        
    } else {
        
        self.label.textColor = [NSColor darkGrayColor];
        
    }
}

- (void)draggingEndDragView:(JZDragView *)dragView
{
    if (dragView.mouseLocationStatus == JZ_MouseEnter) {
        
        self.label.textColor = [NSColor blackColor];
        
        [self.label drawShadow:[NSColor lightGrayColor]];
        
    }
}

@end
