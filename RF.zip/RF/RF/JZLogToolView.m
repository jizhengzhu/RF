//
//  JZLogToolView.m
//  RF
//
//  Created by Jim on 2017/4/26.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZLogToolView.h"
#import "CustomSize.h"

@implementation JZLogToolView

- (void)drawRect:(NSRect)dirtyRect {
    
    [super drawRect:dirtyRect];

    NSBezierPath *path = [NSBezierPath bezierPath];
    
    [path moveToPoint:NSMakePoint(0, toolheight - 0.5)];
    
    [path lineToPoint:NSMakePoint(dirtyRect.size.width, toolheight - 0.5)];
    
    [[NSColor lightGrayColor] setStroke];
    
    [path setLineWidth:1];
    
    [path stroke];
}

@end
