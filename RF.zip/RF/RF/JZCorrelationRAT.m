//
//  JZCorrelationRAT.m
//  RF
//
//  Created by Jim on 2017/5/9.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZCorrelationRAT.h"

@implementation JZCorrelationRAT

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
