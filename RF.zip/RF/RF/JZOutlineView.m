//
//  JZOutlineView.m
//  RF
//
//  Created by Jim on 2017/5/8.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZOutlineView.h"

@implementation JZOutlineView

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

// 防止点击JZOutlineView的时候此类成为第一响应者，但我发现然并卵
- (BOOL)acceptsFirstResponder
{
    return NO;
}

@end
