//
//  JZDailyBreakdownWiFiFrame.m
//  RF
//
//  Created by Jim on 2017/5/13.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZDailyBreakdownWiFiFrame.h"
#import "CustomSize.h"

@implementation JZDailyBreakdownWiFiFrame
{
    CGFloat margin;
}
- (instancetype)initWithRect:(NSRect)rect
{
    self = [super init];
    
    if (self) {
        
        margin = (rect.size.width - (dragviewlength + interval * 2 + 80) - 160) / 3;
        
        CGFloat dragViewX = margin;
        
        CGFloat dragViewY = rect.size.height * goldenRatio;
        
        CGFloat dragViewW = dragviewlength + interval * 2 + 80;
        
        CGFloat dragViewH = dragviewlength * (1 + goldenRatio) + dragviewtitleheight;
        
        _summaryDragViewFrame = NSMakeRect(dragViewX, dragViewY, dragViewW, dragViewH);
        
        CGFloat limitViewW = 160;
        
        CGFloat limitViewH = 80;
        
        CGFloat limitViewX = dragViewX + dragViewW + margin;
        
        CGFloat limitViewY = dragViewY + dragViewH - dragviewtitleheight - limitViewH;
        
        _limitViewFrame = NSMakeRect(limitViewX, limitViewY, limitViewW, limitViewH);
        
        CGFloat optionBtnW = 160;
        
        CGFloat optionBtnH = 40;
        
        CGFloat optionBtnX = limitViewX;
        
        CGFloat optionBtnY = limitViewY - optionBtnH;

        _optionBtnFrame = NSMakeRect(optionBtnX, optionBtnY, optionBtnW, optionBtnH);
        
        CGFloat moduleViewX = 50;
        
        CGFloat moduleViewY = 0;
        
        CGFloat moduleViewW = rect.size.width - 100;
        
        CGFloat moduleViewH = dragViewY;
        
        _moduleViewFrame = NSMakeRect(moduleViewX, moduleViewY, moduleViewW, moduleViewH);
        
    }
    
    return self;
}

@end
