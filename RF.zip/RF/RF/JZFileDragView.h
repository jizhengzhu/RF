//
//  JZFileDragView.h
//  RF
//
//  Created by Jim on 2017/5/9.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "JZDragView.h"
#import "NSLabel.h"

@class JZFileDragView;

@protocol JZFileDragViewDelegate <NSObject>

@optional
- (void)fileDragView:(JZFileDragView *)fileDragView throwFilePath:(NSString *)filePath;

@end

@class JZDragView, NSLabel;

@interface JZFileDragView : NSView

@property (nonatomic) NSLabel *title;

@property (nonatomic) JZDragView *dragView;

@property (nonatomic) NSLabel *label;

@property (readonly) NSString *itemName;

@property (copy) NSString *viewName;

@property (nonatomic, copy) NSString *filePath;

@property (weak) id <JZFileDragViewDelegate> delegate;

@property (nonatomic, readonly) NSArray *fileTypes;

@property (nonatomic) BOOL isSelected;

- (void)updateItemName:(NSString *)itemName;

- (instancetype)initWithFrame:(NSRect)frame fileTypes:(NSArray *)fileTypes imageNames:(NSArray *)imageNames;

+ (instancetype)fileDragViewFrame:(NSRect)frame fileTypes:(NSArray *)fileTypes imageNames:(NSArray *)imageNames;

@end
