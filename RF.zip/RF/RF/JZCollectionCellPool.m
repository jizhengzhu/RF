//
//  JZCollectionCellPool.m
//  RF
//
//  Created by Jim on 2017/5/10.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZCollectionCellPool.h"
#import "JZCollectionCell.h"

@interface JZCollectionCellPool ()

@property (nonatomic) NSMutableDictionary *collectionCellPool;

@end

@implementation JZCollectionCellPool

- (NSMutableDictionary *)collectionCellPool
{
    if (!_collectionCellPool) {
        
        _collectionCellPool = [NSMutableDictionary dictionary];
    }
    return _collectionCellPool;
}

- (void)addCollectionCell:(JZCollectionCell *)collectionCell
{
    NSString *key = [NSString stringWithFormat:@"%@%@", collectionCell.itemName, collectionCell.cellName];
    [self.collectionCellPool setObject:collectionCell forKey:key];
}

- (JZCollectionCell *)findCollectionCellByKey:(NSString *)key
{
    return [self.collectionCellPool objectForKey:key];
}

- (void)refreshCollectionCellDisplayWithFirstResponder:(id)firstResponder
{
    
    if ([firstResponder isKindOfClass:[JZCollectionCell class]]) {
        
        NSString *string = [NSString stringWithFormat:@"%@%@", [firstResponder itemName], [firstResponder cellName]];
        
        for (NSString *key in self.collectionCellPool) {
            
            JZCollectionCell *collectionCell = [self findCollectionCellByKey:key];
            
            if ([string isEqualToString:key]) {
                
                collectionCell.mouseLocation = JZCollectionCell_MouseEnter;
                
            } else {
                
                collectionCell.mouseLocation = JZCollectionCell_MouseExit;
                
            }
            
            [collectionCell resetColor];
            
        }
    }

}

@end
