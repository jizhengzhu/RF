//
//  JZDailyBreakdownInsertConfig.h
//  RF
//
//  Created by Jim on 2017/5/5.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZMainView.h"

@class NSLabel, JZDailyBreakdownInsertConfigFrame, JZFileDragView, JZModuleView;

@interface JZDailyBreakdownInsertConfig : JZMainView

@property (nonatomic) JZDailyBreakdownInsertConfigFrame *myFrame;

@property (nonatomic) JZFileDragView *antennaInformationView;

@property (nonatomic) JZFileDragView *rawDataView;

@property (nonatomic) JZModuleView *moduleView;

@end
