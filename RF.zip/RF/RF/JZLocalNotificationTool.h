//
//  JZLocalNotificationTool.h
//  RF
//
//  Created by Jim on 2017/5/12.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZLocalNotificationTool : NSObject 

+ (NSUserNotification *)postNotificationWithTitle:(NSString *)title
                                         subtitle:(NSString *)subtitle
                                  informativeText:(NSString *)informativeText
                                       itemName:(NSString *)itemName
                              removedNotification:(NSUserNotification *)removedNotification;

@end
