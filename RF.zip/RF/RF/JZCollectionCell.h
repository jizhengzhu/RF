//
//  JZCollectionCell.h
//  RF
//
//  Created by Jim on 2017/5/10.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

typedef NS_ENUM(NSInteger, JZCollectionCellMouseLocation) {
    
    JZCollectionCell_MouseExit = 0,
    
    JZCollectionCell_MouseEnter = 1,
};

typedef NS_ENUM(NSInteger, JZCollectionCellMouseStatus) {
    
    JZCollectionCell_MouseUp = 0,
    
    JZCollectionCell_MouseDown = 1,
};

@interface JZCollectionCell : NSView

@property (nonatomic, copy) NSString *text;

@property (readonly) NSString *itemName;

@property (copy) NSString *cellName;

@property JZCollectionCellMouseLocation mouseLocation;

@property JZCollectionCellMouseStatus mouseStatus;

@property BOOL isSelected;

- (void)resetColor;

- (void)updateItemName:(NSString *)itemName;

@end
