//
//  JZLimitView.h
//  RF
//
//  Created by Jim on 2017/5/14.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface JZLimitView : NSView

@property (nonatomic) NSTableView *tbView;

@property (nonatomic) NSArray *dataArray;

@property (readonly) NSString *itemName;

- (void)updateItemName:(NSString *)itemName;

@end
