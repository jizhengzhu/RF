//
//  JZDragView+selectFiles.m
//  RF
//
//  Created by Jim on 2017/5/6.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZDragView+selectFiles.h"

@implementation JZDragView (selectFiles)

- (void)selectFiles:(NSArray *)fileTypes completion:(void (^)(NSString *))completion
{
    __block NSString *path = @"";
    
    NSOpenPanel *panel = [NSOpenPanel openPanel]; // afaf
    
    [panel setCanChooseDirectories:NO];
    
    [panel setCanCreateDirectories:YES];
    
    [panel setAllowsMultipleSelection:NO];
    
    [panel setCanChooseFiles:YES];
    
    [panel setAllowedFileTypes:fileTypes];
    
    [panel beginSheetModalForWindow:self.window completionHandler:^(NSInteger result) {
        
        if (result == NSModalResponseOK)
        {
            NSArray *selectedFiles = [panel URLs];
            
            path= [[selectedFiles objectAtIndex:0] absoluteString];
            
            path = [[path substringFromIndex:7] stringByRemovingPercentEncoding];
        }
        completion(path);
    }];
    
}

@end
