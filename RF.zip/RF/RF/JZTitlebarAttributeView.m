//
//  JZTitlebarAttributeView.m
//  RF
//
//  Created by Jim on 2017/4/26.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZTitlebarAttributeView.h"
#import "CustomSize.h"
#import "JZApplicationManager.h"
#import "CustomWindowButtonView.h"

@implementation JZTitlebarAttributeView

- (CustomWindowButtonView *)windowButtonView
{
    if (!_windowButtonView) {
        
        _windowButtonView = [[CustomWindowButtonView alloc] initWithFrame:NSMakeRect(10, 11, 55, 16)];
    }
    return _windowButtonView;
}

- (NSButton *)runBtn
{
    if (!_runBtn) {
        
        _runBtn = [[NSButton alloc] initWithFrame:NSMakeRect(90, 5, 42, 28)];
        
        [_runBtn setBordered:YES];
        
        [_runBtn setImage:[NSImage imageNamed:@"run"]];
        
        [_runBtn setImageScaling:NSImageScaleProportionallyDown];
        
        [_runBtn setBezelStyle:NSBezelStyleRegularSquare];
        
        [_runBtn setButtonType:NSButtonTypeOnOff];
        
        [_runBtn setAllowsMixedState:NO];
        
        [_runBtn setTarget:self];
        
        [_runBtn setAction:@selector(runPythonFile)];
    }
    
    return _runBtn;
}

- (NSButton *)leftBtn
{
    if (!_leftBtn) {
        
        _leftBtn = [[NSButton alloc] initWithFrame:NSMakeRect(155, 5, 33, 28)];
        
        [_leftBtn setBordered:YES];
        
        [_leftBtn setImage:[NSImage imageNamed:@"leftarrow"]];
        
        [_leftBtn setImageScaling:NSImageScaleProportionallyDown];
        
        [_leftBtn setBezelStyle:NSBezelStyleRegularSquare];
        
        [_leftBtn setButtonType:NSButtonTypeMomentaryLight];
        
        [_leftBtn setTarget:self];
        
        [_leftBtn setAction:@selector(clickBtn:)];
        
        _leftBtn.tag = 100;
        
    }
    
    return _leftBtn;
}

- (NSButton *)rightBtn
{
    if (!_rightBtn) {
        
        _rightBtn = [[NSButton alloc] initWithFrame:NSMakeRect(182.5, 5, 33, 28)];
        
        [_rightBtn setBordered:YES];
        
        [_rightBtn setImage:[NSImage imageNamed:@"rightarrow"]];
        
        [_rightBtn setImageScaling:NSImageScaleProportionallyDown];
        
        [_rightBtn setBezelStyle:NSBezelStyleRegularSquare];
        
        [_rightBtn setButtonType:NSButtonTypeMomentaryLight];
        
        [_rightBtn setTarget:self];
        
        [_rightBtn setAction:@selector(clickBtn:)];
        
        _rightBtn.tag = 200;
        
    }
    
    return _rightBtn;
}

- (NSTextField *)titleTF
{
    if (!_titleTF) {
        
        CGFloat width = self.window.frame.size.width / 4;
        
        CGFloat height = 25;
        
        CGFloat x = (self.window.frame.size.width - width) / 2;
        
        CGFloat y = 6;
        
        _titleTF = [[NSTextField alloc] initWithFrame:NSMakeRect(x, y, width, height)];
        
        _titleTF.alignment = NSTextAlignmentCenter;
        
        _titleTF.stringValue = @"RF";
        
        _titleTF.backgroundColor = [NSColor clearColor];
        
        _titleTF.editable = NO;
        
    }
    return _titleTF;
}

- (NSButton *)resizeButton
{
    if (!_resizeButton) {
        
        _resizeButton = [[NSButton alloc] initWithFrame:NSMakeRect(self.frame.size.width - 60, 3.5, 35, 30)];
        
        [_resizeButton setBordered:YES];
        
        [_resizeButton setImage:[NSImage imageNamed:@"resize"]];
        
        [_resizeButton setImageScaling:NSImageScaleProportionallyDown];
        
        [_resizeButton setBezelStyle:NSBezelStyleRegularSquare];
        
        [_resizeButton setButtonType:NSButtonTypeMomentaryLight];
    }
    return _resizeButton;
}

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self addSubview:self.windowButtonView];
        
        [self addSubview:self.runBtn];
        
        [self addSubview:self.leftBtn];
        
        [self addSubview:self.rightBtn];
        
        [self addSubview:self.titleTF];
        
        self.wantsLayer = YES;
        
        self.layer.backgroundColor = [NSColor colorWithRed:0.11 green:0.38 blue:0.22 alpha:1.00].CGColor;
        
        [self judgeLeftOrRightButtonEnable];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(outlineCellMouseDown:) name:JZOutlineCellNotification object:nil];

    }
    return self;
}

- (void)setFrame:(NSRect)frame
{
    [super setFrame:frame];
    
    CGFloat width = frame.size.width / 4;
    
    CGFloat height = 25;
    
    CGFloat x = (frame.size.width - width) / 2;
    
    CGFloat y = 6;
    
    self.titleTF.frame = NSMakeRect(x, y, width, height);
    
    self.resizeButton.frame = NSMakeRect(self.frame.size.width - 40, 3.5, 35, 30);
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

- (void)clickBtn:(NSButton *)btn
{
    NSMutableArray *array = [[JZApplicationManager manager] pageManagerArray];
    
    if (btn.tag == 100) {
        
        [[JZApplicationManager manager] increaseIndex];

    } else {
        
        [[JZApplicationManager manager] decreaseIndex];
    }
    
    [self judgeLeftOrRightButtonEnable];
    
    NSInteger index = [[JZApplicationManager manager] index];
    
    NSString *itemName = array[array.count - 1 - index];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:JZTitlebarLeftOrRightBtnNotification object:nil userInfo:@{keyItemName:itemName}];

}

- (void)judgeLeftOrRightButtonEnable
{
    NSMutableArray *array = [[JZApplicationManager manager] pageManagerArray];

    NSInteger index = [[JZApplicationManager manager] index];
    
    if (array.count == 1) {
        
        [self.leftBtn setEnabled:NO];
        
        [self.rightBtn setEnabled:NO];
        
    } else if (index == 0) {
        
        [self.rightBtn setEnabled:NO];
        
        [self.leftBtn setEnabled:YES];

    } else if (index == array.count - 1) {
        
        
        [self.rightBtn setEnabled:YES];
        
        [self.leftBtn setEnabled:NO];
        
    } else if (index > 0 && index < array.count - 1) {
        
        [self.rightBtn setEnabled:YES];
        
        [self.leftBtn setEnabled:YES];
        
    } else {
        
        [self.rightBtn setEnabled:NO];
        
        [self.leftBtn setEnabled:NO];
    }
}

- (void)runPythonFile
{
    NSString *itemName = [[NSUserDefaults standardUserDefaults] objectForKey:keyItemName];
    
    NSString *notificationName = [NSString stringWithFormat:@"%@%@", itemName, RunPythonFileNotification];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationName object:nil];
}

#pragma mark - NSNotificationCenter 
- (void)outlineCellMouseDown:(NSNotification *)note
{
    [self judgeLeftOrRightButtonEnable];
}

#pragma mark - dealloc
- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:JZOutlineCellNotification object:nil];
}

@end
