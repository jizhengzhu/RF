//
//  NSLabel+wrapperBackground.m
//  RF
//
//  Created by Jim on 2017/5/7.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "NSLabel+wrapperBackground.h"
#import "NSLabel+separateLines.h"
#import "NSLabel+attributes.h"

typedef NS_ENUM(NSInteger, JZWrapperDirection) {
    
    JZ_WrapperCenter = 0,
    
    JZ_WrapperLeft = 1,
    
    JZ_WrapperRight = 2,
};

@interface NSLabel ()
{
    JZWrapperDirection _wrapperDirection;
}

@end

@implementation NSLabel (wrapperBackground)

- (void)drawWrapperBackground:(NSRect)dirtyRect cornerRadius:(CGFloat)cornerRadius
{
    NSArray *lines = [NSArray array];
    
    if (self.text) {
        
        lines = [self getSeparatedLines];

    }
//    NSLog(@"lines = %@", lines);
    
    NSDictionary *attribute = [self customAttribute];
    
    NSMutableArray *rectArray = [NSMutableArray array];
    
    for (int i = 0; i < lines.count; i++) {
        
        NSString *line = lines[i];
        
        NSSize textSize = [line boundingRectWithSize:dirtyRect.size options:NSStringDrawingUsesLineFragmentOrigin attributes:attribute].size;
        
        CGFloat x = (self.bounds.size.width - textSize.width) / 2;
        
        CGFloat y = (lines.count - i - 1) * textSize.height;
        
        NSRect textRect = NSMakeRect(x, y, textSize.width, textSize.height);
        
        [rectArray addObject:NSStringFromRect(textRect)];
    }
    
//    NSLog(@"rectArray = %@", rectArray);
    
    [self.wrapperBackgroundColor setFill];
    
    NSBezierPath *path = [NSBezierPath bezierPath];
    
    if (rectArray.count > 0) {
        
        NSRect firstRect = NSRectFromString(rectArray[rectArray.count - 1]);
        
        NSPoint firstCenter = NSMakePoint(firstRect.origin.x + cornerRadius, firstRect.origin.y + cornerRadius);
        
        [path appendBezierPathWithArcWithCenter:firstCenter radius:cornerRadius startAngle:-90 endAngle:180 clockwise:YES];
        
        if (rectArray.count > 1) {
            
            NSRect firstNextRect = NSRectFromString(rectArray[rectArray.count - 2]);
            
            if (firstRect.size.width > firstNextRect.size.width) {
                
                NSPoint firstNextCenter = NSMakePoint(firstRect.origin.x + cornerRadius, firstRect.origin.y + firstRect.size.height - cornerRadius);
                
                [path appendBezierPathWithArcWithCenter:firstNextCenter radius:cornerRadius startAngle:180 endAngle:90 clockwise:YES];

            } else if (firstRect.size.width < firstNextRect.size.width) {
                
                NSPoint firstNextCenter = NSMakePoint(firstRect.origin.x - cornerRadius, firstRect.origin.y + firstRect.size.height - cornerRadius);
                
                [path appendBezierPathWithArcWithCenter:firstNextCenter radius:cornerRadius startAngle:0 endAngle:90 clockwise:NO];
            } else {
                
                // do nothing
            }
        }
        
        for (NSInteger i = rectArray.count - 2; i > 0; i--) {
            
            NSRect previousRect = NSRectFromString(rectArray[i + 1]);
            
            NSRect rect = NSRectFromString(rectArray[i]);

            if (previousRect.size.width > rect.size.width) {
                
                NSPoint previousCenter = NSMakePoint(rect.origin.x - cornerRadius, rect.origin.y + cornerRadius);
                
                [path appendBezierPathWithArcWithCenter:previousCenter radius:cornerRadius startAngle:-90 endAngle:0 clockwise:NO];
                
            } else if (previousRect.size.width < rect.size.width) {
                
                NSPoint previousCenter = NSMakePoint(rect.origin.x + cornerRadius, rect.origin.y + cornerRadius);
                
                [path appendBezierPathWithArcWithCenter:previousCenter radius:cornerRadius startAngle:-90 endAngle:180 clockwise:YES];
            }
            
            if (i - 1 > 0) {
                
                NSRect nextRect = NSRectFromString(rectArray[i - 1]);
                
                if (rect.size.width > nextRect.size.width) {
                    
                    NSPoint nextCenter = NSMakePoint(rect.origin.x + cornerRadius, rect.origin.y + rect.size.height - cornerRadius);
                    
                    [path appendBezierPathWithArcWithCenter:nextCenter radius:cornerRadius startAngle:180 endAngle:90 clockwise:YES];
                    
                } else if (rect.size.width < nextRect.size.width) {
                    
                    NSPoint nextCenter = NSMakePoint(rect.origin.x - cornerRadius, rect.origin.y + rect.size.height - cornerRadius);
                    
                    [path appendBezierPathWithArcWithCenter:nextCenter radius:cornerRadius startAngle:0 endAngle:90 clockwise:NO];
                } else {
                    
                    // do nothing
                }
            }
        }
        
        NSRect lastRect = NSRectFromString(rectArray[0]);
        
        NSPoint lastCenter = NSMakePoint(lastRect.origin.x + cornerRadius, lastRect.origin.y + lastRect.size.height - cornerRadius);
        
        [path appendBezierPathWithArcWithCenter:lastCenter radius:cornerRadius startAngle:180 endAngle:90 clockwise:YES];
        
        
        NSRect rightFirstRect = NSRectFromString(rectArray[0]);
        
        NSPoint rightFirstCenter = NSMakePoint(rightFirstRect.origin.x + rightFirstRect.size.width - cornerRadius, rightFirstRect.origin.y + rightFirstRect.size.height - cornerRadius);
        
        [path appendBezierPathWithArcWithCenter:rightFirstCenter radius:cornerRadius startAngle:90 endAngle:0 clockwise:YES];
        
        if (rectArray.count > 1) {
            
            NSRect rightFirstNextRect = NSRectFromString(rectArray[1]);
            
            if (rightFirstRect.size.width > rightFirstNextRect.size.width) {
                
                NSPoint rightNextCenter = NSMakePoint(rightFirstRect.origin.x + rightFirstRect.size.width - cornerRadius, rightFirstRect.origin.y + cornerRadius);
                
                [path appendBezierPathWithArcWithCenter:rightNextCenter radius:cornerRadius startAngle:0 endAngle:-90 clockwise:YES];
                
            } else if (rightFirstRect.size.width < rightFirstNextRect.size.width) {
                
                NSPoint rightNextCenter = NSMakePoint(rightFirstRect.origin.x + rightFirstRect.size.width + cornerRadius, rightFirstRect.origin.y + cornerRadius);
                
                [path appendBezierPathWithArcWithCenter:rightNextCenter radius:cornerRadius startAngle:0 endAngle:90 clockwise:NO];
            } else {
                
                // do nothing
            }
        }
        
        for (int i = 1; i < rectArray.count - 1; i++) {
            
            NSRect rightPreviousRect = NSRectFromString(rectArray[i - 1]);
            
            NSRect rightRect = NSRectFromString(rectArray[i]);
            
            if (rightPreviousRect.size.width > rightRect.size.width) {
                
                NSPoint rightPreviousCenter = NSMakePoint(rightRect.origin.x + rightRect.size.width + cornerRadius, rightRect.origin.y + rightRect.size.height - cornerRadius);
                
                [path appendBezierPathWithArcWithCenter:rightPreviousCenter radius:cornerRadius startAngle:90 endAngle:180 clockwise:NO];
                
            } else if (rightPreviousRect.size.width < rightRect.size.width) {
                
                NSPoint rightPreviousCenter = NSMakePoint(rightRect.origin.x + rightRect.size.width - cornerRadius, rightRect.origin.y + rightRect.size.height - cornerRadius);
                
                [path appendBezierPathWithArcWithCenter:rightPreviousCenter radius:cornerRadius startAngle:90 endAngle:0 clockwise:YES];
            }
            
            if (i + 1 < rectArray.count - 1) {
                
                NSRect rightNextRect = NSRectFromString(rectArray[i + 1]);
                
                if (rightRect.size.width > rightNextRect.size.width) {
                    
                    NSPoint rightNextCenter = NSMakePoint(rightRect.origin.x + rightRect.size.width - cornerRadius, rightRect.origin.y - cornerRadius);
                    
                    [path appendBezierPathWithArcWithCenter:rightNextCenter radius:cornerRadius startAngle:0 endAngle:-90 clockwise:YES];
                    
                } else if (rightRect.size.width < rightNextRect.size.width) {
                    
                    NSPoint rightNextCenter = NSMakePoint(rightRect.origin.x + rightRect.size.width + cornerRadius, rightRect.origin.y + cornerRadius);
                    
                    [path appendBezierPathWithArcWithCenter:rightNextCenter radius:cornerRadius startAngle:180 endAngle:-90 clockwise:NO];
                } else {
                    
                    // do nothing
                }
            }
        }
        
        NSRect rightLastRect = NSRectFromString(rectArray[rectArray.count - 1]);
        
        NSPoint rightLastCenter = NSMakePoint(rightLastRect.origin.x + rightLastRect.size.width - cornerRadius, rightLastRect.origin.y + cornerRadius);
        
        [path appendBezierPathWithArcWithCenter:rightLastCenter radius:cornerRadius startAngle:0 endAngle:-90 clockwise:YES];
        
    }
    
    [path fill];
    
}


@end
