//
//  JZInsertView.m
//  RF
//
//  Created by Jim on 2017/5/10.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZInsertView.h"
#import "JZInsertBtn.h"
#import "JZDailyBreakdownInsertConfig.h"
#import "JZModuleView.h"
#import <QuartzCore/QuartzCore.h>
#import "CustomSize.h"
#import "JZDailyBreakdownInsertConfigFrame.h"
#import "JZAlertTool.h"

@interface JZInsertView() <NSTextFieldDelegate, NSControlTextEditingDelegate, JZInsertBtnDelegate, CAAnimationDelegate>
{
    NSString *_animationNotificationName;
    
    CGSize _smallsize, _bigsize;
}
@end

@implementation JZInsertView

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
    
    NSRect rect = NSMakeRect(0.5, 0.5, dirtyRect.size.width - 1, dirtyRect.size.height - 1);
    
    NSBezierPath *path = [NSBezierPath bezierPathWithRoundedRect:rect xRadius:3 yRadius:3];
    
    path.lineWidth = 1;
    
    [[NSColor colorWithRed:0.11 green:0.38 blue:0.22 alpha:1.00] setFill];
    // [[NSColor colorWithWhite:0 alpha:0.4] setFill];
    
    [path fill];
    
}

- (NSTextField *)insertTextField
{
    if (!_insertTextField) {
                
        _insertTextField = [[NSTextField alloc] initWithFrame:NSMakeRect(23, 4, self.superview.bounds.size.width * goldenRatio - dragviewtitleheight, 18)];
        
        _insertTextField.bordered = NO;
        
        _insertTextField.drawsBackground = NO;
        
        _insertTextField.placeholderAttributedString = [[NSAttributedString alloc] initWithString:@"input item name" attributes:@{NSForegroundColorAttributeName:[NSColor grayColor]}];
        
        _insertTextField.focusRingType = NSFocusRingTypeNone;
        
        _insertTextField.delegate = self;
        
        _insertTextField.textColor = [NSColor whiteColor];
    
    }
    return _insertTextField;
}

- (JZInsertBtn *)insertBtn
{
    if (!_insertBtn) {
        
        _insertBtn = [[JZInsertBtn alloc] initWithFrame:NSMakeRect(0, 0, insertviewheight, insertviewheight)];
        
        _insertBtn.image = [NSImage imageNamed:@"insertnormal"];
        
        _insertBtn.delegate = self;
    }
    
    return _insertBtn;
}

- (void)setFrame:(NSRect)frame
{
    [super setFrame:frame];
    
    // 注意 layer 的 frame 和 self 的 frame 不一样
    
    _smallsize = CGSizeMake(insertviewheight, insertviewheight);

    _bigsize = CGSizeMake(self.superview.bounds.size.width * goldenRatio, insertviewheight);
        
    if (CGSizeEqualToSize(frame.size, _smallsize) == true) {
        
        [self.insertTextField removeFromSuperview];
        
        [self.insertBtn.layer removeAllAnimations];
        
        [self.layer removeAllAnimations];
                
        [self.insertBtn setImage:[NSImage imageNamed:@"insertnormal"]];

        _isShrink = YES;
        
    }
    
    [self setNeedsDisplay:YES];
    
}

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self addSubview:self.insertBtn];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textFieldDidChange:) name:NSControlTextDidChangeNotification object:nil];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textFieldDidEndEditing:) name:NSControlTextDidEndEditingNotification object:nil];
        
    }
    return self;
}

- (void)updateItemName:(NSString *)itemName
{
    _itemName = [itemName copy];
    
    _animationNotificationName = [NSString stringWithFormat:@"%@%@", itemName, AnimationNotification];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(displayAnimation) name:_animationNotificationName object:nil];
}

#pragma mark - NSNotificationCenter

- (void)textFieldDidChange:(NSNotification *)note
{
    NSLog(@"%s", __FUNCTION__);
    
    if (self.insertTextField.stringValue.length > 0) {
        
        [self.insertBtn setImage:[NSImage imageNamed:@"inserthighlightMouseDown"]];
        
    } else {
        
        [self.insertBtn setImage:[NSImage imageNamed:@"insertnormal"]];
    }
}

- (void)textFieldDidEndEditing:(NSNotification *)note
{
    NSLog(@"%s", __FUNCTION__);
    
    JZModuleView *moduleView = (JZModuleView *)self.superview;
    
    if ([self.insertTextField.stringValue containsString:@","]) {
        
        [JZAlertTool showAlertWithMessageText:@"Please input again" informativeText:@"The string you input should not contain commas" window:self.window];
        
        return;
    }
    
    if (self.insertTextField.stringValue.length > 0) {
        
        [moduleView.collectionScrollView addModuleWithModuleName:self.insertTextField.stringValue];

    }
}

#pragma mark - JZInsertBtnDelegate

- (void)mouseDownInsertBtn:(JZInsertBtn *)insertBtn
{
    [insertBtn setImage:[NSImage imageNamed:@"inserthighlightMouseDown"]];
}

- (void)mouseUpInsertBtn:(JZInsertBtn *)insertBtn
{
    [insertBtn setImage:[NSImage imageNamed:@"insertnormal"]];

    [self.insertBtn.layer addAnimation:[self makeFadeAnimation] forKey:nil];
    
    self.insertBtn.layer.anchorPoint = CGPointMake(0.5, 0.5); // Default
    
    self.insertBtn.layer.position = CGPointMake(insertviewheight / 2, insertviewheight / 2);
    
    [self.insertBtn.layer addAnimation:[self makeRotationAnimation] forKey:nil];
    
    [self.layer addAnimation:[self makeBoundsAnimation] forKey:nil];
    
    self.insertTextField.stringValue = @"";
    
}

- (CAAnimation *)makeFadeAnimation
{
    CATransition *animation = [CATransition animation];
    
    animation.duration = 1;
    
    [animation setFillMode:kCAFillModeForwards];
    
    [animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault]];
    
    //    [animation setType:@"rippleEffect"];
    
    return animation;
}

- (CABasicAnimation *)makeRotationAnimation
{
    CABasicAnimation *transformAnimation = [CABasicAnimation animationWithKeyPath:@"transform"];
    
    NSValue *transformFrom, *transformTo;
    
    if (CGSizeEqualToSize(self.frame.size, _smallsize) == true) {
        
        transformFrom = [NSValue valueWithCATransform3D:CATransform3DIdentity];
        
        transformTo = [NSValue valueWithCATransform3D:CATransform3DMakeRotation(-0.78, 0.0, 0.0, 1.0)];
        
    } else {
        
        transformFrom = [NSValue valueWithCATransform3D:CATransform3DMakeRotation(-0.78, 0.0, 0.0, 1.0)];
        
        transformTo = [NSValue valueWithCATransform3D:CATransform3DIdentity];
        
    }
    
    transformAnimation.fromValue = transformFrom;
    
    transformAnimation.toValue = transformTo;
    
    transformAnimation.duration = 0.3;
    
    transformAnimation.removedOnCompletion = NO;
    
    transformAnimation.fillMode = kCAFillModeForwards;
    
    return transformAnimation;

}

- (CABasicAnimation *)makeBoundsAnimation
{
    
    NSLog(@"___self.frame = %@", NSStringFromRect(self.frame));
    
    CABasicAnimation *boundsAnimation = [CABasicAnimation animationWithKeyPath:@"bounds"];
    
    NSValue *boundsFrom, *boundsTo;
    
    if (CGSizeEqualToSize(self.frame.size, _smallsize) == true) {
        
        boundsFrom = [NSValue valueWithRect:NSMakeRect(0, 0, _smallsize.width, _smallsize.height)];
        
        boundsTo = [NSValue valueWithRect:NSMakeRect(0, 0, _bigsize.width, _bigsize.height)];
        
    } else {
        
        boundsFrom = [NSValue valueWithRect:NSMakeRect(0, 0, _bigsize.width, _bigsize.height)];
        
        boundsTo = [NSValue valueWithRect:NSMakeRect(0, 0, _smallsize.width, _smallsize.height)];
        
    }
    boundsAnimation.fromValue = boundsFrom;
    
    boundsAnimation.toValue = boundsTo;
    
    boundsAnimation.duration = 0.3;
    
    boundsAnimation.removedOnCompletion = NO;
    
    boundsAnimation.fillMode = kCAFillModeForwards;
    
    boundsAnimation.delegate = self;
    
    return boundsAnimation;
}

#pragma mark - CAAnimationDelegate 

- (void)animationDidStart:(CAAnimation *)anim
{
    self.frame = NSMakeRect(self.frame.origin.x, self.frame.origin.y, _bigsize.width, _bigsize.height);
    
    if (_isShrink == YES) {
        
        [self.insertTextField removeFromSuperview];
    }

}

- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
{
    if (flag == YES) {
        
        if (_isShrink == YES) {
            
            self.frame = NSMakeRect(self.frame.origin.x, self.frame.origin.y, _bigsize.width, _bigsize.height);
            
            [self addSubview:self.insertTextField];
            
            _isShrink = NO;
            
        } else {
            
            self.frame = NSMakeRect(self.frame.origin.x, self.frame.origin.y, _smallsize.width, _smallsize.height);
            
            _isShrink = YES;
        }
    }
}

#pragma mark - NSNotification
- (void)displayAnimation
{
    if (CGSizeEqualToSize(self.frame.size, _smallsize) == true) {
        
        [self mouseUpInsertBtn:self.insertBtn];

    }

}


#pragma mark - dealloc
- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NSControlTextDidChangeNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NSControlTextDidEndEditingNotification object:nil];

    [[NSNotificationCenter defaultCenter] removeObserver:self name:_animationNotificationName object:nil];
}

























@end
