//
//  NSLabel+attributes.h
//  RF
//
//  Created by Jim on 2017/5/7.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "NSLabel.h"

@interface NSLabel (attributes)

- (NSDictionary *)customAttribute;

@end
