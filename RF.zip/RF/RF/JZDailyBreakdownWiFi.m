//
//  JZDailyBreakdownWiFi.m
//  RF
//
//  Created by Jim on 2017/5/5.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZDailyBreakdownWiFi.h"
#import "JZFileDragView.h"
#import "JZLimitView.h"
#import "JZDailyBreakdownWiFiFrame.h"
#import "JZModuleView.h"
#import "NSLabel.h"
#import "CustomSize.h"
#import "JZShellTool.h"
#import "JZLocalNotificationTool.h"
#import "JZAlertTool.h"
#import "JZApplicationManager.h"

@interface JZDailyBreakdownWiFi () <JZFileDragViewDelegate, NSAlertDelegate, NSUserNotificationCenterDelegate>
{
    NSString *_summaryFilePath;
    
    NSString *_notificationTitle;
    
    NSString *_notificationSubtitle;
    
    NSString *_notificationInformativeText;
    
    NSUserNotification *_removedNotification;
}

@end

@implementation JZDailyBreakdownWiFi

- (JZDailyBreakdownWiFiFrame *)myFrame
{
    if (!_myFrame) {
        
        _myFrame = [[JZDailyBreakdownWiFiFrame alloc] initWithRect:self.bounds];
    }
    return _myFrame;
}

- (JZFileDragView *)summaryDragView
{
    if (!_summaryDragView) {
        
        _summaryDragView = [JZFileDragView fileDragViewFrame:self.myFrame.summaryDragViewFrame fileTypes:@[@"xlsx"] imageNames:@[@"xlsx"]];
        
        _summaryDragView.title.text = @"Summary File Here";
        
        _summaryDragView.delegate = self;
        
        _summaryDragView.viewName = @"Summary";
        
        [[[JZApplicationManager manager] fileDragViewPool] addFileDragView:_summaryDragView];
    }
    
    return _summaryDragView;
}

- (JZLimitView *)limitView
{
    if (!_limitView) {
        
        _limitView = [[JZLimitView alloc] initWithFrame:self.myFrame.limitViewFrame];
        
        NSString *path = [[NSBundle mainBundle] pathForResource:@"WiFiLimitList" ofType:@"plist"];
        
        NSArray *array = [NSArray arrayWithContentsOfFile:path];
        
        _limitView.dataArray = array;
        
    }
    
    return _limitView;
}

- (NSButton *)optionBtn
{
    if (!_optionBtn) {
        
        _optionBtn = [[NSButton alloc] initWithFrame:self.myFrame.optionBtnFrame];
        
        [_optionBtn setButtonType:NSButtonTypeSwitch];
        
        [_optionBtn setTitle:@"PathLoss Summary"];
    }
    
    return _optionBtn;
}

- (JZModuleView *)moduleView
{
    if (!_moduleView) {
        
        _moduleView = [[JZModuleView alloc] initWithFrame:self.myFrame.moduleViewFrame];
    }
    
    return _moduleView;
}

- (void)setFrame:(NSRect)frame
{
    [super setFrame:frame];
    
    _myFrame = [[JZDailyBreakdownWiFiFrame alloc] initWithRect:self.bounds];
    
    self.summaryDragView.frame = _myFrame.summaryDragViewFrame;
    
    self.limitView.frame = _myFrame.limitViewFrame;
    
    self.optionBtn.frame = _myFrame.optionBtnFrame;
    
    self.moduleView.frame = _myFrame.moduleViewFrame;
}

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self addSubview:self.summaryDragView];
        
        [self addSubview:self.limitView];
        
        [self addSubview:self.optionBtn];
        
        [self addSubview:self.moduleView];
        
        [[NSUserNotificationCenter defaultUserNotificationCenter] setDelegate:self];
    }
    return self;
}

- (void)updateItemName:(NSString *)itemName
{
    self.itemName = [itemName copy];
    
    NSString *key = [NSString stringWithFormat:@"%@%@", itemName, ModuleArrayKey];
    
    NSMutableArray *mArray = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    
    if (mArray == nil) {
        
        NSString *path = [[NSBundle mainBundle] pathForResource:@"WiFiModule" ofType:@"plist"];
        
        NSArray *array = [NSArray arrayWithContentsOfFile:path];
        
        NSMutableArray *moduleArray = [NSMutableArray arrayWithArray:array];
        
        [[NSUserDefaults standardUserDefaults] setObject:moduleArray forKey:key];
        
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    
    [self.moduleView updateItemName:itemName];
    
    NSString *notificationName = [NSString stringWithFormat:@"%@%@", itemName, UserUnixTaskNotification];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(runPythonCompletion:) name:notificationName object:nil];
    
    NSString *summaryKey = [NSString stringWithFormat:@"%@%@%@", self.itemName, self.summaryDragView.viewName, FilePathKey];
    
    _summaryFilePath = [[NSUserDefaults standardUserDefaults] objectForKey:summaryKey];
    
    if (_summaryFilePath.length > 0) {
        
        self.summaryDragView.filePath = _summaryFilePath;
        
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateSummaryFilePath:) name:JZDailyBreakdownInsertConfigCreateSucceededNotification object:nil];
}

/**
 *  父类方法
 */
- (void)runPythonFile
{
    NSLog(@"%s", __FUNCTION__);
    
    [self runPythonFileWithBlock:^{
        
        NSString *path = [[NSBundle mainBundle] pathForResource:@"test0" ofType:@"py"];
        
        NSString *shellcode = [NSString stringWithFormat:@"python %@", path];
        
        [JZShellTool shellToolExec:shellcode itemName:self.itemName];
    }];
    
}

- (void)runPythonFileWithBlock:(void(^)())block
{
    NSString *messageText;
    
    NSString *informativeText = @"you can drag excel file to the dashed area or click the dashed area to select file";
    
    if (_summaryFilePath.length > 0) {
        
        block();
        
        return;
        
    } else {
        
        messageText = @"Please Check for Missing Summary File";
        
    }
    
    [JZAlertTool showAlertWithMessageText:messageText informativeText:informativeText window:self.window];
}

#pragma mark - NSUserNotificationCenter
- (void)runPythonCompletion:(NSNotification *)note
{
    [super runPythonCompletion:note];
    
    NSString *errorString = [note userInfo][@"errorString"];
    
    if (errorString.length == 0) {
        
        _notificationTitle = @"Create Succeeded";
        
        _notificationInformativeText = @"new excel file here.";
        
    } else {
        
        _notificationTitle = @"Create Failed";
        
        _notificationInformativeText = @"See the log below for more information.";
    }
    
    _notificationSubtitle = @"Daily & Breakdown WiFi";
    
    _removedNotification = [JZLocalNotificationTool postNotificationWithTitle:_notificationTitle
                                                                     subtitle:_notificationSubtitle
                                                              informativeText:_notificationInformativeText
                                                                     itemName:self.itemName
                                                          removedNotification:_removedNotification];
}

- (void)updateSummaryFilePath:(NSNotification *)notify
{
    NSString *filePath = [notify userInfo][@"filePath"];

    self.summaryDragView.filePath = filePath;
    
    _summaryFilePath = filePath;
}

#pragma mark - NSUserNotifcationCenterDelegate
- (void)userNotificationCenter:(NSUserNotificationCenter *)center didDeliverNotification:(NSUserNotification *)notification
{
    NSLog(@"通知已经递交！");
    
    if (notification.presented == NO) {
        
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            
            _removedNotification = [JZLocalNotificationTool postNotificationWithTitle:_notificationTitle
                                                                             subtitle:_notificationSubtitle
                                                                      informativeText:_notificationInformativeText
                                                                             itemName:self.itemName
                                                                  removedNotification:_removedNotification];
        });
        
    }
}

- (void)userNotificationCenter:(NSUserNotificationCenter *)center didActivateNotification:(NSUserNotification *)notification
{
    if (notification.activationType == NSUserNotificationActivationTypeAdditionalActionClicked) {
        
        NSLog(@"NSUserNotificationActivationTypeAdditionalActionClicked");
    }
    NSLog(@"用户点击了通知！");
    
    NSURL *url = [NSURL URLWithString:@"file:///Users/jim/Desktop/xiaolong/xiaolong.xlsx"];
    [[NSWorkspace sharedWorkspace] activateFileViewerSelectingURLs:@[url]];
}

- (BOOL)userNotificationCenter:(NSUserNotificationCenter *)center shouldPresentNotification:(NSUserNotification *)notification
{
    //用户中心决定不显示该条通知(如果显示条数超过限制或重复通知等)，returen YES;强制显示
    return YES;
}


#pragma mark - JZFileDragViewDelegate
- (void)fileDragView:(JZFileDragView *)fileDragView throwFilePath:(NSString *)filePath
{
    NSLog(@"filePath = %@", filePath);
    
    _summaryFilePath = filePath;
    
    NSString *key = [NSString stringWithFormat:@"%@%@%@", self.itemName, fileDragView.viewName, FilePathKey];
    
    [[NSUserDefaults standardUserDefaults] setObject:filePath forKey:key];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
}


- (void)dealloc
{
    NSString *notificationName = [NSString stringWithFormat:@"%@%@", self.itemName, UserUnixTaskNotification];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationName object:nil];
    
}

@end
