//
//  JZDailyBreakdownInsertConfig.m
//  RF
//
//  Created by Jim on 2017/5/5.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZDailyBreakdownInsertConfig.h"
#import "NSLabel.h"
#import "JZDailyBreakdownInsertConfigFrame.h"
#import "JZApplicationManager.h"
#import "JZFileDragView.h"
#import <objc/runtime.h>
#import "JZInsertView.h"
#import "JZModuleView.h"
#import "JZShellTool.h"
#import "JZLocalNotificationTool.h"
#import "JZAlertTool.h"
#import "CustomSize.h"
#import "JZCollectionCell.h"

@interface JZDailyBreakdownInsertConfig () <JZFileDragViewDelegate, NSAlertDelegate, NSUserNotificationCenterDelegate>
{
    NSString *_antennaInformationFilePath;
    
    NSString *_rawDataFilePath;
    
    NSString *_notificationTitle;
    
    NSString *_notificationSubtitle;
    
    NSString *_notificationInformativeText;
    
    NSUserNotification *_removedNotification;
}

@end

@implementation JZDailyBreakdownInsertConfig

- (JZDailyBreakdownInsertConfigFrame *)myFrame
{
    if (!_myFrame) {
        
        _myFrame = [[JZDailyBreakdownInsertConfigFrame alloc] initWithRect:self.bounds];
    }
    return _myFrame;
}

- (JZFileDragView *)antennaInformationView
{
    if (!_antennaInformationView) {
        
        _antennaInformationView = [JZFileDragView fileDragViewFrame:self.myFrame.antennaInformationViewFrame fileTypes:@[@"xlsx", @"csv", @"xls"] imageNames:@[@"xlsx", @"csv", @"xls"]];
        
        _antennaInformationView.title.text = @"Antenna Information Here";
        
        _antennaInformationView.viewName = @"AntennaInformation";
        
        _antennaInformationView.delegate = self;
                
        [[[JZApplicationManager manager] fileDragViewPool] addFileDragView:_antennaInformationView];

    }
    return _antennaInformationView;
}

- (JZFileDragView *)rawDataView
{
    if (!_rawDataView) {
        
        _rawDataView = [JZFileDragView fileDragViewFrame:self.myFrame.rawDataViewFrame fileTypes:@[@"csv"] imageNames:@[@"csv"]];
        
        _rawDataView.title.text = @"Raw Data Here";
        
        _rawDataView.viewName = @"RawData";
        
        _rawDataView.delegate = self;
        
        [[[JZApplicationManager manager] fileDragViewPool] addFileDragView:_rawDataView];
    }
    return _rawDataView;
}

- (JZModuleView *)moduleView
{
    if (!_moduleView) {
        
        _moduleView = [[JZModuleView alloc] initWithFrame:self.myFrame.moduleViewFrame];
        
    }
    return _moduleView;
}

- (void)setFrame:(NSRect)frame
{
    [super setFrame:frame];
    
    _myFrame = [[JZDailyBreakdownInsertConfigFrame alloc] initWithRect:self.bounds];
    
    self.antennaInformationView.frame = _myFrame.antennaInformationViewFrame;
    
    self.rawDataView.frame = _myFrame.rawDataViewFrame;
        
    self.moduleView.frame = _myFrame.moduleViewFrame;
}

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        
        [self addSubview:self.antennaInformationView];
        
        [self addSubview:self.rawDataView];
                
        [self addSubview:self.moduleView];
        
        [[NSUserNotificationCenter defaultUserNotificationCenter] setDelegate:self];

    }
    return self;
}

- (void)updateItemName:(NSString *)itemName
{
    self.itemName = [itemName copy];
    
    [self.antennaInformationView updateItemName:itemName];
    
    [self.rawDataView updateItemName:itemName];
    
    [self.moduleView updateItemName:itemName];
    
    NSString *notificationName = [NSString stringWithFormat:@"%@%@", self.itemName, UserUnixTaskNotification];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(runPythonCompletion:) name:notificationName object:nil];
    
    NSString *rawDataKey = [NSString stringWithFormat:@"%@%@%@", self.itemName, self.rawDataView.viewName, FilePathKey];
    
    _rawDataFilePath = [[NSUserDefaults standardUserDefaults] objectForKey:rawDataKey];
    
    if (_rawDataFilePath.length > 0) {
        
        self.rawDataView.filePath = _rawDataFilePath;
        
    }
    
    NSString *antennaInformationKey = [NSString stringWithFormat:@"%@%@%@", self.itemName, self.antennaInformationView.viewName, FilePathKey];
    
    _antennaInformationFilePath = [[NSUserDefaults standardUserDefaults] objectForKey:antennaInformationKey];
    
    
    if (_antennaInformationFilePath.length > 0) {
        
        self.antennaInformationView.filePath = _antennaInformationFilePath;

    }
}

/**
 *  父类方法
 */
- (void)runPythonFile
{
    
    NSLog(@"%s", __FUNCTION__);
    
    NSString *key = [NSString stringWithFormat:@"%@%@", self.itemName, ModuleArrayKey];
    
    NSMutableArray *mArray = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    
    NSMutableArray *moduleArray = [NSMutableArray arrayWithArray:mArray];
    
    NSMutableString *mString = [NSMutableString string];
    
    for (NSDictionary *dict in moduleArray) {
        
        NSString *cellName = dict[@"cellName"];
        
        NSString *collectionCellKey = [NSString stringWithFormat:@"%@%@", self.itemName, cellName];
        
        JZCollectionCell *collectionCell = [[[JZApplicationManager manager] collectionCellPool] findCollectionCellByKey:collectionCellKey];
        
        if (collectionCell.isSelected == YES) {
            
            [mString appendString:cellName];
            
            [mString appendString:@","];
        }
    }
    
    if (mString.length == 0) {
        
        [JZAlertTool showAlertWithMessageText:@"There is no item" informativeText:@"please select one item at least" window:self.window];
        
        return;
    }
    
    NSString *moduleString = [mString substringToIndex:mString.length - 1];

    [self runPythonFileWithBlock:^{
        
        NSString *path = [[NSBundle mainBundle] pathForResource:@"DailyBreakdownInsertConfig" ofType:@"py"];
        
        NSString *shellcode = [NSString stringWithFormat:@"python %@ '%@' '%@' '%@' %@", path, _rawDataFilePath, _antennaInformationFilePath, moduleString, NSHomeDirectory()];
        
        [JZShellTool shellToolExec:shellcode itemName:self.itemName];
        
    }];
}

- (void)runPythonFileWithBlock:(void(^)())block
{
    NSString *messageText;
    
    NSString *informativeText = @"you can drag excel file to the dashed area or click the dashed area to select file";
    
    if (_antennaInformationFilePath.length > 0 && _rawDataFilePath.length > 0) {
        
        block();
        
        return;
        
    } else if (_antennaInformationFilePath.length == 0  && _rawDataFilePath.length > 0) {
        
        messageText = @"Please Check for Missing Antenna Information File";
        
    } else if (_antennaInformationFilePath.length > 0 && _rawDataFilePath.length == 0) {
        
        messageText = @"Please Check for Missing Raw Data File";
        
    } else if (_antennaInformationFilePath.length == 0 && _rawDataFilePath.length == 0) {
        
        messageText = @"Please Check for Missing Antenna Information File and Raw Data File";
    
    }
    
    [JZAlertTool showAlertWithMessageText:messageText informativeText:informativeText window:self.window];

}

#pragma mark - NSUserNotificationCenter
- (void)runPythonCompletion:(NSNotification *)note
{
    [super runPythonCompletion:note];

    NSString *errorString = [note userInfo][@"errorString"];
    
    if (errorString.length == 0) {

        _notificationTitle = @"Create Succeeded";
        
        _notificationInformativeText = @"new excel file here.";
        
        NSString *newFilePath = [NSString stringWithFormat:@"%@/Desktop/DailyBreakdownInsertConfig.xlsx", NSHomeDirectory()];
        
        [[NSUserDefaults standardUserDefaults] setObject:newFilePath forKey:@"JZDailyBreakdownWiFiSummaryFilePathKey"];
        
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:JZDailyBreakdownInsertConfigCreateSucceededNotification object:nil userInfo:@{@"filePath":newFilePath}];
        
    } else {
        
        _notificationTitle = @"Create Failed";
        
        _notificationInformativeText = @"See the log below for more information.";
    }
    
    _notificationSubtitle = @"Daily & Breakdown Insert Config";

    _removedNotification = [JZLocalNotificationTool postNotificationWithTitle:_notificationTitle
                                                                     subtitle:_notificationSubtitle
                                                              informativeText:_notificationInformativeText
                                                                   itemName:self.itemName
                                                          removedNotification:_removedNotification];
}

#pragma mark - NSUserNotificationCenterDelegate
- (void)userNotificationCenter:(NSUserNotificationCenter *)center didDeliverNotification:(NSUserNotification *)notification
{
    NSLog(@"通知已经递交！");
    
    if (notification.presented == NO) {
        
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            
            _removedNotification = [JZLocalNotificationTool postNotificationWithTitle:_notificationTitle
                                                                             subtitle:_notificationSubtitle
                                                                      informativeText:_notificationInformativeText
                                                                           itemName:self.itemName
                                                                  removedNotification:_removedNotification];
        });
        
    }
}

- (void)userNotificationCenter:(NSUserNotificationCenter *)center didActivateNotification:(NSUserNotification *)notification
{
    if (notification.activationType == NSUserNotificationActivationTypeAdditionalActionClicked) {
        
        NSLog(@"NSUserNotificationActivationTypeAdditionalActionClicked");
    }
    NSLog(@"用户点击了通知！");
    
    NSURL *url = [NSURL URLWithString:@"file:///Users/jim/Desktop/DailyBreakdownInsertConfig.xlsx"];
    [[NSWorkspace sharedWorkspace] activateFileViewerSelectingURLs:@[url]];
}

- (BOOL)userNotificationCenter:(NSUserNotificationCenter *)center shouldPresentNotification:(NSUserNotification *)notification
{
    //用户中心决定不显示该条通知(如果显示条数超过限制或重复通知等)，returen YES;强制显示
    return YES;
}

#pragma mark - JZFileDragViewDelegate 方法

- (void)fileDragView:(JZFileDragView *)fileDragView throwFilePath:(NSString *)filePath
{
    NSLog(@"filePath = %@", filePath);
    
    if ([fileDragView.viewName isEqualToString:@"RawData"]) {
        
        _rawDataFilePath = filePath;
        
    } else if ([fileDragView.viewName isEqualToString:@"AntennaInformation"]) {
        
        _antennaInformationFilePath = filePath;

    }
    
    NSString *key = [NSString stringWithFormat:@"%@%@%@", self.itemName, fileDragView.viewName, FilePathKey];
    
    [[NSUserDefaults standardUserDefaults] setObject:filePath forKey:key];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)dealloc
{
    NSString *notificationName = [NSString stringWithFormat:@"%@%@", self.itemName, UserUnixTaskNotification];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationName object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:RunPythonFileNotification object:nil];
}

@end
