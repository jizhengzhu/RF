//
//  JZCollectionViewItem.m
//  RF
//
//  Created by Jim on 2017/5/10.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZCollectionViewItem.h"
#import "JZCollectionViewItemView.h"
#import "JZApplicationManager.h"

@interface JZCollectionViewItem ()

@property (nonatomic) JZCollectionViewItemView *collectionViewItemView;

@end

@implementation JZCollectionViewItem

- (JZCollectionViewItemView *)collectionViewItemView
{
    if (!_collectionViewItemView) {
        
        _collectionViewItemView = [[JZCollectionViewItemView alloc] initWithFrame:NSMakeRect(0, 0, 130, 60)];
    }
    
    return _collectionViewItemView;
}

- (void)loadView
{
    self.view = self.collectionViewItemView;
}

- (void)setRepresentedObject:(id)representedObject
{
    [super setRepresentedObject:representedObject];
    
    if ([representedObject isKindOfClass:[NSDictionary class]]) {
        
        NSString *cellName = representedObject[@"cellName"];
        
        NSString *itemName = representedObject[@"itemName"];
        
        NSString *key = [NSString stringWithFormat:@"%@%@", itemName, cellName];
        
        JZCollectionCell *collectionCell = [[[JZApplicationManager manager] collectionCellPool] findCollectionCellByKey:key];
        
        if (collectionCell == nil) {
            
            collectionCell = [[JZCollectionCell alloc] initWithFrame:NSMakeRect(10, 10, 110, 40)];
            
            [collectionCell setText:cellName];
            
            [collectionCell setCellName:cellName];
            
            [collectionCell updateItemName:itemName];
            
            [[[JZApplicationManager manager] collectionCellPool] addCollectionCell:collectionCell];
            
        }
        
        [self.collectionViewItemView addSubview:collectionCell];

    }

}

@end
