//
//  JZInsertBtn.m
//  RF
//
//  Created by Jim on 2017/5/10.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZInsertBtn.h"

@interface JZInsertBtn ()

@property (nonatomic) NSImageView *imageView;

@end

@implementation JZInsertBtn

- (NSImageView *)imageView
{
    if (!_imageView) {
        
        _imageView = [[NSImageView alloc] initWithFrame:NSMakeRect(5, 5, 18, 18)];
        
    }
    return _imageView;
}

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self addSubview:self.imageView];
    }
    return self;
}

- (void)setImage:(NSImage *)image
{
    _image = image;
    
    [self.imageView setImage:image];
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];

}

//此方法需要在改变的时候手动调用一次(父类的方法)
- (void)updateTrackingAreas
{
    NSArray *trackings = [self trackingAreas];
    for (NSTrackingArea *tracking in trackings)
    {
        [self removeTrackingArea:tracking];
    }
    
    //添加NSTrackingActiveAlways掩码可以使视图未处于激活或第一响应者时也能响应相应的方法
    NSTrackingArea *trackingArea = [[NSTrackingArea alloc] initWithRect:[self bounds]
                                                                options:NSTrackingMouseEnteredAndExited|NSTrackingMouseMoved|NSTrackingActiveAlways
                                                                  owner:self
                                                               userInfo:nil];
    [self addTrackingArea:trackingArea];
}

- (void)mouseDown:(NSEvent *)event
{
    [super mouseDown:event];
    
    if ([self.delegate respondsToSelector:@selector(mouseDownInsertBtn:)]) {
        
        [self.delegate mouseDownInsertBtn:self];
    }
}

- (void)mouseUp:(NSEvent *)event
{
    [super mouseUp:event];
    
    if ([self.delegate respondsToSelector:@selector(mouseUpInsertBtn:)]) {
        
        [self.delegate mouseUpInsertBtn:self];
    }
}

@end
