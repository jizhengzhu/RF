//
//  JZLimitView.m
//  RF
//
//  Created by Jim on 2017/5/14.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZLimitView.h"
#import "NSLabel.h"

@interface JZLimitView () <NSTableViewDelegate, NSTableViewDataSource>


@end

@implementation JZLimitView

- (NSTableView *)tbView
{
    if (!_tbView) {
        
        _tbView = [[NSTableView alloc] initWithFrame:self.bounds];
        
        _tbView.delegate = self;
        
        _tbView.dataSource = self;
        
        _tbView.backgroundColor = [NSColor clearColor];
        
        _tbView.selectionHighlightStyle = NSTableViewSelectionHighlightStyleNone;
        
        _tbView.refusesFirstResponder = YES;
        
        NSTableColumn *tableColumn1 = [[NSTableColumn alloc] initWithIdentifier:@"name"];
        
        [tableColumn1 setWidth:80];
        
        [_tbView addTableColumn:tableColumn1];
        
        NSTableColumn *tableColumn2 = [[NSTableColumn alloc] initWithIdentifier:@"array"];
        
        [tableColumn2 setWidth:80];
        
        [_tbView addTableColumn:tableColumn2];
        
    }
    return _tbView;
}

- (void)setDataArray:(NSArray *)dataArray
{
    _dataArray = dataArray;
    
    [self.tbView reloadData];
}

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self addSubview:self.tbView];
    }
    return self;
}

- (void)updateItemName:(NSString *)itemName
{
    _itemName = [itemName copy];
}

#pragma mark - NSTableViewDataSource

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView
{
    return _dataArray.count;
}

- (id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    return nil;
}

- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row
{
    return 40;
}

- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    NSDictionary *dict = _dataArray[row];
    
    NSString *identifier = [tableColumn identifier];
    
    NSLog(@"iden = %@", identifier);
    
    NSView *view = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 80, 40)];
    
    if ([identifier isEqualToString:@"name"]) {
        
        NSLabel *label = [[NSLabel alloc] initWithFrame:NSMakeRect(0, 5, 70, 30)];
        
        label.alignment = NSTextAlignmentRight;
        
        [label setText:dict[@"name"]];
        
        [view addSubview:label];
        
    } else if ([identifier isEqualToString:@"array"]) {
        
        NSPopUpButton *btn = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(0, 5, 80, 30)];
        
        NSArray *array = dict[@"array"];
        
        for (int i = 0; i < array.count; i++) {
            
            NSString *title = array[i];
            
            [btn insertItemWithTitle:title atIndex:i];

        }
        
        [view addSubview:btn];
    }
    
    return view;
}
@end



































