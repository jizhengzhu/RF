//
//  JZApplicationManager.m
//  RF
//
//  Created by Jim on 2017/5/7.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZApplicationManager.h"
#import "CustomSize.h"

@interface JZApplicationManager ()

@property (nonatomic) JZMainViewPool *mainViewPool;

@property (nonatomic) JZOutlineCellPool *outlineCellPool;

@property (nonatomic) JZFileDragViewPool *fileDragViewPool;

@property (nonatomic) JZCollectionCellPool *collectionCellPool;

@property (nonatomic) NSMutableArray *pageManagerArray;

@property BOOL isFirstLaunch;

@end

static JZApplicationManager *_manager = nil;

@implementation JZApplicationManager

+ (instancetype)manager
{
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        
        _manager = [[JZApplicationManager alloc] init];
        
        _manager.isFirstLaunch = YES;
    });
    
    return _manager;
}

- (JZMainViewPool *)mainViewPool
{
    if (!_mainViewPool) {
        
        _mainViewPool = [[JZMainViewPool alloc] init];
    }
    return _mainViewPool;
}

- (JZOutlineCellPool *)outlineCellPool
{
    if (!_outlineCellPool) {
        
        _outlineCellPool = [[JZOutlineCellPool alloc] init];
    }
    return _outlineCellPool;
}

- (JZFileDragViewPool *)dragViewPool
{
    if (!_fileDragViewPool) {
        
        _fileDragViewPool = [[JZFileDragViewPool alloc] init];
    }
    return _fileDragViewPool;
}

- (JZCollectionCellPool *)collectionCellPool
{
    if (!_collectionCellPool) {
        
        _collectionCellPool = [[JZCollectionCellPool alloc] init];
    }
    return _collectionCellPool;
}
- (void)setMain:(BOOL)main
{
    _main = main;
    
    self.outlineCellPool.main = main;
    
    if (_isFirstLaunch == YES) {
        
        _isFirstLaunch = NO;
        
        NSString *itemName = [[NSUserDefaults standardUserDefaults] objectForKey:keyItemName];
        
        JZOutlineCell *outlineCell = [self.outlineCellPool findOutlineCellByItemName:itemName];
        
        _firstResponder = outlineCell;
    }
    
    [self refreshOutlineCellDisplay];
    
    [self refreshFileDragViewDisplay];

}

- (void)refreshOutlineCellDisplay
{
    [self.outlineCellPool refreshOutlineCellDisplayWithFirstResponder:_firstResponder];
}

- (void)refreshFileDragViewDisplay
{
    [self.fileDragViewPool refreshFileDragViewDisplayWithFirstResponder:_firstResponder];
}

- (void)refreshCollectionViewDisplay
{
    [self.collectionCellPool refreshCollectionCellDisplayWithFirstResponder:_firstResponder];
}

- (NSMutableArray *)pageManagerArray
{
    if (!_pageManagerArray) {
        
        _pageManagerArray = [NSMutableArray array];
        
    }
    return _pageManagerArray;
}

- (void)increaseIndex
{
    _index++;
    
    if (_index > self.pageManagerArray.count - 1) {
        
        _index = self.pageManagerArray.count - 1;
    }
}

- (void)decreaseIndex
{
    _index--;
    
    if (_index < 0) {
        
        _index = 0;
    }
}

@end
