//
//  JZDailyBreakdownWF5.m
//  RF
//
//  Created by Jim on 2017/5/9.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZDailyBreakdownWF5.h"

@implementation JZDailyBreakdownWF5


- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

@end
