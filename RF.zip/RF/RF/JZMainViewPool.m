//
//  JZMainViewPool.m
//  RF
//
//  Created by Jim on 2017/5/8.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZMainViewPool.h"
#import "JZMainView.h"


@interface JZMainViewPool ()

@property (nonatomic) NSMutableDictionary *mainViewPool;
@end

@implementation JZMainViewPool

- (NSMutableDictionary *)mainViewPool
{
    if (!_mainViewPool) {
        
        _mainViewPool = [NSMutableDictionary dictionary];
    }
    return _mainViewPool;
}

- (void)addMainView:(JZMainView *)mainView
{
    [self.mainViewPool setObject:mainView forKey:mainView.itemName];
}

- (JZMainView *)findMainViewByItemName:(NSString *)itemName
{
    return [self.mainViewPool objectForKey:itemName];
}

@end
