//
//  JZDragView+drawRect.m
//  RF
//
//  Created by Jim on 2017/5/6.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZDragView+drawRect.h"

@implementation JZDragView (drawRect)

- (void)drawBorderMouseEnter:(NSRect)dirtyRect
{
    [self drawBorder:dirtyRect lineColor:[NSColor colorWithRed:0.05 green:0.70 blue:0.96 alpha:1.00] dash:NO];
}

- (void)drawBorderMouseExit:(NSRect)dirtyRect
{
    [self drawBorder:dirtyRect lineColor:[NSColor colorWithRed:0.43 green:0.79 blue:0.95 alpha:1.00] dash:NO];

}

- (void)drawDashBorder:(NSRect)dirtyRect
{
    [self drawBorder:dirtyRect lineColor:[NSColor grayColor] dash:YES];
}

- (void)drawMouseDownHighlightDashBorder:(NSRect)dirtyRect
{
    [self drawBorder:dirtyRect lineColor:[NSColor colorWithRed:0.43 green:0.79 blue:0.95 alpha:1.00] dash:YES];
}

- (void)drawMouseEnterHighlightDashBorder:(NSRect)dirtyRect
{
    [self drawBorder:dirtyRect lineColor:[NSColor colorWithRed:0.05 green:0.70 blue:0.96 alpha:1.00] dash:YES];
}

- (void)drawBorder:(NSRect)dirtyRect lineColor:(NSColor *)lineColor dash:(BOOL)isDash
{
    // 画虚线边框
    [lineColor setStroke];
    
    // 如果不这样处理，线的宽度有一半会看不到
    NSRect roundedRect = NSMakeRect(dirtyRect.origin.x + lineWidth / 2,
                                    dirtyRect.origin.y + lineWidth / 2,
                                    dirtyRect.size.width - lineWidth,
                                    dirtyRect.size.height - lineWidth);
    
    NSBezierPath *dashBorderPath = [NSBezierPath bezierPath];
    
    [dashBorderPath appendBezierPathWithRoundedRect:roundedRect xRadius:_radius yRadius:_radius];
    
    if (isDash) {
        
        CGFloat dash[] = {_borderlengths, _bordergaps};
        
        [dashBorderPath setLineDash:dash count:2 phase:0.0];
    }
    
    [dashBorderPath setLineWidth:lineWidth];
    
    [dashBorderPath stroke];
}

- (void)drawPlusSign:(NSRect)dirtyRect
{
    [self drawPlusSign:dirtyRect lineColor:[NSColor grayColor]];
}

- (void)drawMouseDownHighlightPlusSign:(NSRect)dirtyRect
{
    [self drawPlusSign:dirtyRect lineColor:[NSColor colorWithRed:0.43 green:0.79 blue:0.95 alpha:1.00]];
}

- (void)drawMouseEnterHighlightPlusSign:(NSRect)dirtyRect
{
    [self drawPlusSign:dirtyRect lineColor:[NSColor colorWithRed:0.05 green:0.70 blue:0.96 alpha:1.00]];
}

- (void)drawPlusSign:(NSRect)dirtyRect lineColor:(NSColor *)lineColor
{
    [lineColor setStroke];
    
    CGFloat dash[] = {_pluslengths, _plusgaps};
    
    NSBezierPath *plusSignPath = [NSBezierPath bezierPath];
    
    [plusSignPath setLineDash:dash count:2 phase:0.0];
    
    [plusSignPath moveToPoint:NSMakePoint(dirtyRect.size.width / 4, dirtyRect.size.height / 2)];
    
    [plusSignPath lineToPoint:NSMakePoint(dirtyRect.size.width * 3 / 4, dirtyRect.size.height / 2)];
    
    [plusSignPath moveToPoint:NSMakePoint(dirtyRect.size.width / 2, dirtyRect.size.height * 3 / 4)];
    
    [plusSignPath lineToPoint:NSMakePoint(dirtyRect.size.width / 2, dirtyRect.size.height / 4)];
    
    [plusSignPath setLineWidth:lineWidth];
    
    [plusSignPath stroke];
}

- (void)drawTranslucentBackground:(NSRect)dirtyRect
{
    NSColor* translucentBackgroundColor = [NSColor colorWithWhite:1 alpha:0.5];
    
    [translucentBackgroundColor setFill];
    
    NSBezierPath *translucentBackgroundPath = [NSBezierPath bezierPath];
    
    [translucentBackgroundPath appendBezierPathWithRoundedRect:dirtyRect xRadius:_radius yRadius:_radius];
    
    [translucentBackgroundPath fill];
    
    self.layer.cornerRadius = _radius;
}

- (void)drawShadow
{    
    NSShadow *shadow = [[NSShadow alloc] init];
    
    shadow.shadowOffset = NSMakeSize(0, 0);
    
    shadow.shadowColor = [NSColor lightGrayColor];
    
    shadow.shadowBlurRadius = 4;
    
    self.shadow = shadow;
}

@end
