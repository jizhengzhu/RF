//
//  NSLabel.m
//  RF
//
//  Created by Jim on 2017/5/6.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "NSLabel.h"
#import "NSLabel+separateLines.h"
#import "NSLabel+attributes.h"
#import "NSLabel+wrapperBackground.h"

#define kDegreeToRadians(degree) (degree) * M_PI / 180

@implementation NSLabel

@synthesize text = _text;

@synthesize font = _font;

@synthesize textColor = _textColor;

@synthesize backgroundColor = _backgroundColor;

@synthesize wrapperBackgroundColor = _wrapperBackgroundColor;

- (void)setText:(NSString *)text
{
    _text = [text copy];
    
    [self setNeedsDisplay:YES];
}

- (NSString *)text
{
    if (!_text) {
        
        _text = @"";
    }
    return _text;
}

- (void)setFont:(NSFont *)font
{
    _font = font;
    
    [self setNeedsDisplay:YES];
}

- (NSFont *)font
{
    if (!_font) {
        
        _font = [NSFont systemFontOfSize:12];
    }
    return _font;
}

- (void)setTextColor:(NSColor *)textColor
{
    _textColor = textColor;
    
    [self setNeedsDisplay:YES];
}

- (NSColor *)textColor
{
    if (!_textColor) {
        
        _textColor = [NSColor blackColor];
    }
    return _textColor;
}

- (void)setBackgroundColor:(NSColor *)backgroundColor
{
    _backgroundColor = backgroundColor;

    [self setNeedsDisplay:YES];
}

- (NSColor *)backgroundColor
{
    if (!_backgroundColor) {
        
        _backgroundColor = [NSColor clearColor];
    }
    return _backgroundColor;
}

- (void)setWrapperBackgroundColor:(NSColor *)wrapperBackgroundColor
{
    _wrapperBackgroundColor = wrapperBackgroundColor;
    
    [self setNeedsDisplay:YES];
}

- (NSColor *)wrapperBackgroundColor
{
//    if (!_wrapperBackgroundColor) {
    
        _wrapperBackgroundColor = [NSColor clearColor];
//    }
    
    return _wrapperBackgroundColor;
}

- (void)setLineBreakMode:(NSLineBreakMode)lineBreakMode
{
    _lineBreakMode = lineBreakMode;
    
    [self setNeedsDisplay:YES];
}

- (void)setAlignment:(NSTextAlignment)alignment
{
    _alignment = alignment;
    
    [self setNeedsDisplay:YES];
}

- (void)setAutoResize:(BOOL)autoResize
{
    _autoResize = autoResize;
    
    [self setNeedsDisplay:YES];
}

- (void)setCornerRadius:(CGFloat)cornerRadius
{
    _cornerRadius = cornerRadius;
    
    [self setNeedsDisplay:YES];
}

- (void)setWrapperCornerRadius:(CGFloat)wrapperCornerRadius
{
    _wrapperCornerRadius = wrapperCornerRadius;
    
    [self setNeedsDisplay:YES];
}

- (void)drawRect:(NSRect)dirtyRect {
    
    [super drawRect:dirtyRect];

    [self drawBackgroundColor:dirtyRect];
    
//    [self drawWrapperBackground:dirtyRect cornerRadius:_wrapperCornerRadius];

    [self drawText:dirtyRect];
    
}

- (void)drawBackgroundColor:(NSRect)dirtyRect
{
    
    [self.backgroundColor setFill];
    
    NSBezierPath *path = [NSBezierPath bezierPathWithRoundedRect:dirtyRect xRadius:_cornerRadius yRadius:_cornerRadius];
    
    [path fill];
}

- (void)drawText:(NSRect)dirtyRect
{
    NSDictionary *attribute = [self customAttribute];
    
    NSSize textSize = [self.text boundingRectWithSize:NSMakeSize(self.bounds.size.width, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:attribute].size;
    
    if (_autoResize) {
        
        self.frame = NSMakeRect(self.frame.origin.x, self.frame.origin.y - (textSize.height - dirtyRect.size.height), self.frame.size.width, textSize.height);
    }

    NSRect textRect = NSMakeRect(0, (self.bounds.size.height - textSize.height) / 2, self.bounds.size.width, textSize.height);
    
    [self.text drawInRect:textRect withAttributes:attribute];
}

- (void)drawShadow:(NSColor *)shadowColor
{
    self.layer.backgroundColor = [NSColor clearColor].CGColor;
    
    NSShadow *shadow = [[NSShadow alloc] init];
    
    shadow.shadowColor = shadowColor;
    
    shadow.shadowBlurRadius = 3;
    
    self.shadow = shadow;
}

@end








































