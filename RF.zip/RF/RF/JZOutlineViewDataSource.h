//
//  JZOutlineViewDataSource.h
//  RF
//
//  Created by Jim on 2017/4/27.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>

@interface JZOutlineViewDataSource : NSObject <NSOutlineViewDataSource>

@property (nonatomic) NSArray *list;

@end
