//
//  JZShellTool.h
//  RF
//
//  Created by Jim on 2017/5/12.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZShellTool : NSObject

+ (void)shellToolExec:(NSString *)cmd itemName:(NSString *)itemName;

@end
