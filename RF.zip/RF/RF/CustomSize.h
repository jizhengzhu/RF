//
//  CustomSize.h
//  RF
//
//  Created by Jim on 2017/4/26.
//  Copyright © 2017年 Jim. All rights reserved.
//

#ifndef CustomSize_h
#define CustomSize_h

static const CGFloat tbwidth = 160;

static const CGFloat cellheight = 40;

static const CGFloat windowwidth = 800;

static const CGFloat windowheight = 600;

static const CGFloat toolheight = 30;

static const CGFloat logdragheight = 10;

static const CGFloat dragviewlength = 100;

static const CGFloat dragviewtitleheight = 50;

static const CGFloat interval = 10;

static const CGFloat insertviewheight = 28;

static NSString *const JZOutlineCellNotification = @"JZOutlineCellNotification";

static NSString *const JZTitlebarLeftOrRightBtnNotification = @"JZTitlebarLeftOrRightBtnNotification";

static const CGFloat goldenRatio = 0.618f;

static NSString *const keyItemName = @"keyItemName";

// 这个值与各类名组合，成为NSUserDefault的key值，与各个类一一对应，存储的是一个数组，每个数组只存储当前视图moduleView的collectioncell的信息，以字典的形式存储，如：{@"itemName":itemName, @"cellName":cellName}
static NSString *const ModuleArrayKey = @"ModuleArrayKey";

static NSString *const FilePathKey = @"FilePathKey";

static NSString *const RefreshCollectionViewNotification = @"RefreshCollectionViewNotification";

static NSString *const RunPythonFileNotification = @"RunPythonFileNotification";

static NSString *const AnimationNotification = @"AnimationNotification";

static NSString *const UserUnixTaskNotification = @"UserUnixTaskNotification";

static NSString *const JZShowLogStatusNotification = @"JZShowLogStatusNotification";

static NSString *const JZDailyBreakdownInsertConfigCreateSucceededNotification = @"JZDailyBreakdownInsertConfigCreateSucceededNotification";

#endif /* CustomSize_h */
