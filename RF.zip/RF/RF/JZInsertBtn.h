//
//  JZInsertBtn.h
//  RF
//
//  Created by Jim on 2017/5/10.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class JZInsertBtn;

@protocol JZInsertBtnDelegate <NSObject>

- (void)mouseDownInsertBtn:(JZInsertBtn *)insertBtn;

- (void)mouseUpInsertBtn:(JZInsertBtn *)insertBtn;

@end

@interface JZInsertBtn : NSView

@property (weak) id <JZInsertBtnDelegate> delegate;

@property (nonatomic) NSImage *image;

@end
