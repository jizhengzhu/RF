//
//  JZWindow.m
//  RF
//
//  Created by Jim on 2017/5/9.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZWindow.h"
#import "JZApplicationManager.h"


@implementation JZWindow

//- (NSTimeInterval)animationResizeTime:(NSRect)newFrame
//{
//    
//    NSLog(@"newFrame = %@", NSStringFromRect(newFrame));
//    return 10;
//}
- (BOOL)makeFirstResponder:(NSResponder *)responder
{
    BOOL result = NO;
    
    if (self) {
        
        result = [super makeFirstResponder:responder];
    }
    [[JZApplicationManager manager] setFirstResponder:responder];
    
    [[JZApplicationManager manager] refreshFileDragViewDisplay];
    
    [[JZApplicationManager manager] refreshOutlineCellDisplay];
    
    [[JZApplicationManager manager] refreshCollectionViewDisplay];
    
    return result;
}

- (BOOL)acceptsFirstResponder
{
    return NO;
}

@end
