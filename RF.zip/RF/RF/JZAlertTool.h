//
//  JZAlertTool.h
//  RF
//
//  Created by Jim on 2017/5/12.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
@interface JZAlertTool : NSObject

+ (NSAlert *)showAlertWithMessageText:(NSString *)messageText
                          informativeText:(NSString *)informativeText
                                   window:(NSWindow *)window;

@end
