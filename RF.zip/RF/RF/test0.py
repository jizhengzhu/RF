# encoding=utf8
import sys

reload(sys)
sys.setdefaultencoding('utf8')
# 导入读excel的python库
import xlrd

# 打开文件
xls = xlrd.open_workbook('/Users/jim/Desktop/xiaolong/xiaolong.xlsx')

# 选择表
sheet1 = xls.sheet_by_index(0)
sheet2 = xls.sheet_by_index(1)

# 获取表的行数
nrows1 = sheet1.nrows
nrows2 = sheet2.nrows

# 定义数组存放表中的数据
arr1 = [] # 表1中的数据
arr2 = [] # 表2中的数据

# 遍历第一张表中的C列单元格
for i in range(nrows1):

	# C列第i行的单元格内容
	Ci = sheet1.col(2)[i].value

	# 打印单元格内容
	print 'C' + str(i) + '=' + Ci

	# 把获取的单元格内容放到arr1数组中
	arr1.append(Ci)

# 遍历第二张表中的D列单元格
for i in range(nrows2):

	# D列第i行的单元格内容
	Di = sheet2.col(3)[i].value

	# 打印单元格内容
#	print 'D' + str(i) + '=' + Di

	# 把获取的单元格内容放到arr2数组中
	arr2.append(Di)

CNumber = 0
for i in range(len(arr1)):

	str1 = arr1[i].strip()

	if len(str1) == 5 :

#		print 'str1 = ' + str1

		CNumber = CNumber + 1

print CNumber

DNumber = 0
for j in range(len(arr2)):

	str2 = arr2[j].strip()

	if len(str2) == 5:

#		print 'str2 = ' + str2

		DNumber = DNumber + 1

print DNumber




























