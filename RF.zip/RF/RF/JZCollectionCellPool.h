//
//  JZCollectionCellPool.h
//  RF
//
//  Created by Jim on 2017/5/10.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@class JZCollectionCell;
@interface JZCollectionCellPool : NSObject

@property (nonatomic, readonly) NSMutableDictionary *collectionCellPool;

- (void)addCollectionCell:(JZCollectionCell *)collectionCell;

- (JZCollectionCell *)findCollectionCellByKey:(NSString *)key;

- (void)refreshCollectionCellDisplayWithFirstResponder:(id)firstResponder;

@end
