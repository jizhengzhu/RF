//
//  JZViewControllerFrame.h
//  RF
//
//  Created by Jim on 2017/5/9.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZViewControllerFrame : NSObject

@property CGRect mainViewFrame;

@property CGRect logDragViewFrame;

@property CGRect logScrollViewFrame;

@property CGFloat logViewHeight;

- (instancetype)initWithRect:(NSRect)rect;

- (void)refreshFrameWithRect:(NSRect)rect;

@end
