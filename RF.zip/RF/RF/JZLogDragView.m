//
//  JZLogDragView.m
//  RF
//
//  Created by Jim on 2017/5/8.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZLogDragView.h"
#import "CustomSize.h"

@implementation JZLogDragView

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    NSBezierPath *backgroundColorPath = [NSBezierPath bezierPathWithRect:dirtyRect];
    
    [[NSColor colorWithWhite:0.5 alpha:0.5] setFill];
    
    [backgroundColorPath fill];
    
    NSBezierPath *path = [NSBezierPath bezierPath];
    
    [path moveToPoint:NSMakePoint(dirtyRect.size.width, logdragheight - 0.5)];

    [path lineToPoint:NSMakePoint(0, logdragheight - 0.5)];
    
    [[NSColor lightGrayColor] setStroke];
    
    [path setLineWidth:1];
    
    [path stroke];

}

//此方法需要在改变的时候手动调用一次(父类的方法)
- (void)updateTrackingAreas
{
    NSArray *trackings = [self trackingAreas];
    for (NSTrackingArea *tracking in trackings)
    {
        [self removeTrackingArea:tracking];
    }
    
    //添加NSTrackingActiveAlways掩码可以使视图未处于激活或第一响应者时也能响应相应的方法
    NSTrackingArea *trackingArea = [[NSTrackingArea alloc] initWithRect:[self bounds]
                                                                options:NSTrackingMouseEnteredAndExited|NSTrackingMouseMoved|NSTrackingActiveAlways
                                                                  owner:self
                                                               userInfo:nil];
    [self addTrackingArea:trackingArea];
}


- (void)mouseDragged:(NSEvent *)event
{
    NSLog(@"%s", __FUNCTION__);
    
    [[NSCursor resizeUpDownCursor] set];

    if ([self.delegate respondsToSelector:@selector(logDragView:mouseDrag:)]) {
                
        [self.delegate logDragView:self mouseDrag:event];
    }
}


- (void)mouseEntered:(NSEvent *)event
{
    NSLog(@"%s", __FUNCTION__);
    
    [[NSCursor resizeUpDownCursor] set];
    
}

- (void)mouseMoved:(NSEvent *)event
{    
    [[NSCursor resizeUpDownCursor] set];
}

- (void)mouseExited:(NSEvent *)event
{
    [super mouseExited:event];
    
    NSLog(@"%s", __FUNCTION__);
    
    [[NSCursor arrowCursor] set];
}



@end
