//
//  CustomWindowButtonView.m
//  RF
//
//  Created by Jim on 2017/5/10.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "CustomWindowButtonView.h"

@implementation CustomWindowButtonView

- (NSButton *)closeButton
{
    if (!_closeButton) {
        
        _closeButton = [NSWindow standardWindowButton:NSWindowCloseButton forStyleMask:self.window.styleMask];
        
        NSLog(@"_closeButton.frame = %@", NSStringFromRect(_closeButton.frame));
        
//        2017-05-10 02:13:38.831674+0800 RF[70089:1894657] _closeButton.frame = {{0, 0}, {14, 16}}
        
        _closeButton.frame = NSMakeRect(0, 0, 14, 16);
    }
    return _closeButton;
}

- (NSButton *)minitButton
{
    if (!_minitButton) {
        
        _minitButton = [NSWindow standardWindowButton:NSWindowMiniaturizeButton forStyleMask:self.window.styleMask];
        
        _minitButton.frame = NSMakeRect(20, 0, 14, 16);

    }
    return _minitButton;
}

- (NSButton *)zoomButton
{
    if (!_zoomButton) {
    
        _zoomButton = [NSWindow standardWindowButton:NSWindowZoomButton forStyleMask:self.window.styleMask];
        
        _zoomButton.frame = NSMakeRect(40, 0, 14, 16);

    }
    
    return _zoomButton;
}

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self addSubview:self.closeButton];
        
        [self addSubview:self.minitButton];
        
        [self addSubview:self.zoomButton];
        
        NSNotificationCenter *defaultCenter = [NSNotificationCenter defaultCenter];
        
        [defaultCenter addObserver:self selector:@selector(applicationWillBecomeActive:)
                              name:NSApplicationWillBecomeActiveNotification object:NSApp];
        
        [defaultCenter addObserver:self selector:@selector(applicationDidResignActive:)
                              name:NSApplicationDidResignActiveNotification object:NSApp];
        
        [defaultCenter addObserver:self selector:@selector(windowActiveChanged:)
                              name:NSWindowDidBecomeMainNotification object:nil];
    }
    return self;
}

- (void)updateTrackingAreas {
    
    [super updateTrackingAreas];
    
    NSTrackingArea *const trackingArea = [[NSTrackingArea alloc] initWithRect:NSZeroRect options:(NSTrackingMouseEnteredAndExited | NSTrackingActiveAlways | NSTrackingInVisibleRect) owner:self userInfo:nil];
    [self addTrackingArea:trackingArea];
}

- (void)mouseEntered:(NSEvent *)event {
    [super mouseEntered:event];
    
    self.mouseInside = YES;
    [self setNeedsDisplayForStandardWindowButtons];
}

- (void)mouseExited:(NSEvent *)event {
    [super mouseExited:event];
    
    self.mouseInside = NO;
    [self setNeedsDisplayForStandardWindowButtons];
}

- (BOOL)_mouseInGroup:(NSButton *)button {
    return self.mouseInside;
}

- (void)setNeedsDisplayForStandardWindowButtons {
    [self.closeButton setNeedsDisplay];
    [self.minitButton setNeedsDisplay];
    [self.zoomButton setNeedsDisplay];
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
}

- (void)applicationWillBecomeActive:(NSNotification *)notification {
    
    self.mouseInside = YES;
    [self setNeedsDisplayForStandardWindowButtons];
    
    self.mouseInside = NO;
    [self setNeedsDisplayForStandardWindowButtons];
}

- (void)applicationDidResignActive:(NSNotification *)notification {
    
    self.mouseInside = NO;
    [self setNeedsDisplayForStandardWindowButtons];
}

- (void)windowActiveChanged:(NSNotification *)notification {
    
    self.mouseInside = NO;
    [self setNeedsDisplayForStandardWindowButtons];
}

- (void)dealloc
{
    NSNotificationCenter *defaultCenter = [NSNotificationCenter defaultCenter];
    
    [defaultCenter removeObserver:self name:NSApplicationWillBecomeActiveNotification object:NSApp];
    
    [defaultCenter removeObserver:self name:NSApplicationDidResignActiveNotification object:NSApp];
    
    [defaultCenter removeObserver:self name:NSWindowDidBecomeMainNotification object:NSApp];

}

@end
