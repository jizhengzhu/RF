//
//  JZDragView+drawRect.h
//  RF
//
//  Created by Jim on 2017/5/6.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZDragView.h"

@interface JZDragView (drawRect)

- (void)drawBorderMouseEnter:(NSRect)dirtyRect;

- (void)drawBorderMouseExit:(NSRect)dirtyRect;

- (void)drawDashBorder:(NSRect)dirtyRect;

- (void)drawMouseDownHighlightDashBorder:(NSRect)dirtyRect;

- (void)drawMouseEnterHighlightDashBorder:(NSRect)dirtyRect;

- (void)drawBorder:(NSRect)dirtyRect lineColor:(NSColor *)lineColor dash:(BOOL)isDash;

- (void)drawPlusSign:(NSRect)dirtyRect;

- (void)drawMouseDownHighlightPlusSign:(NSRect)dirtyRect;

- (void)drawMouseEnterHighlightPlusSign:(NSRect)dirtyRect;

- (void)drawPlusSign:(NSRect)dirtyRect lineColor:(NSColor *)lineColor;

- (void)drawTranslucentBackground:(NSRect)dirtyRect;

- (void)drawShadow;

@end
