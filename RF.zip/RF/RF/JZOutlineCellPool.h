//
//  JZOutlineCellPool.h
//  RF
//
//  Created by Jim on 2017/5/9.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@class JZOutlineCell;
@interface JZOutlineCellPool : NSObject

@property (nonatomic) NSMutableDictionary *outlineCellPool;

- (void)addOutlineCell:(JZOutlineCell *)outlineCell;

- (JZOutlineCell *)findOutlineCellByItemName:(NSString *)itemName;

- (void)refreshOutlineCellDisplayWithFirstResponder:(id)firstResponder;

@property BOOL main;

@end
