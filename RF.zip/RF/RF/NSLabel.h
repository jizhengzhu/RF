//
//  NSLabel.h
//  RF
//
//  Created by Jim on 2017/5/6.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSLabel : NSView

@property (nonatomic, copy) NSString *text;

@property (nonatomic) NSFont *font;

@property (nonatomic) NSLineBreakMode lineBreakMode;

@property (nonatomic) NSTextAlignment alignment;

@property (nonatomic) NSColor *textColor;

@property (nonatomic) NSColor *backgroundColor;

@property (nonatomic) CGFloat cornerRadius;

/**
 * 当autoResize为YES，且alignment为NSTextAlignmentCenter时使用
 */
@property (nonatomic) NSColor *wrapperBackgroundColor;

@property (nonatomic) CGFloat wrapperCornerRadius;

/**
 * 默认为NO，如果设置为YES，lineBreakMode的设置就无效
 */
@property (nonatomic) BOOL autoResize;

- (void)drawShadow:(NSColor *)shadowColor;

@end
