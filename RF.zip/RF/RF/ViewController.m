//
//  ViewController.m
//  RF
//
//  Created by Jim on 2017/4/25.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "ViewController.h"
#import "CustomSize.h"
#import "JZMainView.h"
#import "JZOutlineViewDelegate.h"
#import "JZOutlineViewDataSource.h"
#import "JZFilterView.h"
#import "JZLogToolView.h"
#import "NSLabel.h"
#import "JZApplicationManager.h"
#import "JZOutlineView.h"
#import "JZLogDragView.h"
#import "NSArray+itemName.h"
#import "JZMainSuperView.h"
#import "JZOutlineCell.h"
#import "JZViewControllerFrame.h"
#import "JZLogScrollView.h"

@interface ViewController () <JZLogDragViewDelegate>
{
    NSString *_itemName;
}
@property (nonatomic) BOOL logIsShow;

@property (nonatomic) JZViewControllerFrame *viewControllerFrame;

@end

@implementation ViewController

- (JZViewControllerFrame *)viewControllerFrame
{
    if (!_viewControllerFrame) {
        
        _viewControllerFrame = [[JZViewControllerFrame alloc] initWithRect:self.view.bounds];
    }
    return _viewControllerFrame;
}

- (void)setLogIsShow:(BOOL)logIsShow
{
    _logIsShow = logIsShow;
    
    if (logIsShow == NO) {
        
        self.logDragView.hidden = YES;
        
        self.logScrollView.hidden = YES;
        
        self.filterView.hidden = YES;
        
        self.cleanButton.hidden = YES;
        
        [self.showAndHiddenLogButton setImage:[NSImage imageNamed:@"show"]];
        
    } else {
        
        self.logDragView.hidden = NO;
        
        self.logScrollView.hidden = NO;
        
        self.filterView.hidden = NO;
        
        self.cleanButton.hidden = NO;
        
        [self.viewControllerFrame refreshFrameWithRect:self.view.bounds];
        
        self.logDragView.frame = self.viewControllerFrame.logDragViewFrame;
        
        self.logScrollView.frame = self.viewControllerFrame.logScrollViewFrame;
                
        [self.showAndHiddenLogButton setImage:[NSImage imageNamed:@"hidden"]];
    }
}

- (void)viewDidLoad {
    
    [super viewDidLoad];

    [self.filterView adjustBorder];
    
    self.logIsShow = NO;
    
    self.showAndHiddenLogButton.imageScaling = NSImageScaleProportionallyUpOrDown;
    
    self.logDragView.delegate = self;
    //监测tableview滚动
    [[NSNotificationCenter defaultCenter] addObserver:self
                                            selector:@selector(tableviewDidScroll:)
                                                name:NSViewBoundsDidChangeNotification
                                              object:[[_outlineView enclosingScrollView] contentView]];
    
    NSString *itemName = [[NSUserDefaults standardUserDefaults] objectForKey:keyItemName];
    
    if (itemName == nil) {
        
        itemName = @"JZDailyBreakdownInsertConfig";
        
        [[NSUserDefaults standardUserDefaults] setObject:itemName forKey:keyItemName];
        
        [[NSUserDefaults standardUserDefaults] synchronize];
        
    }
    NSLog(@"%s_itemName = %@", __FUNCTION__, itemName);
    
    _itemName = itemName;
    
    [self.mainView setItemName:itemName];
    
    [[NSUserDefaults standardUserDefaults] setObject:itemName forKey:keyItemName];
    
    [[[JZApplicationManager manager] pageManagerArray] addObject:itemName];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(outlineCellMouseDown:) name:JZOutlineCellNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickTitlebarLeftOrRightBtn:) name:JZTitlebarLeftOrRightBtnNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showLogViewNofification:) name:JZShowLogStatusNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(windowBecameMain) name:NSWindowDidBecomeMainNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(windowResignMain) name:NSWindowDidResignMainNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(beginRunPythonFile) name:RunPythonFileNotification object:nil];
}

- (void)viewWillAppear
{
    [super viewWillAppear];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(windowDidResize:)
                                                 name:NSWindowDidResizeNotification
                                               object:self.view.window];
    
}

- (void)viewDidAppear
{
    [super viewDidAppear];
    
    [self delayedAnimation:0.5];
}

- (void)delayedAnimation:(CGFloat)time
{
    dispatch_time_t dispatchtime = dispatch_time(DISPATCH_TIME_NOW, time * NSEC_PER_SEC);
    
    dispatch_after(dispatchtime, dispatch_get_main_queue(), ^{
        
        NSString *notificationName = [NSString stringWithFormat:@"%@%@", _itemName, AnimationNotification];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationName object:nil];
    });
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    
    NSLog(@"representedObject = %@", representedObject);
    // Update the view, if already loaded.
}

#pragma mark - NSNotificationCenter
// tableview滚动处理
-(void)tableviewDidScroll:(NSNotification *)notification
{
    NSClipView *contentView = [notification object];
    CGFloat scrollY = contentView.visibleRect.origin.y;
    NSLog(@"滚动 %.1f", scrollY);
    
    [[JZApplicationManager manager] refreshOutlineCellDisplay];
}

- (void)windowDidResize:(NSNotification *)notification
{
//    NSWindow *window = notification.object;
    
//    self.logView.frame = NSMakeRect(tbwidth, 0, self.view.frame.size.width - tbwidth, self.logView.frame.size.height);
    
    for (NSTitlebarAccessoryViewController *controller in self.view.window.titlebarAccessoryViewControllers) {
        controller.view.frame = NSMakeRect(0, 0, self.view.frame.size.width, 40);

    }
    
    [self.viewControllerFrame refreshFrameWithRect:self.view.bounds];
    
    self.logDragView.frame = self.viewControllerFrame.logDragViewFrame;
    
    self.logScrollView.frame = self.viewControllerFrame.logScrollViewFrame;
    
    self.mainView.frame = self.viewControllerFrame.mainViewFrame;

}

- (void)clickTitlebarLeftOrRightBtn:(NSNotification *)note
{
    NSString *itemName = [note userInfo][keyItemName];
    
    [self.mainView setItemName:itemName];
    
    JZOutlineCell *outlineCell = [[[JZApplicationManager manager] outlineCellPool] findOutlineCellByItemName:itemName];
    
    [[NSApplication sharedApplication].keyWindow makeFirstResponder:outlineCell];
    
    [[JZApplicationManager manager] setFirstResponder:outlineCell];
    
    [[JZApplicationManager manager] refreshOutlineCellDisplay];
    
    [[JZApplicationManager manager] refreshFileDragViewDisplay];
}

- (void)showLogViewNofification:(NSNotification *)note
{
    NSDictionary *logInfo = [note userInfo];
    
    NSString *logKeyString = logInfo[@"logKeyString"];
    
    NSString *logKeyStatus = logInfo[@"logKeyStatus"];
    
    if ([logKeyStatus isEqualToString:@"showLog"]) {
        
        self.logIsShow = YES;

    }
    
    self.logScrollView.textView.string = logKeyString;
    
    self.logScrollView.textView.textColor = [NSColor whiteColor];
}

- (void)windowBecameMain
{
    NSLog(@"%s", __FUNCTION__);
    
    [[JZApplicationManager manager] setMain:YES];
}

- (void)windowResignMain
{
    NSLog(@"%s", __FUNCTION__);
    
    [[JZApplicationManager manager] setMain:NO];
}

- (void)beginRunPythonFile
{
    self.logScrollView.textView.string = @"";
}

#pragma mark - JZOutlineCellNotification 方法
- (void)outlineCellMouseDown:(NSNotification *)note
{
    NSString *itemName = [[note userInfo] objectForKey:keyItemName];
    
    [self.mainView setItemName:itemName];
        
    JZOutlineCell *outlineCell = [[[JZApplicationManager manager] outlineCellPool] findOutlineCellByItemName:itemName];
    
    [[NSApplication sharedApplication].keyWindow makeFirstResponder:outlineCell];
//    
//    [[JZApplicationManager manager] setFirstResponder:outlineCell];
//    
//    [[JZApplicationManager manager] refreshOutlineCellDisplay];
//    
//    [[JZApplicationManager manager] refreshFileDragViewDisplay];
    
    [[NSUserDefaults standardUserDefaults] setObject:itemName forKey:keyItemName];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSString *lastItemName = [[[JZApplicationManager manager] pageManagerArray] lastObject];
    
    if ([lastItemName isEqualToString:itemName] == NO) {
        
        [[[JZApplicationManager manager] pageManagerArray] addObject:itemName];

    }
    
    _itemName = itemName;
    
    [self delayedAnimation:0.2];

}

#pragma mark - JZLogDragViewDelegate 方法
- (void)logDragView:(JZLogDragView *)logDragView mouseDrag:(NSEvent *)event
{
    NSPoint location = [event locationInWindow];
    
    if (location.y > self.view.frame.size.height - 100) {
        
        [[NSCursor resizeDownCursor] set];
        
        self.viewControllerFrame.logViewHeight = self.view.bounds.size.height - toolheight - logdragheight;
        
    } else if (location.y > 125 && location.y < self.view.frame.size.height - 100) {
        
        self.viewControllerFrame.logViewHeight = location.y - toolheight;
        
    } else if(location.y < 125) {
        
        [[NSCursor resizeUpCursor] set];
                
        self.logIsShow = NO;
    }
    
    [self.viewControllerFrame refreshFrameWithRect:self.view.bounds];
    
    self.logDragView.frame = self.viewControllerFrame.logDragViewFrame;
    
    self.logScrollView.frame = self.viewControllerFrame.logScrollViewFrame;
    
    self.mainView.frame = self.viewControllerFrame.mainViewFrame;
}


- (IBAction)cleanLog:(NSButton *)sender {

    self.logScrollView.textView.string = @"";
}

- (IBAction)showAndHiddenLog:(id)sender {

    self.logIsShow = !self.logIsShow;
    
}

#pragma mark - dealloc 方法
- (void)dealloc
{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NSViewBoundsDidChangeNotification object:[[_outlineView enclosingScrollView] contentView]];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:JZOutlineCellNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:JZTitlebarLeftOrRightBtnNotification object:nil];

    [[NSNotificationCenter defaultCenter] removeObserver:self name:JZShowLogStatusNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NSWindowDidBecomeMainNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NSWindowDidResignMainNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NSWindowDidResizeNotification object:self.view.window];
        
    NSString *notificationName = [NSString stringWithFormat:@"%@%@", _itemName, AnimationNotification];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationName object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:RunPythonFileNotification object:nil];
}
@end
