//
//  JZFileDragViewPool.m
//  RF
//
//  Created by Jim on 2017/5/9.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZFileDragViewPool.h"
#import "JZFileDragView.h"

@interface JZFileDragViewPool ()

@property (nonatomic) NSMutableDictionary *fileDragViewPool;

@end

@implementation JZFileDragViewPool

- (JZFileDragView *)findFileDragViewByKey:(NSString *)key
{
    return [self.fileDragViewPool objectForKey:key];
}

- (void)addFileDragView:(JZFileDragView *)fileDragView
{
    NSString *key = [NSString stringWithFormat:@"%@%@", fileDragView.itemName, fileDragView.viewName];
    
    [self.fileDragViewPool setObject:fileDragView forKey:key];
}

- (void)refreshFileDragViewDisplayWithFirstResponder:(id)firstResponder
{
    
    if ([firstResponder isKindOfClass:[JZFileDragView class]]) {
        
        NSString *string = [NSString stringWithFormat:@"%@%@", [firstResponder itemName], [firstResponder viewName]];
        
        for (NSString *key in self.fileDragViewPool) {
            
            JZFileDragView *fileDragView = [self.fileDragViewPool objectForKey:key];
            
            if ([key isEqualToString:string]) {
                
                fileDragView.isSelected = YES;
                
            } else {
                
                fileDragView.isSelected = NO;
            }
        }
    }
}

@end
