//
//  JZWindowController.m
//  RF
//
//  Created by Jim on 2017/4/25.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZWindowController.h"
#import "JZTitlebarAttributeView.h"
#import "CustomSize.h"
#import "JZCollectionViewItem.h"
#import "JZWindow.h"

@interface JZWindowController ()

@property (nonatomic) IBInspectable CGFloat titleBarHeight;

@property (nonatomic, strong) NSTitlebarAccessoryViewController *titlebarAccessoryViewController;

@property (nonatomic, strong) JZTitlebarAttributeView *titlebarAttributeView;

@end

@implementation JZWindowController

- (JZTitlebarAttributeView *)titlebarAttributeView
{
    if (!_titlebarAttributeView) {
        
        _titlebarAttributeView = [[JZTitlebarAttributeView alloc] initWithFrame:NSMakeRect(0, 0, windowwidth, 60)];
    }
    
    return _titlebarAttributeView;
}

- (NSTitlebarAccessoryViewController *)titlebarAccessoryViewController
{
    if (!_titlebarAccessoryViewController) {
        
        _titlebarAccessoryViewController = [NSTitlebarAccessoryViewController new];
        
        _titlebarAccessoryViewController.view = self.titlebarAttributeView;
        
        [_titlebarAccessoryViewController setLayoutAttribute:NSLayoutAttributeRight];
    }
    
    return _titlebarAccessoryViewController;
}

- (void)windowDidLoad {
    [super windowDidLoad];

//    self.titleBarHeight = 50;

    [self.window setTitleVisibility:NSWindowTitleHidden];

    [self.window addTitlebarAccessoryViewController:self.titlebarAccessoryViewController];
    
    self.window.contentMinSize = NSMakeSize(windowwidth, windowheight);
    
    self.window.titlebarAppearsTransparent = YES;
    
    self.window.backgroundColor = [NSColor clearColor];
    
//    [self.window setLevel:NSStatusWindowLevel];
//    [self.window setFrame:NSMakeRect(0, 0, windowwidth, windowheight) display:YES animate:YES];

//    self.window.showsResizeIndicator = YES;
    
}

- (float)defaultTitleBarHeight {
    NSRect frame = NSMakeRect(0, 0, [NSApplication sharedApplication].keyWindow.frame.size.width, [NSApplication sharedApplication].keyWindow.frame.size.height);
    
    NSRect contentRect;
    
#pragma clang diagnostic push
    
#pragma clang diagnostic ignored"-Wdeprecated-declarations"
    
    NSProcessInfo *processInfo = [[NSProcessInfo alloc] init];
    
    if (processInfo.operatingSystemVersion.minorVersion >= 12) {
        
        contentRect = [NSWindow contentRectForFrameRect:frame styleMask:NSWindowStyleMaskTitled];
        
    } else {
        
        contentRect = [NSWindow contentRectForFrameRect:frame styleMask:NSTitledWindowMask];
        
    }
    
    
#pragma clang diagnostic pop
    
    return NSHeight(frame) - NSHeight(contentRect);
}

- (void)setTitleBarHeight:(CGFloat)titleBarHeight {
    
        titleBarHeight = MAX(titleBarHeight,[self defaultTitleBarHeight]);
        CGFloat delta = titleBarHeight - _titleBarHeight;
    _titleBarHeight = titleBarHeight;
    
    if (_titlebarAccessoryViewController) {
        [self.window removeTitlebarAccessoryViewControllerAtIndex:0];
    }
    
    NSView *view = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, windowwidth, titleBarHeight - [self defaultTitleBarHeight])];
    _titlebarAccessoryViewController = [NSTitlebarAccessoryViewController new];
    _titlebarAccessoryViewController.view = view;
    _titlebarAccessoryViewController.fullScreenMinHeight = 40;

    [self.window addTitlebarAccessoryViewController:_titlebarAccessoryViewController];
    
    NSRect frame = self.window.frame;
    frame.size.height += delta;
    frame.origin.y -= delta;
    
    [self.window setFrame:frame display:NO]; // NO is important.
}



@end
