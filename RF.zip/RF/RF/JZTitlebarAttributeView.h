//
//  JZTitlebarAttributeView.h
//  RF
//
//  Created by Jim on 2017/4/26.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class CustomWindowButtonView;
@interface JZTitlebarAttributeView : NSView

@property (nonatomic, strong) CustomWindowButtonView *windowButtonView;

@property (nonatomic, strong) NSButton *runBtn;

@property (nonatomic, strong) NSButton *leftBtn;

@property (nonatomic, strong) NSButton *rightBtn;

@property (nonatomic, strong) NSTextField *titleTF;

@property (nonatomic, strong) NSButton *resizeButton;

@end
