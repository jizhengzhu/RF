//
//  JZMainView.h
//  RF
//
//  Created by Jim on 2017/4/26.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface JZMainView : NSView

@property (copy) NSString *itemName;

- (void)updateItemName:(NSString *)itemName;

- (void)runPythonFile;

- (void)runPythonCompletion:(NSNotification *)note;

@end
