//
//  JZAlertTool.m
//  RF
//
//  Created by Jim on 2017/5/12.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZAlertTool.h"

@implementation JZAlertTool

+ (NSAlert *)showAlertWithMessageText:(NSString *)messageText informativeText:(NSString *)informativeText window:(NSWindow *)window
{
    NSError *error = [NSError errorWithDomain:NSURLErrorDomain code:400 userInfo:nil];
    
    NSAlert *alert = [NSAlert alertWithError:error];
    
    alert.messageText = messageText;
    
    alert.informativeText = informativeText;
    
    alert.icon = [NSImage imageNamed:@"RF1024"];
    
    alert.alertStyle = NSAlertStyleWarning;
    
    [alert beginSheetModalForWindow:window completionHandler:^(NSModalResponse returnCode) {
        
        NSLog(@"%ld", (long)returnCode);
    }];
    
    return alert;
}

@end
