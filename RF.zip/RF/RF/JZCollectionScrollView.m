//
//  JZCollectionScrollView.m
//  RF
//
//  Created by Jim on 2017/5/13.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZCollectionScrollView.h"
#import "JZCollectionViewItem.h"
#import "JZCollectionView.h"
#import "CustomSize.h"
#import "JZMainView.h"
#import "JZApplicationManager.h"

@interface JZCollectionScrollView ()

@property (nonatomic) NSScrollView *scrollView;

@property (nonatomic) JZCollectionView *collectionView;

@end

@implementation JZCollectionScrollView

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        
        [self addSubview:self.scrollView];
        
        self.wantsLayer = YES;
        
        self.layer.borderColor = [NSColor colorWithWhite:1 alpha:1].CGColor;
        
        self.layer.borderWidth = 1;
        //
        self.layer.cornerRadius = 6;
        
        self.layer.backgroundColor = [NSColor colorWithWhite:0 alpha:0.1].CGColor;
        
    }
    return self;
}

- (void)setFrame:(NSRect)frame
{
    [super setFrame:frame];
    
    self.scrollView.frame = self.bounds;
    
}

- (NSScrollView *)scrollView
{
    if (!_scrollView) {
        
        _scrollView = [[NSScrollView alloc] initWithFrame:self.bounds];
        
        [_scrollView setDocumentView:self.collectionView];
        
        [_scrollView setDrawsBackground:NO];
        
        [_scrollView setHasVerticalScroller:YES];
        
        [_scrollView setHasHorizontalScroller:NO];
        
        [_scrollView setScrollerStyle:NSScrollerStyleOverlay];
        
        _scrollView.backgroundColor = [NSColor clearColor];
        
        //        _textContainerView.borderType = NSBezelBorder;
        
        _scrollView.scrollerKnobStyle = NSScrollerKnobStyleLight;
        
        //        [_textContainerView setAutoresizingMask:NSViewWidthSizable | NSViewHeightSizable];
        
        //        _textContainerView.verticalLineScroll = 2;
        
        _scrollView.verticalScrollElasticity = NSScrollElasticityAllowed;    // 允许在纵轴有弹性
        
        _scrollView.horizontalScrollElasticity = NSScrollElasticityNone;     // 不允许在横轴有弹性
        
        _scrollView.autohidesScrollers = YES;
        
    }
    return _scrollView;
}

- (JZCollectionView *)collectionView
{
    if (!_collectionView) {
        
        _collectionView = [[JZCollectionView alloc] initWithFrame:self.bounds];
        
        JZCollectionViewItem *itemPrototype = [[JZCollectionViewItem alloc] init];
        
        _collectionView.itemPrototype = itemPrototype;
        
        _collectionView.backgroundColors = @[[NSColor clearColor]];
        
    }
    return _collectionView;
}

- (void)updateItemName:(NSString *)itemName
{
    _itemName = [itemName copy];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshCollectionView) name:[NSString stringWithFormat:@"%@%@", itemName, RefreshCollectionViewNotification] object:nil];
    
    [self refreshCollectionView];
}

- (void)addModuleWithModuleName:(NSString *)moduleName
{
    NSString *key = [NSString stringWithFormat:@"%@%@", self.itemName, ModuleArrayKey];
    
    NSLog(@"ModuleArrayKey = %@", key);
    
    NSMutableArray *mArray = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    
    BOOL isEqual = NO;
    
    for (NSDictionary *dict in mArray) {
        
        NSString *cellName = dict[@"cellName"];
        
        if ([cellName isEqualToString:moduleName]) {
            
            isEqual = YES;
            
            break;
        }
    }
    
    if (isEqual == NO) {
        
        NSMutableArray *anotherMArray = [NSMutableArray array];
        
        for (NSDictionary *dict in mArray) {
            
            NSString *cellName = dict[@"cellName"];
            
            if (cellName.length > 0) {
                
                [anotherMArray addObject:dict];
            }
        }
        
        [anotherMArray addObject:@{@"itemName":self.itemName, @"cellName":moduleName}];
        
        self.collectionView.content = anotherMArray;
        
        [[NSUserDefaults standardUserDefaults] setObject:anotherMArray forKey:key];
        
        [[NSUserDefaults standardUserDefaults] synchronize];
        
    }
    
    
}

#pragma mark - NSNotification

- (void)refreshCollectionView
{
    NSString *key = [NSString stringWithFormat:@"%@%@", self.itemName, ModuleArrayKey];
    
    NSLog(@"ModuleArrayKey = %@", key);
    
    NSMutableArray *mArray = [[NSUserDefaults standardUserDefaults] objectForKey:key];
    
    if (mArray == nil) {
        
        mArray = [NSMutableArray array];
        
        [[NSUserDefaults standardUserDefaults] setObject:mArray forKey:key];
        
        [[NSUserDefaults standardUserDefaults] synchronize];
        
    }
    
    NSMutableArray *anotherMArray = [NSMutableArray array];
    
    for (NSDictionary *dict in mArray) {
        
        NSString *cellName = dict[@"cellName"];
        
        if (cellName.length > 0) {
            
            [anotherMArray addObject:dict];
        }
    }
    
    self.collectionView.content = anotherMArray;
    
    [[JZApplicationManager manager] refreshCollectionViewDisplay];
    
}

#pragma mark - dealloc

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:[NSString stringWithFormat:@"%@%@", self.itemName, RefreshCollectionViewNotification]
                                                  object:nil];
}

@end
