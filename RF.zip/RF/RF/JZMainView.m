//
//  JZMainView.m
//  RF
//
//  Created by Jim on 2017/4/26.
//  Copyright © 2017年 Jim. All rights reserved.
//
 
#import "JZMainView.h"
#import "CustomSize.h"
#import "JZApplicationManager.h"
#import <objc/runtime.h>

@interface JZMainView ()

@end

@implementation JZMainView


- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        NSString *className = NSStringFromClass([self class]);
        
        NSString *notificationName = [NSString stringWithFormat:@"%@%@", className, RunPythonFileNotification];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(runPythonFile) name:notificationName object:nil];
    }
    return self;
}

- (void)runPythonCompletion:(NSNotification *)note
{
    NSDictionary *userInfo = [note userInfo];
    
    NSString *outputString = userInfo[@"outputString"];
    
    NSString *errorString = userInfo[@"errorString"];
    
    NSString *logKeyString;
    
    NSString *logKeyStatus;
    
    if (outputString.length != 0 && errorString.length == 0) {
        
        logKeyString = outputString;
        
        logKeyStatus = @"doNothing";
        
    } else if (outputString.length == 0 && errorString.length != 0) {
        
        logKeyString = [NSString stringWithFormat:@"Python Error:\n%@", errorString];
        
        logKeyStatus = @"showLog";
        
    } else if (outputString.length != 0 && errorString.length != 0) {
        
        logKeyString = [NSString stringWithFormat:@"Python Error:\n%@\nPython Output:\n%@", errorString, outputString];
        
        logKeyStatus = @"showLog";
        
    } else {
        
        logKeyString = @"";
        
        logKeyStatus = @"doNothing";
    }
    
    NSDictionary *logInfo = @{@"logKeyString":logKeyString,
                              @"logKeyStatus":logKeyStatus};
    
    [[NSNotificationCenter defaultCenter] postNotificationName:JZShowLogStatusNotification object:nil userInfo:logInfo];
}

- (void)updateItemName:(NSString *)itemName
{
    _itemName = [itemName copy];
}

/**
 *  这个方法不写其实也可以，因为通知的observer是子类，运行时将执行子类的runPythonFile方法，写这个方法只是为了消除警告
 */
- (void)runPythonFile
{
    NSLog(@"%s", __FUNCTION__);
}

@end
