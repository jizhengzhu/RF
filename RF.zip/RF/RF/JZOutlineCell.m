//
//  JZOutlineCell.m
//  RF
//
//  Created by Jim on 2017/5/9.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZOutlineCell.h"
#import "CustomSize.h"

@interface JZOutlineCell ()

@property (nonatomic) NSImageView *imgView;

@end

@implementation JZOutlineCell

@synthesize backgroundColor = _backgroundColor;

- (NSLabel *)label
{
    if (!_label) {
        
        _label = [[NSLabel alloc] initWithFrame:NSMakeRect(20, 0, self.bounds.size.width - 20, self.bounds.size.height)];
        
        _label.font = [NSFont systemFontOfSize:15];
        
        
    }
    return _label;
}

- (void)setSelectable:(BOOL)selectable
{
    _selectable = selectable;
    
    if (selectable == YES) {
        
        self.label.frame = NSMakeRect(30, 0, self.bounds.size.width - 30, self.bounds.size.height);
        
    } else {
        
        self.label.frame = NSMakeRect(20, 0, self.bounds.size.width - 20, self.bounds.size.height);
    }
}

- (NSImageView *)imgView
{
    if (!_imgView) {
        
        _imgView = [[NSImageView alloc] initWithFrame:NSMakeRect(30, 5, self.bounds.size.height - 10, self.bounds.size.height - 10)];
        
    }
    return _imgView;
}

- (void)setImage:(NSImage *)image
{
    _image = image;
    
    self.imgView.image = image;
    
    self.label.frame = NSMakeRect(35 + self.imgView.bounds.size.width, 0, self.bounds.size.width - (35 + self.imgView.bounds.size.width), self.bounds.size.height);
}

- (void)setBackgroundColor:(NSColor *)backgroundColor
{
    _backgroundColor = backgroundColor;
    
    [self setNeedsDisplay:YES];
}

- (NSColor *)backgroundColor
{
    if (!_backgroundColor) {
        
        _backgroundColor = [NSColor clearColor];
    }
    return _backgroundColor;
}

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        
        [self addSubview:self.label];
        
        [self addSubview:self.imgView];
        
    }
    return self;
}

//此方法需要在改变的时候手动调用一次(父类的方法)
- (void)updateTrackingAreas
{
    NSArray *trackings = [self trackingAreas];
    for (NSTrackingArea *tracking in trackings)
    {
        [self removeTrackingArea:tracking];
    }
    
    //添加NSTrackingActiveAlways掩码可以使视图未处于激活或第一响应者时也能响应相应的方法
    NSTrackingArea *trackingArea = [[NSTrackingArea alloc] initWithRect:[self bounds]
                                                                options:NSTrackingMouseEnteredAndExited|NSTrackingMouseMoved|NSTrackingActiveAlways
                                                                  owner:self
                                                               userInfo:nil];
    [self addTrackingArea:trackingArea];
}

- (void)mouseDown:(NSEvent *)event
{
    [super mouseDown:event];
    NSLog(@"%s", __FUNCTION__);
    
    if (_selectable == YES) {
        
        [[NSNotificationCenter defaultCenter] postNotificationName:JZOutlineCellNotification object:nil userInfo:@{keyItemName:self.itemName}];

    }

}

- (void)mouseEntered:(NSEvent *)event
{
    [super mouseEntered:event];
    NSLog(@"%s", __FUNCTION__);
    
    if (_selectable == YES) {
        
        if (_isSelected == NO) {
            
            self.backgroundColor = [NSColor colorWithWhite:0 alpha:0.1];
            
        }
    }
}

- (void)mouseUp:(NSEvent *)event
{
    [super mouseUp:event];
    NSLog(@"%s", __FUNCTION__);
    
}

- (void)mouseExited:(NSEvent *)event
{
    [super mouseExited:event];
    NSLog(@"%s", __FUNCTION__);
    
    if (_selectable == YES) {
        
        if (_isSelected == NO) {
            
            self.backgroundColor = [NSColor clearColor];
            
        }
    }
}


- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    [self.backgroundColor setFill];
    
    NSBezierPath *path = [NSBezierPath bezierPathWithRect:dirtyRect];
    
    [path fill];
}

- (BOOL)acceptsFirstResponder
{
    return YES;
}

- (void)keyDown:(NSEvent *)event
{
    
}

@end
