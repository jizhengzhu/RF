//
//  JZLocalNotificationTool.m
//  RF
//
//  Created by Jim on 2017/5/12.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZLocalNotificationTool.h"
#import <AppKit/AppKit.h>

@implementation JZLocalNotificationTool

+ (NSUserNotification *)postNotificationWithTitle:(NSString *)title
                                         subtitle:(NSString *)subtitle
                                  informativeText:(NSString *)informativeText
                                       itemName:(NSString *)itemName
                              removedNotification:(NSUserNotification *)removedNotification
{
    NSUserNotification *notification = [[NSUserNotification alloc] init];
    
    notification.title = title;
    
    notification.subtitle = subtitle;
    
    notification.informativeText = informativeText;
    
//    notification.actionButtonTitle = @"Check";
    
    notification.contentImage = [NSImage imageNamed:@"search"];
    
//    NSUserNotificationAction *action = [NSUserNotificationAction actionWithItemName:itemName title:nil];
    
//    notification.additionalActions = @[action];
    
    notification.identifier = itemName;
    
    notification.soundName = NSUserNotificationDefaultSoundName;
    
    if (removedNotification != nil) {
        
        [[NSUserNotificationCenter defaultUserNotificationCenter] removeDeliveredNotification:removedNotification];
        
    }
    
    [[NSUserNotificationCenter defaultUserNotificationCenter] deliverNotification:notification];
        
    return notification;

}

@end
