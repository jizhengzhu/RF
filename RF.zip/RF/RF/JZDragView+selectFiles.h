//
//  JZDragView+selectFiles.h
//  RF
//
//  Created by Jim on 2017/5/6.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZDragView.h"

@interface JZDragView (selectFiles)

- (void)selectFiles:(NSArray *)fileTypes completion:(void(^)(NSString *filePath))completion;

@end
