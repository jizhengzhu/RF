//
//  NSArray+itemName.m
//  RF
//
//  Created by Jim on 2017/5/8.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "NSArray+itemName.h"

@implementation NSArray (itemName)

- (NSString *)itemName
{
    NSString *firstObject = [self firstObject];
    
    NSString *lastObject = [self lastObject];
    
    lastObject = [self takeOutSpecifyChar:@" " withString:lastObject];
    
    lastObject = [self takeOutSpecifyChar:@"&" withString:lastObject];
    
    return [NSString stringWithFormat:@"JZ%@%@", lastObject, firstObject];
}

- (NSString *)takeOutSpecifyChar:(NSString *)specifyChar withString:(NSString *)string
{
    NSArray *array = [string componentsSeparatedByString:specifyChar];
    
    NSMutableString *mString = [NSMutableString string];
    
    for (NSString *str in array) {
        
        [mString appendString:str];
    }
    
    return mString;
}

@end
