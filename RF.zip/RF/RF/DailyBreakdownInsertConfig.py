# _*_ encoding: UTF-8 _*_

# /usr/bin/env python

import xlrd, xlsxwriter

import sys, os.path

import csv, string

import time

# rawData文件的路径
rawDataFilePath = sys.argv[1]

print "Raw Data 文件路径为：" + rawDataFilePath

# antennaInformation文件的路径
antennaInformationFilePath = sys.argv[2]

print "Antenna Information 文件路径为：" + antennaInformationFilePath

# 将选取的module用逗号连接成字符串，
modulesString = sys.argv[3]

# 将module字符串转换成数组
modulesArray = modulesString.split(',')

# 系统用户的路径
outFilePath = sys.argv[4]

# 保存的文件名及路径
outFilePath = outFilePath + '/Desktop/DailyBreakdownInsertConfig.xlsx'

# 新建Excel文件
workbook = xlsxwriter.Workbook(outFilePath)

# 在新建的Excel文件中新建一张表命名为OTA_raw_data
worksheet = workbook.add_worksheet('OTA_raw_data')

# 读取antennaInformation源文件

if not os.path.isfile(antennaInformationFilePath):

    print "antenna information file path is not exist"

    sys.exit()

antennaInformationWorkBook = xlrd.open_workbook(antennaInformationFilePath)

# 读取antennaInformation源文件的BM表
BMWorkSheet = antennaInformationWorkBook.sheet_by_index(0)

class get_content(object):

	def __init__(self, rowIndex = None, colIndex = None):

		self._rowIndex = rowIndex

		self._colIndex = colIndex

	@property

	def getrow(self):

		for row in range(0, BMWorkSheet.nrows):

			if str(BMWorkSheet.cell_value(row, 0)).upper() == self._rowIndex.upper():
				
				return row

	@property

	def getcol(self):

		for col in range(0, BMWorkSheet.ncols):

			if self._colIndex == BMWorkSheet.cell_value(8, col):
				
				return col

print "打开rawDataFilePath路径下的文件，把整个csv文件读到内存中" 
# asvfile是一个可迭代的对象
with open(rawDataFilePath, 'rU') as csvfile:

#————————————————————————————————————————————————————————————————————————————————————————————
	print "由csvfile对象生成一个reader迭代器"
	reader = csv.reader(csvfile, dialect = 'excel')

	# 定义一个数组存储rawdata源文件中第一列的数据
	firstColumnArray = [];

	print "遍历整个csv文件，每个rowArray对应的就是一行内容组成的数组"
	for rowArray in reader:

		# 取每个rowArray的第0个值组成数组，就得到rawdata源文件第一列的内容
		firstColumnArray.append(rowArray[0])
#—————————————————————————————————————————————————————————————————————————————————————————————
	# 初始化一个整形变量，存储字符串'Product'所在的行数
	productRowNumber = 0

	print "遍历rawdata源文件第一列的数组并找出字符串'Product'所在的行数"
	for rowFirstValue in firstColumnArray:

		# 当找到字符串'Product'时跳出循环，这样得到的productRowNumber就是字符串'Product'所在的行数了
		if rowFirstValue.strip() == 'Product':

			break

		# 每次循环在判断之后productRowNumber 都自增1
		productRowNumber = productRowNumber + 1
#—————————————————————————————————————————————————————————————————————————————————————————————
	print "使迭代器回到初始状态"
	# 这种方法在多线程时会出问题，多线程中应该重新读文件创建一个迭代器
	csvfile.seek(0)

	print "遍历整个csv文件，找出Product所在的那一行，取出那一行对应的数组"
	for i, rows in enumerate(reader):

		if i == productRowNumber:
			
			productArray = rows

			break

#—————————————————————————————————————————————————————————————————————————————————————————————
	# 初始化一个整形变量存储WOSN所在的列数
	WOSNColNumber = 0

	print "遍历productArray数组，找出WOSN这一列所在的列数"
	for product in productArray:

		if product.strip() == 'WOSN':
		
			break	

		WOSNColNumber = WOSNColNumber + 1
#—————————————————————————————————————————————————————————————————————————————————————————————
	print "使迭代器回到初始状态，但是.line_num不会归0"
	# 这种方法在多线程时会出问题，多线程中应该重新读文件创建一个迭代器
	csvfile.seek(0)

	# 定义一个数组存储WOSN这一列的内容
	WOSNArray = []

	# 获取迭代器的line_num
	readerLineNum = reader.line_num

	print "遍历整个csv文件，将WOSN这一列的内容存到WOSNArray数组中"
	for rowArray in reader:

		# 取第7行后每一行内容中WOSN所在列的值，存入WOSNArray数组中
		if reader.line_num > readerLineNum + 7:

			WOSNArray.append(rowArray[WOSNColNumber])
	
#—————————————————————————————————————————————————————————————————————————————————————————————
	print "把WOSN的标题写在'Product'所在行的第12列"
	worksheet.write(productRowNumber, 12, 'WOSN')

	# 设置12列的宽度
	worksheet.set_column('M:M', 20)
#—————————————————————————————————————————————————————————————————————————————————————————————
	# 初始化一个整形变量WOSNRowNumber存储WOSN在WOSN列下的行数
	WOSNRowNumber = 7

	print "从第7行开始，把WOSNArray的内容存到12列"
	for WOSN in WOSNArray:

		worksheet.write(WOSNRowNumber, 12, WOSNArray[WOSNRowNumber - 7])

		WOSNRowNumber = WOSNRowNumber + 1
#—————————————————————————————————————————————————————————————————————————————————————————————
	print "遍历modulesArray数组，将选择的module名（即列标题）依次插入到第一行'WOSN'后面"
	for moduleIndex in range(0, len(modulesArray)):

		worksheet.write(productRowNumber, 13 + moduleIndex, modulesArray[moduleIndex])

#—————————————————————————————————————————————————————————————————————————————————————————————
	# 初始化一个记录行数的整形变量rowNumber
	rowNumber = 0

	# 初始化一个存储WOSN的的字典，key为WOSN的名字，value为WOSN在BMWorkSheet表中的列数
	configDict = dict()
#—————————————————————————————————————————————————————————————————————————————————————————————
	print "使迭代器回到初始状态"
	# 这种方法在多线程时会出问题，多线程中应该重新读文件创建一个迭代器
	csvfile.seek(0)

	# 获取迭代器的line_num
	readerLineNum = reader.line_num

	print "遍历整个csv文件,往worksheet表里写数据"
	# 每个rowArray对应的就是一行内容组成的数组
	for rowArray in reader:
				
		# 从第7行（以第0行开始算）开始写数据
		if reader.line_num > readerLineNum + 7:

			# 判断第12列（即WOSN列）的内容是否在configDict字典中，第一次循环肯定不在字典中，后面的循环可能就存在了
			if rowArray[12] not in configDict:

				# 将WOSN在该行的内容作为参数初始化一个config对象
				config = get_content(None, rowArray[12])

				# 将WOSN在BMWorkSheet表中的列数存到字典configDict中，key为WOSN的名字
				configDict[rowArray[12]] = config.getcol

			# 按插入的modulesArray数组长度循环

			for moduleIndex in range(0, len(modulesArray)):

				# 如果module包含'&'，感觉这个判断好像没用，但还是写上吧，毕竟是旺枝留下的，可能是某种特殊情况
				position = modulesArray[moduleIndex].find('&')

				if position > 0:
					
					firstString = get_content(modulesArray[moduleIndex][:position])

					lastString = get_content(modulesArray[moduleIndex][position + 1:])

					firstContent = BMWorkSheet.cell_value(firstString.getrow, configDict[rowArray[12]])

					lastContent = BMWorkSheet.cell_value(lastString.getrow, configDict[rowArray[12]])

					worksheet.write(rowNumber, 13 + moduleIndex, firstContent + '&' + lastContent)

				else:

					# 将插入的module作为参数初始化一个module对象
					module = get_content(modulesArray[moduleIndex])

					# 如果module在BMWorkSheet表格中的行数，以及config的列数都存在
					if module.getrow and configDict[rowArray[12]]:
						
						# module在表格中的行数和config在表格中的列数就能定位在BMWorkSheet的值，将这个值插入到新建的表中
						worksheet.write(rowNumber, 13 + moduleIndex, BMWorkSheet.cell_value(module.getrow, configDict[rowArray[12]]))

		# 遍历插入其他数据
		for colNumber in range(0, len(rowArray) + len(modulesArray)):

			if colNumber < 12:
				
				worksheet.write(rowNumber, colNumber, rowArray[colNumber])

			elif colNumber > 12 + len(modulesArray):

				worksheet.write(rowNumber, colNumber, rowArray[colNumber - len(modulesArray)])

		rowNumber = rowNumber + 1

workbook.close()
