//
//  JZFileDragViewPool.h
//  RF
//
//  Created by Jim on 2017/5/9.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@class JZFileDragView;

@interface JZFileDragViewPool : NSObject

@property (nonatomic, readonly) NSMutableDictionary *fileDragViewPool;

- (void)addFileDragView:(JZFileDragView *)fileDragView;

- (JZFileDragView *)findFileDragViewByKey:(NSString *)key;

- (void)refreshFileDragViewDisplayWithFirstResponder:(id)firstResponder;

@end
