//
//  JZOutlineViewDelegate.m
//  RF
//
//  Created by Jim on 2017/4/27.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZOutlineViewDelegate.h"
#import "JZApplicationManager.h"
#import "NSArray+itemName.h"
#import "JZOutlineCell.h"
#import "NSLabel.h"
#import "CustomSize.h"

static const CGFloat cellHeight = 30;

@implementation JZOutlineViewDelegate

// 如果不实现这个方法，下面的方法- (nullable NSTableRowView *)outlineView:(NSOutlineView *)outlineView rowViewForItem:(id)item将无法显示内容
- (nullable NSView *)outlineView:(NSOutlineView *)outlineView viewForTableColumn:(nullable NSTableColumn *)tableColumn item:(id)item
{
    return nil;
}

// 自定义每一行的视图，用这个方法定义视图，textField的文字在被选中时会自动变为白色，默认为黑色，上面的方法始终默认为黑色
- (nullable NSTableRowView *)outlineView:(NSOutlineView *)outlineView rowViewForItem:(id)item
{
    NSTableRowView *rowView = [[NSTableRowView alloc] initWithFrame:NSMakeRect(0, 0, outlineView.bounds.size.width, cellHeight)];
    
//    rowView.selectionHighlightStyle = NSTableViewSelectionHighlightStyleSourceList;

    NSString *itemName, *text;
    BOOL selectable;
    
    if ([item isKindOfClass:[NSDictionary class]]) {
        
        itemName = item[@"parent"];
        
        text = [NSString stringWithFormat:@"%@", item[@"parent"]];
        
        selectable = NO;
        
    } else {
        
        itemName = [item itemName];
        
        text = [NSString stringWithFormat:@"%@", [item firstObject]];
        
        selectable = YES;
    }
    
    JZOutlineCell *outlineCell = [[[JZApplicationManager manager] outlineCellPool] findOutlineCellByItemName:itemName];
    
    if (outlineCell == nil) {
        
        outlineCell = [[JZOutlineCell alloc] initWithFrame:NSMakeRect(0, 0, outlineView.bounds.size.width, cellHeight)];
        
        outlineCell.label.text = text;
        
        outlineCell.itemName = itemName;
        
        outlineCell.selectable = selectable;
        
        if (selectable == YES) {
            
            if ([text isEqualToString:@"InsertConfig"]) {
            
                outlineCell.image = [NSImage imageNamed:@"confignormal"];

            } else if ([text isEqualToString:@"WiFi"]) {
                
                outlineCell.image = [NSImage imageNamed:@"WiFinormal"];
                
            } else if ([text isEqualToString:@"RAT"]) {
                
                outlineCell.image = [NSImage imageNamed:@"RATnormal"];
                
            } else if ([text isEqualToString:@"WF3"]) {
                
                outlineCell.image = [NSImage imageNamed:@"WF3normal"];

            } else if ([text isEqualToString:@"WF5"]) {
                
                outlineCell.image = [NSImage imageNamed:@"WF5normal"];

            }
            
            outlineCell.label.textColor = [NSColor colorWithWhite:0.3 alpha:1];
            
            outlineCell.label.font = [NSFont systemFontOfSize:13];

            [[[JZApplicationManager manager] outlineCellPool] addOutlineCell:outlineCell];

        } else {
            
            outlineCell.label.textColor = [NSColor blackColor];
            
        }
    }
    
    if ([itemName isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:keyItemName]]) {
        
        [[NSApplication sharedApplication].keyWindow makeFirstResponder:outlineCell];
        
    }
    
    [rowView addSubview:outlineCell];
    
    
    return rowView;
}

//定义每一行的行高
- (CGFloat)outlineView:(NSOutlineView *)outlineView heightOfRowByItem:(id)item
{
    return cellHeight;
}

// 控制每一行是否可选中
- (BOOL)outlineView:(NSOutlineView *)outlineView shouldSelectItem:(id)item
{
    NSLog(@"%s", __FUNCTION__);

    return NO;
}

- (BOOL)outlineView:(NSOutlineView *)outlineView shouldExpandItem:(id)item
{
    
    if ([item isKindOfClass:[NSDictionary class]]) {
        
        return YES;
        
    } else {
        
        return NO;
    }
}

// 这个方法会覆盖上面的方法，返回可选中行所排的序号组成的set
//- (NSIndexSet *)outlineView:(NSOutlineView *)outlineView selectionIndexesForProposedSelection:(NSIndexSet *)proposedSelectionIndexes
//{
//    [proposedSelectionIndexes enumerateIndexesUsingBlock:^(NSUInteger idx, BOOL * _Nonnull stop) {
//        NSLog(@"idx = %lu", (unsigned long)idx);
//    }];
//    
//    return proposedSelectionIndexes;
//}


@end
