//
//  JZMainViewPool.h
//  RF
//
//  Created by Jim on 2017/5/8.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@class JZMainView;
@interface JZMainViewPool : NSObject

@property (nonatomic, readonly) NSMutableDictionary *mainViewPool;

- (void)addMainView:(JZMainView *)mainView;

- (JZMainView *)findMainViewByItemName:(NSString *)itemName;

@end
