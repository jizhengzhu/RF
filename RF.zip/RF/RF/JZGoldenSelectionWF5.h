//
//  JZGoldenSelectionWF5.h
//  RF
//
//  Created by Jim on 2017/5/9.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZMainView.h"

@interface JZGoldenSelectionWF5 : JZMainView

@end
