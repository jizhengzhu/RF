//
//  JZCollectionCell.m
//  RF
//
//  Created by Jim on 2017/5/10.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZCollectionCell.h"
#import "NSLabel.h"
#import "JZApplicationManager.h"
#import "CustomSize.h"
#import "JZModuleView.h"
#import "JZDailyBreakdownInsertConfig.h"

@interface JZCollectionCell ()
{
    BOOL canHighlight;
}

@property (nonatomic) NSLabel *label;

@end

@implementation JZCollectionCell

- (NSLabel *)label
{
    if (!_label) {
        
        _label = [[NSLabel alloc] initWithFrame:self.bounds];
        
        _label.alignment = NSTextAlignmentCenter;
        
        _label.backgroundColor = [NSColor colorWithWhite:1 alpha:0.6];
        
        _label.textColor = [NSColor darkGrayColor];

        _label.wantsLayer = YES;
        
        _label.layer.cornerRadius = 5;
        
        _label.layer.masksToBounds = YES;
        
    }
    return _label;
}

- (void)setText:(NSString *)text
{
    _text = [text copy];
    
    self.label.text = text;
}

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self addSubview:self.label];
    }
    return self;
}

- (void)updateItemName:(NSString *)itemName
{
    _itemName = [itemName copy];
}

//此方法需要在改变的时候手动调用一次(父类的方法)
- (void)updateTrackingAreas
{
    NSArray *trackings = [self trackingAreas];
    for (NSTrackingArea *tracking in trackings)
    {
        [self removeTrackingArea:tracking];
    }
    
    //添加NSTrackingActiveAlways掩码可以使视图未处于激活或第一响应者时也能响应相应的方法
    NSTrackingArea *trackingArea = [[NSTrackingArea alloc] initWithRect:[self bounds]
                                                                options:NSTrackingMouseEnteredAndExited|NSTrackingMouseMoved|NSTrackingActiveAlways
                                                                  owner:self
                                                               userInfo:nil];
    [self addTrackingArea:trackingArea];
}

- (void)mouseDown:(NSEvent *)event
{
    _mouseStatus = JZCollectionCell_MouseDown;
    
    [self resetColor];
}

- (void)mouseUp:(NSEvent *)event
{
    _mouseStatus = JZCollectionCell_MouseUp;

    _isSelected = !_isSelected;
    
    canHighlight = _isSelected;

    [self resetColor];
    
}

- (void)mouseMoved:(NSEvent *)event
{
    [[NSApplication sharedApplication].keyWindow makeFirstResponder:self];
    
    [[JZApplicationManager manager] refreshCollectionViewDisplay];
}

- (void)mouseEntered:(NSEvent *)event
{
    _mouseLocation = JZCollectionCell_MouseEnter;
    
    canHighlight = YES;
    
    [self resetColor];

}

- (void)mouseExited:(NSEvent *)event
{
    _mouseLocation = JZCollectionCell_MouseExit;
    
    [self resetColor];
    
}

- (void)resetColor
{
    if (_mouseLocation == JZCollectionCell_MouseExit) {
        
        if (_isSelected == YES) {
            
            [self labelMouseUp];
            
        } else {
            
            [self labelMouseExit];

        }
        
    } else {
        
        if (_mouseStatus == JZCollectionCell_MouseUp) {
            
            
            if (_isSelected == YES) {
                
                [self labelMouseUp];
                
            } else {
                
                [self labelMouseExit];
            }
            
            if (canHighlight == YES) {
                
                [self labelMouseEnter];

            } else {
                
                [self labelMouseExit];

            }

        } else {
            
            [self labelMouseDown];
        }
        
    }
    
}

- (void)labelMouseEnter
{
    self.label.layer.borderColor = [NSColor colorWithRed:0.05 green:0.70 blue:0.96 alpha:1.00].CGColor;
    
    self.label.layer.borderWidth = 2;
}

- (void)labelMouseExit
{
    self.label.backgroundColor = [NSColor colorWithWhite:1 alpha:0.6];
    
    self.label.textColor = [NSColor darkGrayColor];
    
    self.label.layer.borderColor = [NSColor clearColor].CGColor;
    
    self.label.layer.borderWidth = 0;
}

- (void)labelMouseDown
{
    self.label.backgroundColor = [NSColor colorWithRed:1 green:0.5 blue:0 alpha:0.5];
    
    self.label.textColor = [NSColor grayColor];
    
    self.label.layer.borderColor = [NSColor clearColor].CGColor;
    
    self.label.layer.borderWidth = 0;
}

- (void)labelMouseUp
{
    self.label.backgroundColor = [NSColor orangeColor];
    
    self.label.textColor = [NSColor whiteColor];
    
    self.label.layer.borderColor = [NSColor clearColor].CGColor;
    
    self.label.layer.borderWidth = 0;
}

- (void)keyDown:(NSEvent *)event
{
    NSLog(@"%s", __FUNCTION__);
    
    NSString *chars = [event characters];
    
    unichar character = [chars characterAtIndex: 0];
    
    if (character == NSDeleteCharacter) {
        
        if (_isSelected == YES) {
            
            NSString *key = [NSString stringWithFormat:@"%@%@", self.itemName, ModuleArrayKey];
            
            NSLog(@"ModuleArrayKey = %@", key);
            
            NSMutableArray *mArray = [[NSUserDefaults standardUserDefaults] objectForKey:key];
            
            NSMutableArray *anotherMArray = [NSMutableArray arrayWithArray:mArray];
            
            NSMutableArray *newMArray = [NSMutableArray array];
            
            for (NSDictionary *dict in anotherMArray) {
                
                NSString *cellName = dict[@"cellName"];
                
                if ([cellName isEqualToString:self.cellName] == NO) {
                    
                    [newMArray addObject:dict];
                }
            }
            
            [[NSUserDefaults standardUserDefaults] setObject:newMArray forKey:key];
            
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:[NSString stringWithFormat:@"%@%@", self.itemName, RefreshCollectionViewNotification] object:nil];
        }

    }
}

//
//- (NSImage *) captureScreenImageWithFrame: (NSRect) frame
//{
//    // 获取屏幕的图形端口
//    
//    CGrafPtr screenPort = CreateNewPort();
//    Rect screenRect;
//    GetPortBounds (screenPort, &screenRect);
//    
//    // 创建一个临时窗口做为容器
//    
//    NSWindow *grabWindow = [[NSWindow alloc] initWithContentRect: frame
//                            
//                            
//                                                       styleMask:NSBorderlessWindowMask
//                            
//                            
//                                                         backing:NSBackingStoreRetained
//                            
//                            
//                                                           defer: NO
//                                                          screen: nil];
//    CGrafPtr windowPort = GetWindowPort ([grabWindow windowRef]);
//    Rect windowRect;
//    GetPortBounds (windowPort, &windowRect);
//    SetPort (windowPort);
//    
//    // 将屏幕内容复制到临时窗口
//    
//    CopyBits (GetPortBitMapForCopyBits(screenPort),
//              GetPortBitMapForCopyBits(windowPort),
//              &screenRect,
//              &windowRect,
//              srcCopy,
//              NULL);
//    
//    // 将窗口内容复制到NSImage中
//    
//    NSView *grabContentView = [grabWindow contentView];
//    
//    [grabContentView lockFocus];
//    NSBitmapImageRep *screenRep;
//    screenRep = [[NSBitmapImageRep alloc] initWithFocusedViewRect: frame];
//    [grabContentView unlockFocus];
//    
//    NSImage *screenImage = [[NSImage alloc] initWithSize: frame.size];
//    [screenImage addRepresentation: screenRep];
//    
//    
//    
//    // Clean up
//    [grabWindow close];
//    DisposePort(screenPort);
//    
//    return (screenImage);
//    
//} // captureScreenImageWithFrame

@end
