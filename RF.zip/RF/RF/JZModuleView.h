//
//  JZModuleView.h
//  RF
//
//  Created by Jim on 2017/5/10.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "JZCollectionScrollView.h"
#import "JZInsertView.h"

@interface JZModuleView : NSView

@property (nonatomic, readonly) JZCollectionScrollView *collectionScrollView;

@property (nonatomic, readonly) JZInsertView *insertView;

@property (readonly) NSString *itemName;

- (void)updateItemName:(NSString *)itemName;

@end
