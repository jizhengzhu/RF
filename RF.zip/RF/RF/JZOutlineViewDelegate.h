//
//  JZOutlineViewDelegate.h
//  RF
//
//  Created by Jim on 2017/4/27.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>


@interface JZOutlineViewDelegate : NSObject <NSOutlineViewDelegate>

@end
