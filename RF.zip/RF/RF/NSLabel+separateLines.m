//
//  NSLabel+separateLines.m
//  RF
//
//  Created by Jim on 2017/5/7.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "NSLabel+separateLines.h"

@implementation NSLabel (separateLines)

- (NSArray *)getSeparatedLines
{
    CTFontRef myFont = CTFontCreateWithName((__bridge CFStringRef)([self.font fontName]), [self.font pointSize], NULL);
    
    NSMutableAttributedString *attStr = [[NSMutableAttributedString alloc] initWithString:self.text];
    
    [attStr addAttribute:(NSString *)kCTFontAttributeName value:(__bridge id)myFont range:NSMakeRange(0, attStr.length)];
    
    CTFramesetterRef frameSetter = CTFramesetterCreateWithAttributedString((__bridge CFAttributedStringRef)attStr);
    
    CGMutablePathRef path = CGPathCreateMutable();
    
    CGPathAddRect(path, NULL, CGRectMake(0,0,self.frame.size.width,100000));
    
    CTFrameRef frame = CTFramesetterCreateFrame(frameSetter, CFRangeMake(0, 0), path, NULL);
    
    NSArray *lines = (__bridge NSArray *)CTFrameGetLines(frame);
    
    NSMutableArray *linesArray = [[NSMutableArray alloc] init];
    
    for (id line in lines)
    {
        CTLineRef lineRef = (__bridge CTLineRef )line;
        
        CFRange lineRange = CTLineGetStringRange(lineRef);
        
        NSRange range = NSMakeRange(lineRange.location, lineRange.length);
        
        NSString *lineString = [self.text substringWithRange:range];
        
        [linesArray addObject:lineString];
    }
    
    return (NSArray *)linesArray;
}

@end
