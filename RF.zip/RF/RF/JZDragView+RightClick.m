//
//  JZDragView+RightClick.m
//  RF
//
//  Created by Jim on 2017/5/15.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZDragView+RightClick.h"

@implementation JZDragView (RightClick)

- (void)rightMouseDown:(NSEvent *)event
{
    NSLog(@"%s", __FUNCTION__);
    
//    CGPoint location = [event locationInWindow];
//    
//    NSArray *dataArray = @[@"Show In Finder", @"Delete"];
//    
//    NSMenuItem *itemMenu = [NSMenuItem separatorItem];

}

- (void)showInFinder
{
    NSLog(@"%s", __FUNCTION__);
}

- (void)deleteFile
{
    NSLog(@"%s", __FUNCTION__);
}
@end
