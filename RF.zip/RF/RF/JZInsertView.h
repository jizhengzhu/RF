//
//  JZInsertView.h
//  RF
//
//  Created by Jim on 2017/5/10.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class JZInsertBtn;
@interface JZInsertView : NSView

@property (nonatomic) NSTextField *insertTextField;

@property (nonatomic) JZInsertBtn *insertBtn;

@property BOOL isShrink;

@property (readonly) NSString *itemName;

- (void)updateItemName:(NSString *)itemName;

@end
