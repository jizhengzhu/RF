//
//  JZOutlineCell.h
//  RF
//
//  Created by Jim on 2017/5/9.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "NSLabel.h"

@interface JZOutlineCell : NSView

@property (nonatomic) NSLabel *label;

@property (copy) NSString *itemName;

@property (nonatomic) BOOL selectable;

@property BOOL isSelected;

@property (nonatomic) NSColor *backgroundColor;

@property (nonatomic) NSImage *image;

@end
