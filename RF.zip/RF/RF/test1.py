#!/usr/bin/python
import xlwt

str1 = 'abcd'
str2 = 'd'

for i in range(10):
    
    print str1.replace(str2, '')


wb = xlwt.Workbook()

ws = wb.add_sheet('sheet')

ws.col(0).width = 20000

wb.save("/Users/jim/Desktop/test1.xls")
