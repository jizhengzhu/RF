//
//  JZDailyBreakdownRATFrame.h
//  RF
//
//  Created by Jim on 2017/5/14.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZDailyBreakdownRATFrame : NSObject

@property NSRect summaryDragViewFrame;

@property NSRect frequencyDragViewFrame;

@property NSRect moduleViewFrame;

@property NSRect limitViewFrame;

@property NSRect optionBtnFrame;

- (instancetype)initWithRect:(NSRect)rect;

@end
