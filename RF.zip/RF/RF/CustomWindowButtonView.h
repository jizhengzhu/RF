//
//  CustomWindowButtonView.h
//  RF
//
//  Created by Jim on 2017/5/10.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface CustomWindowButtonView : NSView 

@property (nonatomic) BOOL mouseInside;
@property (nonatomic) NSButton *closeButton;
@property (nonatomic) NSButton *minitButton;
@property (nonatomic) NSButton *zoomButton;

@end
