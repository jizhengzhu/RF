//
//  JZDailyBreakdownRATFrame.m
//  RF
//
//  Created by Jim on 2017/5/14.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZDailyBreakdownRATFrame.h"
#import "CustomSize.h"

@implementation JZDailyBreakdownRATFrame
{
    CGFloat margin;
}
- (instancetype)initWithRect:(NSRect)rect
{
    self = [super init];
    
    if (self) {
        
        margin = (rect.size.width - (dragviewlength + interval * 2 + 80) * 2 - 160) / 4;
        
        CGFloat summaryX = margin;
        
        CGFloat summaryY = rect.size.height * goldenRatio;
        
        CGFloat summaryW = dragviewlength + interval * 2 + 80;
        
        CGFloat summaryH = dragviewlength * (1 + goldenRatio) + dragviewtitleheight;
        
        _summaryDragViewFrame = NSMakeRect(summaryX, summaryY, summaryW, summaryH);
        
        CGFloat frequencyX = summaryX + summaryW + margin;
        
        CGFloat frequencyY = rect.size.height * goldenRatio;
        
        CGFloat frequencyW = summaryW;
        
        CGFloat frequencyH = summaryH;
        
        _frequencyDragViewFrame = NSMakeRect(frequencyX, frequencyY, frequencyW, frequencyH);
        
        CGFloat limitViewW = 160;
        
        CGFloat limitViewH = 80;
        
        CGFloat limitViewX = frequencyX + frequencyW + margin;
        
        CGFloat limitViewY = summaryY + summaryH - dragviewtitleheight - limitViewH;
        
        _limitViewFrame = NSMakeRect(limitViewX, limitViewY, limitViewW, limitViewH);
        
        CGFloat optionBtnW = 160;
        
        CGFloat optionBtnH = 40;
        
        CGFloat optionBtnX = limitViewX;
        
        CGFloat optionBtnY = limitViewY - optionBtnH;
        
        _optionBtnFrame = NSMakeRect(optionBtnX, optionBtnY, optionBtnW, optionBtnH);
        
        CGFloat moduleViewX = 50;
        
        CGFloat moduleViewY = 0;
        
        CGFloat moduleViewW = rect.size.width - 100;
        
        CGFloat moduleViewH = summaryY;
        
        _moduleViewFrame = NSMakeRect(moduleViewX, moduleViewY, moduleViewW, moduleViewH);
    }
    
    return self;
}

@end
